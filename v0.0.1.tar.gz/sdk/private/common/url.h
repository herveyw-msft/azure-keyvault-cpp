/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace common {

inline akv::string_t full_authority( const web::uri& self )
{
    auto authority = self.host();

    if ( !contains( authority, __T( ":" ) ) && self.port() > 0 )
    {
        // Append port for complete authority
        // string and wstring are different on Windows
        return authority + __T( ":" ) + to_platform_string( self.port() );
    }

    return authority;
}

} }
