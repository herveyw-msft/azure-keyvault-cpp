/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

static inline bool sequence_equal( const std::vector<akv::byte_t>& self, const std::vector<akv::byte_t>& other )
{
    // Constant time comparison of two byte arrays
    size_t difference = self.size() ^ other.size();

    for ( size_t i = 0; i < self.size() && i < other.size(); i++ )
    {
        difference |= (size_t)( self[i] ^ other[i] );
    }

    return difference == 0;
}

static inline std::vector<akv::byte_t> take( const std::vector<akv::byte_t>& self, size_t count )
{
    if ( self.size() < count )
        throw std::invalid_argument( "self" );

    return std::vector<akv::byte_t>( self.cbegin(), self.cbegin() + count );
}

#if TARGET_OS_MAC || TARGET_OS_UNIX

static inline void SecureZeroMemory( void *ptr, size_t cnt )
{
    memset(ptr, 0, cnt);
    __asm__ __volatile__("" : : "r"(ptr) : "memory");
}

#endif

static inline void SecureZeroMemory( std::vector<akv::byte_t>& self )
{
    if ( !self.empty() ) ::SecureZeroMemory( self.data(), self.size() );
}
