/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

static inline int64_t utc_now()
{
    time_t    local;
    struct tm gmt;

    time( &local );           // Local Unix epoch time

#if TARGET_OS_WIN32
    gmtime_s( &gmt, &local ); // GMT/UTC
#else
    gmtime_r( &local, &gmt ); // GMT/UTC
#endif

    return mktime( &gmt );    // GMT/UTC Unix epoch time
}