/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#if defined(_MSC_VER) && _MSC_VER < 1900

// Need to pull in Boost here for VC++ 12
#include <boost/thread.hpp>

#endif

namespace akv {

#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ < 5

// Experimental GNU C++ 11 support below g++ v5 means we need to use Boost.
// Note that some other compilers define __GNUC__ to indicate their compatibility
// and so these have to be ignored. Currently, this is just CLang on macOS.
typedef boost::mutex                    mutex_t;
typedef boost::lock_guard<boost::mutex> lock_guard_t;

#elif defined(_MSC_VER) && _MSC_VER < 1900

// Incomplete C++ 11 support in Visual C++ before 2015 means that we need 
// to use Boost for mutex and lock_guard.
typedef boost::mutex                    mutex_t;
typedef boost::lock_guard<boost::mutex> lock_guard_t;

#else

// We should have functional C++ 11 support
typedef std::mutex                  mutex_t;
typedef std::lock_guard<std::mutex> lock_guard_t;

#endif
}
