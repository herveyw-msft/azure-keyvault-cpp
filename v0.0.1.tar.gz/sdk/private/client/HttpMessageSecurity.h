/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

namespace authentication {

class AKV_EXPORT AuthenticationProofKey;
}

class HttpMessageSecurity : public akv::IKeyResolver
{
public:
    HttpMessageSecurity();
    HttpMessageSecurity( const HttpMessageSecurity& ) = default;
    HttpMessageSecurity& operator = ( const HttpMessageSecurity& ) = default;

#if _MSC_VER && _MSC_VER >= 1900
	HttpMessageSecurity( HttpMessageSecurity&& )              = default;
	HttpMessageSecurity& operator = ( HttpMessageSecurity&& ) = default;
#endif

    akv::string_t                                           clientSecurityToken;
    std::shared_ptr<authentication::AuthenticationProofKey> clientSignatureKey;
    std::shared_ptr<HttpMessageProtectionKey>               clientEncryptionKey;
    std::shared_ptr<IKey> serverSignatureKey;
    std::shared_ptr<IKey> serverEncryptionKey;

    pplx::task<std::shared_ptr<IKey>> resolve_key( const akv::string_t& kid, const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

protected:

private:
};

}
