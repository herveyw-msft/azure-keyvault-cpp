/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class HttpMessage
{
public:
    HttpMessage( const web::http::method& );

    const web::http::method& method() const;
    web::json::object& body();

    akv::string_t serialize() const;

protected:

private:
    web::http::method _method;
    web::json::object _body;
};

}
