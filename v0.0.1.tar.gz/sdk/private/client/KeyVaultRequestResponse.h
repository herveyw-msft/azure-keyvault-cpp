/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class HttpMessage;
class HttpMessageSecurity;

template<typename T>
std::shared_ptr<T> from_json( const web::json::value& value )
{
    return T::from_json( value );
}

class RequestWriter
{
public:
    static pplx::task<std::shared_ptr<web::http::http_request>> write( const std::shared_ptr<HttpMessage> httpMessage, const std::shared_ptr<HttpMessageSecurity> security );

};

class ResponseReader
{
public:
    template<typename T>
    static pplx::task<std::shared_ptr<T>> read( const web::http::http_response& response, const std::shared_ptr<HttpMessageSecurity> security )
    {
        return ResponseReader::read_json( response, security ).then( []( web::json::value value )
        {
            return from_json<T>( value );
        } );
    }

protected:
    static pplx::task<web::json::value> read_json( const web::http::http_response& response, const std::shared_ptr<HttpMessageSecurity> security );

private:

};

}
