/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace web { namespace http { class http_request; } }

namespace akv {

namespace jose {
class AKV_EXPORT JsonWebKey;
}    

namespace authentication {

class AKV_EXPORT AuthenticationException;
class AKV_EXPORT AccessToken;
class AKV_EXPORT AuthenticationContext;
class AKV_EXPORT ClientSecretCredentials;

class AuthenticationResponse;
    
class AuthenticationContext::Impl
{
public:
    Impl();
    Impl( const Impl& )              = delete; // No copy
    Impl( Impl&& )                   = delete; // No move
    Impl& operator = ( const Impl& ) = delete; // No copy assign
    Impl& operator = ( Impl&& )      = delete; // No move assign
    virtual ~Impl();

    pplx::task<std::shared_ptr<akv::authentication::AccessToken>> acquireToken( const akv::string_t&            scheme,
                                                                                const akv::string_t&            authority,
                                                                                const akv::string_t&            resource,
                                                                                const akv::string_t&            scope,
                                                                                const ClientCredentials&        credentials,
                                                                                const pplx::cancellation_token& cancellationToken = pplx::cancellation_token::none() ) throw( AuthenticationException );

    void flush();

protected:

private:
    pplx::task<std::shared_ptr<AuthenticationResponse>> acquireToken( const web::uri&                                 requestUrl,
                                                                      const std::shared_ptr<web::http::http_request>  request,
                                                                      const pplx::cancellation_token&                 cancellationToken = pplx::cancellation_token::none() ) throw( AuthenticationException );

    std::shared_ptr<akv::authentication::AccessToken> getCachedToken( const akv::string_t& scheme, const akv::string_t& authority, const akv::string_t& resource, const akv::string_t& scope );
    std::shared_ptr<akv::authentication::AccessToken> putCachedToken( const akv::string_t& scheme, const akv::string_t& authority, const akv::string_t& resource, const akv::string_t& scope, std::shared_ptr<akv::authentication::AccessToken> accessToken );
};

} }
