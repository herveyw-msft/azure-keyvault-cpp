/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

// Forward declaration
namespace web {
    namespace json {
        class value;
    }
}

namespace akv { namespace authentication {

class AuthenticationResponse
{
public:
    static std::shared_ptr<AuthenticationResponse> fromJson( const web::json::value& src );

    AuthenticationResponse();
    AuthenticationResponse( const AuthenticationResponse& );
    AuthenticationResponse( AuthenticationResponse&& );
    AuthenticationResponse& operator = ( const AuthenticationResponse& );
    AuthenticationResponse& operator = ( AuthenticationResponse&& );
    virtual ~AuthenticationResponse();

    akv::string_t access_token() const;
    akv::string_t token_type() const;
    time_t        expires() const;

    akv::string_t error() const;
    akv::string_t error_description() const;

protected:

private:
    struct State;
    State *_state;
};

} }
