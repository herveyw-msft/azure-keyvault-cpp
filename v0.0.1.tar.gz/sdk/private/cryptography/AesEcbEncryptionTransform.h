/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IEncryptionTransform;

class AKV_EXPORT AesEcbEncryptionTransform : public IEncryptionTransform
{
public:
    AesEcbEncryptionTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv );
    AesEcbEncryptionTransform( const AesEcbEncryptionTransform& )              = delete;
    AesEcbEncryptionTransform( AesEcbEncryptionTransform&& );
    AesEcbEncryptionTransform& operator = ( const AesEcbEncryptionTransform& ) = delete;
    AesEcbEncryptionTransform& operator = ( AesEcbEncryptionTransform&& );
    virtual ~AesEcbEncryptionTransform();

    EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext );
    DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag );

protected:

private:
    struct State;
    State *_state = NULL;
};

} }
