/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT ISignatureTransform;
class AKV_EXPORT RsaParameters;

class RsaKeyHandle;

class RsaSignatureTransform : public ISignatureTransform
{
public:
    RsaSignatureTransform()                               = delete;
    RsaSignatureTransform( const RsaSignatureTransform& ) = delete;
    RsaSignatureTransform( RsaSignatureTransform&& )      = delete;

    RsaSignatureTransform& operator = ( const RsaSignatureTransform& ) = delete;
    RsaSignatureTransform& operator = ( RsaSignatureTransform&& )      = delete;

    virtual ~RsaSignatureTransform();

    virtual ISignatureTransform::SignResult   signHash( const std::vector<akv::byte_t>& digest );
    virtual ISignatureTransform::VerifyResult verifyHash( const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& signature );

    virtual ISignatureTransform::SignResult   signMessage( const std::vector<akv::byte_t>& message );
    virtual ISignatureTransform::VerifyResult verifyMessage( const std::vector<akv::byte_t>& message, const std::vector<akv::byte_t>& signature );

protected:
    struct State;
    State *_state;

    RsaSignatureTransform( const RsaParameters&, RsaKeyHandle::SignatureMode signatureMode );
    RsaSignatureTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle, RsaKeyHandle::SignatureMode signatureMode );

private:

};

class Rs256SignatureTransform : public RsaSignatureTransform
{
public:
    Rs256SignatureTransform( const RsaParameters& );
    Rs256SignatureTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

    virtual ~Rs256SignatureTransform();

protected:

private:
};

class Rs384SignatureTransform : public RsaSignatureTransform
{
public:
    Rs384SignatureTransform( const RsaParameters& );
    Rs384SignatureTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

    virtual ~Rs384SignatureTransform();

protected:

private:
};

class Rs512SignatureTransform : public RsaSignatureTransform
{
public:
    Rs512SignatureTransform( const RsaParameters& );
    Rs512SignatureTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

    virtual ~Rs512SignatureTransform();

protected:

private:
};

} }
