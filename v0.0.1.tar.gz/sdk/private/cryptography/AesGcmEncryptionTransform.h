/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IEncryptionTransform;

class AKV_EXPORT AesGcmEncryptionTransform : public IEncryptionTransform
{
public:
    AesGcmEncryptionTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv );
    AesGcmEncryptionTransform( const AesGcmEncryptionTransform& )              = delete; // No copy
    AesGcmEncryptionTransform( AesGcmEncryptionTransform&& );                            // Move

    AesGcmEncryptionTransform& operator = ( const AesGcmEncryptionTransform& ) = delete; // No assign copy
    AesGcmEncryptionTransform& operator = ( AesGcmEncryptionTransform&& );               // Assign move
    virtual ~AesGcmEncryptionTransform();

    EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext );
    DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag );

protected:

private:
    struct State;
    State *_state;
};

} }
