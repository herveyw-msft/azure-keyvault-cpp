/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT RsaParameters;
    
class AKV_EXPORT RsaKeyHandle
{
public:
    enum PaddingMode
    {
        PKCS1_5,
        OAEP,
        OAEP256
    };

    enum SignatureMode
    {
        RS256,
        RS384,
        RS512
    };

    RsaKeyHandle();
    RsaKeyHandle( const RsaParameters& parameters );

#if TARGET_OS_WIN32
    RsaKeyHandle( PCCERT_CONTEXT context );
#endif

    RsaKeyHandle( const RsaKeyHandle& )              = delete; // No copy
    RsaKeyHandle( RsaKeyHandle&& )                   = delete; // No move

    RsaKeyHandle& operator = ( const RsaKeyHandle& ) = delete; // No copy assign
    RsaKeyHandle& operator = ( RsaKeyHandle&& )      = delete; // No move assign
    
    virtual ~RsaKeyHandle();

    RsaParameters exportParameters( bool includePrivate = false );

    std::vector<akv::byte_t> decrypt( const std::vector<akv::byte_t>& plaintext, PaddingMode paddingMode = PaddingMode::OAEP );
    std::vector<akv::byte_t> encrypt( const std::vector<akv::byte_t>& plaintext, PaddingMode paddingMode = PaddingMode::OAEP );

    std::vector<akv::byte_t> sign( const std::vector<akv::byte_t>& digest, SignatureMode signatureMode = SignatureMode::RS256 );
    bool                   verify( const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& signature, SignatureMode signatureMode = SignatureMode::RS256 );

protected:

private:
    struct State;
    State *_state;
};

} }
