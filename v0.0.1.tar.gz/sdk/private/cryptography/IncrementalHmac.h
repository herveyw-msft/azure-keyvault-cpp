/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class IncrementalHmac
{
public:
    IncrementalHmac( const akv::string_t& hashName, const std::vector<akv::byte_t>& secret );
    IncrementalHmac( const IncrementalHmac& ) = delete;
    IncrementalHmac& operator = ( const IncrementalHmac& ) = delete;
    ~IncrementalHmac();

    void update( const std::vector<akv::byte_t>& data );
    std::vector<akv::byte_t> updateFinal( const std::vector<akv::byte_t>& data );

protected:

private:
    struct State;
    State *_state;

    void dispose();
};

} }
