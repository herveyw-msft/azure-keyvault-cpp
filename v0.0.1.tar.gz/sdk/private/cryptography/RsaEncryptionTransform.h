/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IEncryptionTransform;
class AKV_EXPORT RsaParameters;

class RsaKeyHandle;

class RsaEncryptionTransform : public IEncryptionTransform
{
public:
    virtual ~RsaEncryptionTransform();

protected:
    struct State;
    State *_state;

    RsaEncryptionTransform( const RsaParameters& );
    RsaEncryptionTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

private:

};

class Rsa15EncryptionTransform : public RsaEncryptionTransform
{
public:
    Rsa15EncryptionTransform( const RsaParameters& );
    Rsa15EncryptionTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

    virtual ~Rsa15EncryptionTransform();

    virtual IEncryptionTransform::EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext );
    virtual IEncryptionTransform::DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag );

protected:

private:
};

class RsaOaepEncryptionTransform : public RsaEncryptionTransform
{
public:
    RsaOaepEncryptionTransform( const RsaParameters& );
    RsaOaepEncryptionTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

    virtual ~RsaOaepEncryptionTransform();

    virtual IEncryptionTransform::EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext );
    virtual IEncryptionTransform::DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag );

protected:

private:
};

class RsaOaep256EncryptionTransform : public RsaEncryptionTransform
{
public:
    RsaOaep256EncryptionTransform( const RsaParameters& );
    RsaOaep256EncryptionTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle );

    virtual ~RsaOaep256EncryptionTransform();

    virtual IEncryptionTransform::EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext );
    virtual IEncryptionTransform::DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag );

protected:

private:
};

} }
