/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IKeyWrapTransform;

class AKV_EXPORT AesKeyWrapTransform : public IKeyWrapTransform
{
public:
    AesKeyWrapTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv );
    AesKeyWrapTransform( const AesKeyWrapTransform& )              = delete; // No copy
    AesKeyWrapTransform( AesKeyWrapTransform&& )                   = delete; // No move
    AesKeyWrapTransform& operator = ( const AesKeyWrapTransform& ) = delete; // No copy assign
    AesKeyWrapTransform& operator = ( AesKeyWrapTransform&& )      = delete; // No move assign
    virtual ~AesKeyWrapTransform();

    virtual WrapResult wrap( const std::vector<akv::byte_t>& key );
    virtual UnwrapResult unwrap( const std::vector<akv::byte_t>& encryptedKey );

protected:

private:
    struct State;
    State *_state = NULL;
};

} }
