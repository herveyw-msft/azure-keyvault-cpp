/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IEncryptionTransform;

class AKV_EXPORT AesCbcEncryptionTransform : public IEncryptionTransform
{
public:
    AesCbcEncryptionTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv );
    AesCbcEncryptionTransform( const AesCbcEncryptionTransform& )              = delete; // No copy
    AesCbcEncryptionTransform( AesCbcEncryptionTransform&& );                            // Move

    AesCbcEncryptionTransform& operator = ( const AesCbcEncryptionTransform& ) = delete; // No assign copy
    AesCbcEncryptionTransform& operator = ( AesCbcEncryptionTransform&& );               // Assign move
    virtual ~AesCbcEncryptionTransform();

    EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext );
    DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag );

protected:

private:
    struct State;
    State *_state;
};

} }
