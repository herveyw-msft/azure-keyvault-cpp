/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/core/IKey.h"

namespace akv
{

IKey::~IKey()
{
}

/// <summary>
/// Encrypts the specified plain text.
/// </summary>
/// <param name="algorithm">The algorithm to use</param>
/// <param name="plaintext">The plain text to encrypt</param>
/// <param name="iv">The initialization vector</param>
/// <param name="authenticationData">The authentication data</param>
/// <param name="token">Cancellation token</param>
/// <returns>A Tuple consisting of the cipher text, the authentication tag (if applicable), the algorithm used</returns>
/// <remarks>Not all algorithyms require, or support, all parameters.</remarks>
pplx::task<IKey::EncryptResult> IKey::encrypt( const std::vector<akv::byte_t>& plaintext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const pplx::cancellation_token& token ) const
{ 
    return encrypt( this->defaultEncryptionAlgorithm(), plaintext, iv, authenticationData, token );
}                                   

/// <summary>
/// Encrypts the specified key material using the keys defaultKeyWrapAlgorithm
/// </summary>
/// <param name="key">The key material to encrypt</param>
/// <param name="algorithm">The algorithm to use</param>
/// <param name="token">Cancellation token</param>
/// <returns>A Tuple consisting of the encrypted key and the algorithm used</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::WrapResult> IKey::wrap( const std::vector<akv::byte_t>& key,
                                         const pplx::cancellation_token& token ) const
{
    return wrap( this->defaultKeyWrapAlgorithm(), key, token );
}                                   

/// <summary>
/// Signs the specified digest using the keys defaultSignatureAlgorithm
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="token">Cancellation token</param>
/// <returns>The signature value</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::SignResult> IKey::signHash( const std::vector<akv::byte_t>& digest,
                                             const pplx::cancellation_token& token ) const
{
    return signHash( this->defaultSignatureAlgorithm(), digest, token );
}                                 

}
