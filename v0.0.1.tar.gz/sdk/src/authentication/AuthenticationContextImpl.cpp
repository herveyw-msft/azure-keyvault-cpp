/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

// CPP REST SDK
#include <cpprest/http_client.h>
#include <cpprest/uri.h>
#include <cpprest/json.h>

// AKV
#include "akv/core/IKey.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/authentication/AuthenticationException.h"
#include "akv/authentication/ClientCredentials.h"
#include "akv/authentication/AuthenticationProofKey.h"
#include "akv/authentication/AuthenticationContext.h"

// Internal
#include "common/mutex_t.h"

#include "authentication/AuthenticationResponse.h"
#include "authentication/AuthenticationContextImpl.h"

#include "cryptography/RsaKeyHandle.h"

using namespace std;

using namespace akv::common;
using namespace akv::cryptography;
using namespace akv::jose;

using namespace web;
using namespace web::details;
using namespace web::http;
using namespace web::http::client;
using namespace web::json;

namespace akv { namespace authentication {

typedef map<akv::string_t, shared_ptr<AccessToken>>       TokenMap;
typedef pair<akv::string_t, std::shared_ptr<AccessToken>> TokenMapEntry;

static akv::string_t ContentTypeJson( __T( "application/json" ) );
static akv::string_t ContentTypeUrlEncoded( __T( "application/x-www-form-urlencoded" ) );

static TokenMap     _cache;
static akv::mutex_t _cacheLock;

shared_ptr<http_request> createRequest( const web::uri& audience, const akv::string_t& resource, const akv::string_t& scope, const std::shared_ptr<akv::jose::JsonWebKey>& key, const ClientCredentials& credentials )
{
    // Build the base request
    auto httpRequest = make_shared<http_request>( methods::POST );

    httpRequest->headers().add( __T("Accept"), ContentTypeJson );

    akv::string_t body = __T( "resource=" ) + uri::encode_data_string( resource )
                        + __T( "&response_type=token&grant_type=client_credentials&" )
                        + credentials.encode( audience.to_string() );

    if ( key != nullptr )
    {
        // Append the encoded public key for Proof of Possession
        body += + __T( "&pop_jwk=" ) + uri::encode_data_string( key->to_string() );
    }

    httpRequest->set_body( body, ContentTypeUrlEncoded );
    
    return httpRequest;
}


static pplx::task<json::value> readResponse( const web::http::http_response& response )
{
    if ( contains( response.headers().content_type(), ContentTypeJson ) )
    {
        return response.extract_json();
    }

    return pplx::create_task( []() -> json::value
    {
        return json::value();
    } );
}

AuthenticationContext::Impl::Impl()
{
}

AuthenticationContext::Impl::~Impl()
{
}

pplx::task<shared_ptr<AccessToken>> AuthenticationContext::Impl::acquireToken( const akv::string_t&                          scheme,
                                                                               const akv::string_t&                          authority,
                                                                               const akv::string_t&                          resource,
                                                                               const akv::string_t&                          scope,
                                                                               const ClientCredentials&                      credentials,
                                                                               const pplx::cancellation_token&               cancellationToken ) throw( AuthenticationException )
{
    // Try to use an existing cached token.
    auto token = getCachedToken( scheme, authority, resource, scope );

    if ( token != nullptr )
    {
        return pplx::create_task( [token]() -> shared_ptr<AccessToken>
        {
            return token;
        } );
    }

    // Establish the token endpoint
    web::uri                                httpUrl( authority + __T( "/oauth2/token" ) );
    std::shared_ptr<http_request>           httpRequest;
    std::shared_ptr<AuthenticationProofKey> key;

    if ( scheme.compare( __T( "PoP" ) ) == 0 )
    {
        // Generate a proof key
        key = make_shared<AuthenticationProofKey>( JsonWebKey::KeyTypes::Rsa() );

        httpRequest = createRequest( httpUrl, resource, scope, key->public_key(), credentials );
    }
    else if ( scheme.compare( __T( "Bearer" ) ) == 0 )
    {
        // No proof key here
        httpRequest = createRequest( httpUrl, resource, scope, nullptr, credentials );
    }
    else
    {
        throw invalid_argument( "scheme" );
    }

    auto self = this;

    // Azure HTTP REST API call
    return acquireToken( httpUrl, httpRequest, cancellationToken ).then( [self, scheme, authority, resource, scope, key]( shared_ptr<AuthenticationResponse> response ) -> std::shared_ptr<AccessToken>
    {
        shared_ptr<AccessToken> token;

        if ( key == nullptr )
            token = make_shared<AccessToken>( response->access_token(), response->expires() );
        else
            token = make_shared<AccessToken>( response->access_token(), key, response->expires() );

        return self->putCachedToken( scheme, authority, resource, scope, token );

    }, cancellationToken );
}

pplx::task<std::shared_ptr<AuthenticationResponse>> AuthenticationContext::Impl::acquireToken( const web::uri&                 httpUrl,
                                                                                               const shared_ptr<http_request>  httpRequest,
                                                                                               const pplx::cancellation_token& cancellationToken ) throw( AuthenticationException )
{
    auto httpClient  = make_shared<http_client>( httpUrl.to_string() );

    return httpClient->request(*httpRequest).then( [cancellationToken]( http_response response ) -> pplx::task<std::shared_ptr<AuthenticationResponse>>
    {
        akv::string_t id;
        auto         status_code = response.status_code();

        if ( response.headers().has(__T("x-ms-request-id")) )
            id = response.headers()[__T("x-ms-request-id")];

        return readResponse( response ).then( [status_code]( json::value value ) -> shared_ptr<AuthenticationResponse>
        {
            auto authResponse = AuthenticationResponse::fromJson( value );

            switch ( status_code )
            {
                case 200:
                    return authResponse;

                default:
                    throw AuthenticationException( status_code, authResponse->error(), authResponse->error_description() );
            }
        }, cancellationToken );
    }, cancellationToken );
}

shared_ptr<AccessToken> AuthenticationContext::Impl::getCachedToken( const akv::string_t& scheme, const akv::string_t& authority, const akv::string_t& resource, const akv::string_t& scope )
{
    // Construct the cache key
    auto key = scheme + __T("::") + authority + __T("::") + resource + __T("::") + scope;

    try
    {
        akv::lock_guard_t lock( _cacheLock );

        auto cache_entry = _cache.find( key );

        if ( cache_entry != _cache.end() )
        {
            time_t current_time;
            double seconds;

            time( &current_time );
            seconds = difftime( cache_entry->second->expires(), current_time );

            // We allow a 5 minute clock skew: if the token has less than 5 minutes 
            // of life left, then we consider it already expired.
            if ( seconds < 300 )
            {
                _cache.erase( key );
            }
            else
            {
                return cache_entry->second;
            }
        }
    }
    catch ( ... )
    {
        // Intentionally empty
    }

    // Don't throw here, just return nullptr if there is no token.
    return nullptr;
}

std::shared_ptr<AccessToken> AuthenticationContext::Impl::putCachedToken( const akv::string_t& scheme, const akv::string_t& authority, const akv::string_t& resource, const akv::string_t& scope, std::shared_ptr<AccessToken> token )
{
    // Construct the cache key
    auto key = scheme + __T( "::" ) + authority + __T( "::" ) + resource + __T( "::" ) + scope;

    try
    {
        akv::lock_guard_t lock( _cacheLock );

        _cache.insert( TokenMapEntry( key, token ) );
    }
    catch ( ... )
    {
        // Intentionally empty
    }

    return token;
}

void AuthenticationContext::Impl::flush()
{
    try
    {
        akv::lock_guard_t lock( _cacheLock );

        _cache.clear();
    }
    catch ( ... )
    {
        // Intentionally empty
    }
}

} }
