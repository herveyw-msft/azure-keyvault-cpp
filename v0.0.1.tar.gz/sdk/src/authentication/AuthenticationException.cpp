/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"

#include "akv/authentication/AuthenticationException.h"

using namespace std;

namespace akv { namespace authentication {

struct AuthenticationException::State
{
    unsigned short _status;
    akv::string_t  _error;
    akv::string_t  _error_description;
};

AuthenticationException::AuthenticationException( unsigned short status, const akv::string_t& error )
{
    unique_ptr<State> state( new State() );

    state->_error  = error;
    state->_status = status;

    _state = state.release();
}

AuthenticationException::AuthenticationException( unsigned short status, const akv::string_t& error, const akv::string_t& error_description )
{    
    unique_ptr<State> state( new State() );

    state->_error             = error;
    state->_error_description = error_description;
    state->_status            = status;

    _state = state.release();
}

AuthenticationException::AuthenticationException( const AuthenticationException& other )
{
    unique_ptr<State> state( new State() );

    state->_error             = other._state->_error;
    state->_error_description = other._state->_error_description;
    state->_status            = other._state->_status;

    _state = state.release();
}

AuthenticationException& AuthenticationException::operator = ( const AuthenticationException& other )
{
    _state->_error             = other._state->_error;
    _state->_error_description = other._state->_error_description;
    _state->_status            = other._state->_status;

    return *this;
}

AuthenticationException::AuthenticationException( AuthenticationException&& other )
{
    _state = other._state;
    other._state = NULL;
}

AuthenticationException& AuthenticationException::operator = ( AuthenticationException&& other )
{
    _state = other._state;
    other._state = NULL;

    return *this;
}

AuthenticationException::~AuthenticationException()
{
    if ( _state != NULL ) delete _state;
}

unsigned short AuthenticationException::status_code() const
{
    return _state->_status;
}

const akv::string_t& AuthenticationException::error() const
{
    return _state->_error;
}

const akv::string_t& AuthenticationException::error_description() const
{
    return _state->_error_description;
}

} }
