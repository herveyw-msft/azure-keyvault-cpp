/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/authentication/ClientCredentials.h"

using namespace std;

namespace akv { namespace authentication {

struct ClientSecretCredentials::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    // TODO: Check that this really sets the data to zero
    ~State() { _client_id.clear(), _client_secret.clear(); }

    akv::string_t _client_id;
    akv::string_t _client_secret;
};

ClientSecretCredentials::ClientSecretCredentials( const akv::string_t& client_id, const akv::string_t& client_secret )
{
    _state = new State();

    _state->_client_id     = client_id;
    _state->_client_secret = client_secret;
}

ClientSecretCredentials::ClientSecretCredentials( const ClientSecretCredentials& other )
{
    _state = new State( *other._state );
}

ClientSecretCredentials & ClientSecretCredentials::operator=( const ClientSecretCredentials& other )
{
    _state->operator = ( *other._state );

    return *this;
}

ClientSecretCredentials::ClientSecretCredentials( ClientSecretCredentials&& other )
{
    _state = other._state;
    other._state = NULL;
}

ClientSecretCredentials& ClientSecretCredentials::operator=( ClientSecretCredentials&& other )
{
    _state = other._state;
    other._state = NULL;

    return *this;
}

ClientSecretCredentials::~ClientSecretCredentials()
{
    if ( NULL != _state ) delete _state;
}

akv::string_t ClientSecretCredentials::encode( const akv::string_t& audience ) const
{
    auto encodedClientId     = web::uri::encode_data_string( _state->_client_id );
    auto encodedClientSecret = web::uri::encode_data_string( _state->_client_secret );
    
    return __T( "client_id=" ) + encodedClientId + __T( "&client_secret=" ) + encodedClientSecret;
}

} }
