/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "authentication/AuthenticationResponse.h"

namespace akv { namespace authentication {

using namespace std;

const akv::string_t ACCESS_TOKEN( __T( "access_token" ) );
const akv::string_t TOKEN_TYPE( __T( "token_type" ) );
const akv::string_t EXPIRES_IN( __T( "expires_in" ) );

const akv::string_t OAUTH_ERROR( __T( "error" ));
const akv::string_t OAUTH_ERROR_DESCRIPTION( __T( "error_description" ) );

struct AuthenticationResponse::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;
    
    akv::string_t _access_token;
    akv::string_t _token_type;
    time_t        _expires;

    akv::string_t _error;
    akv::string_t _error_description;
};

std::shared_ptr<AuthenticationResponse> AuthenticationResponse::fromJson( const web::json::value& src )
{
    shared_ptr<AuthenticationResponse> response( new AuthenticationResponse() );

    if (src.has_field( OAUTH_ERROR ) )
    {
        response->_state->_error = src.at( OAUTH_ERROR ).as_string();

        if (src.has_field( OAUTH_ERROR_DESCRIPTION ) )
        {
            response->_state->_error_description = src.at( OAUTH_ERROR_DESCRIPTION ).as_string();
        }
    }
    else
    {
        // Default to one hour expiry if the server does not tell us the expiry
        int64_t                            expires_in = 3600;

        // TODO: Check for incomplete JSON
        if ( src.has_field( ACCESS_TOKEN ) ) { response->_state->_access_token = src.at( ACCESS_TOKEN ).as_string(); }
        if ( src.has_field( TOKEN_TYPE ) )   { response->_state->_token_type   = src.at( TOKEN_TYPE ).as_string(); }
        if ( src.has_field( EXPIRES_IN ) )
        {
            auto value = src.at( EXPIRES_IN );

            if ( value.is_number() )
            {
                auto number = value.as_number();

                expires_in  = number.to_int64();
            }
            else if ( value.is_string() )
            {
                auto string = value.as_string();

                // Attempt conversion to integer
#if TARGET_OS_WIN32
                expires_in  = ::wcstol( string.data(), NULL, 10 );
#else
                expires_in  = ::strtol( string.data(), NULL, 10 );
#endif
            }
        }

        // Set a reasonable default for expires_in if we didn't get one in
        // the response from the authorization service.
        if ( expires_in == 0 || expires_in == LONG_MIN || expires_in == LONG_MAX )
        {
            expires_in = 3600;
        }

        // Get the current time, should be POSIX Epoch and add the lifetime of the token
        time( &response->_state->_expires );

        response->_state->_expires += expires_in;

    }

    return response;
}

AuthenticationResponse::AuthenticationResponse()
{
    _state = new State();
}

AuthenticationResponse::AuthenticationResponse( const AuthenticationResponse& other )
{
    unique_ptr<State> state( new State() );

    state->_access_token = other._state->_access_token;
    state->_token_type   = other._state->_token_type;
    state->_expires      = other._state->_expires;

    state->_error   = other._state->_error;
    state->_error_description = other._state->_error_description;

    _state = state.release();
}

AuthenticationResponse::AuthenticationResponse( AuthenticationResponse&& other )
{
    _state = other._state;
    other._state = NULL;
}

AuthenticationResponse& AuthenticationResponse::operator = ( const AuthenticationResponse& other )
{
    _state->_access_token = other._state->_access_token;
    _state->_token_type   = other._state->_token_type;
    _state->_expires      = other._state->_expires;

    _state->_error             = other._state->_error;
    _state->_error_description = other._state->_error_description;

    return *this;
}

AuthenticationResponse& AuthenticationResponse::operator = ( AuthenticationResponse&& other )
{
    if ( _state != NULL ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

AuthenticationResponse::~AuthenticationResponse()
{
    if ( _state != NULL ) delete _state;
}

akv::string_t AuthenticationResponse::access_token() const
{
    return _state->_access_token;
}

akv::string_t AuthenticationResponse::token_type() const
{
    return _state->_token_type;
}

time_t AuthenticationResponse::expires() const
{
    return _state->_expires;
}

akv::string_t AuthenticationResponse::error() const
{
    return _state->_error;
}

akv::string_t AuthenticationResponse::error_description() const
{
    return _state->_error_description;
}

} }
