/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#if !TARGET_OS_WIN32
#include <openssl/pkcs12.h>
#endif

#include "common/time_t.h"

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/cryptography/Key.h"
#include "akv/cryptography/CertificateKey.h"

#include "akv/jose/JwsHeader.h"
#include "akv/jose/JwsObject.h"
#include "akv/jose/JsonWebSignature.h"

#include "akv/authentication/ClientCredentials.h"

using namespace akv;
using namespace akv::common;
using namespace akv::jose;

using namespace std;

namespace akv { namespace authentication {

struct ClientCertificateCredentials::State
{
    State() { }
    State( const State& )             = default;
    State& operator = ( const State& ) = default;
    // TODO: Check that this really sets the data to zero
    ~State() { _client_id.clear(); }

    akv::string_t                                 _client_id;
    std::shared_ptr<cryptography::CertificateKey> _client_secret;
};

ClientCertificateCredentials::ClientCertificateCredentials( const akv::string_t& client_id, const std::shared_ptr<cryptography::CertificateKey>& certificate )
{
    _state = new State();

    _state->_client_id     = client_id;
    _state->_client_secret = certificate;
}

ClientCertificateCredentials::ClientCertificateCredentials( const ClientCertificateCredentials& other )
{
    _state = new State( *other._state );
}

ClientCertificateCredentials & ClientCertificateCredentials::operator=( const ClientCertificateCredentials& other )
{
    _state->operator = ( *other._state );

    return *this;
}

ClientCertificateCredentials::ClientCertificateCredentials( ClientCertificateCredentials&& other )
{
    _state = other._state;
    other._state = NULL;
}

ClientCertificateCredentials& ClientCertificateCredentials::operator=( ClientCertificateCredentials&& other )
{
    _state = other._state;
    other._state = NULL;

    return *this;
}

ClientCertificateCredentials::~ClientCertificateCredentials()
{
    if ( NULL != _state ) delete _state;
}

akv::string_t ClientCertificateCredentials::encode( const akv::string_t& audience ) const
{
    // We need to produce a self-issued JWT token with some additional properties
    time_t        nbf     = utc_now();
    time_t        exp     = nbf + ( 5 * 60 );
    akv::string_t payload = __T( "{ \"aud\":\"" ) + audience + __T("\"")
                            + __T( ",\"iss\":\"" ) + _state->_client_id + __T("\"")
                            + __T( ",\"sub\":\"" ) + _state->_client_id + __T("\"")
                            + __T( ",\"nbf\":") + to_platform_string( nbf )
                            + __T( ",\"exp\":") + to_platform_string( exp )
                            + __T( "}" );

    shared_ptr<JwsHeader> header = make_shared<JwsHeader>();
    shared_ptr<JwsObject> object = make_shared<JwsObject>();

    header->algorithm( _state->_client_secret->defaultSignatureAlgorithm() );
    header->kid( _state->_client_secret->kid() );

    header->add_property( __T( "typ" ), web::json::value::string( __T( "JWT" ) ) );
    header->add_property( __T( "x5t" ), web::json::value::string( _state->_client_secret->x5t() ) );

    object->protected_header( header );
    object->payload( get_bytes( payload ) );

    auto jws = JsonWebSignature::sign( *_state->_client_secret, object ).get();

    auto encodedAssertion     = web::uri::encode_data_string( jws->to_compact_jws() );
    auto encodedAssertionType = web::uri::encode_data_string( __T( "urn:ietf:params:oauth:client-assertion-type:jwt-bearer" ) );

    return __T( "client_assertion_type=" ) + encodedAssertionType + __T( "&client_assertion=" ) + encodedAssertion;
}

} }
