/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/core/IKey.h"

#include "akv/cryptography/AlgorithmResolver.h"
#include "akv/cryptography/Key.h"

#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/RsaKey.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/authentication/AuthenticationProofKey.h"

using namespace std;
using namespace pplx;
using namespace web;

namespace akv { namespace authentication {

class AuthenticationProofKey::State
{
public:
    State()
    {
        // Intentionally empty        
    }

    std::shared_ptr<akv::cryptography::RsaKey> _key;
    std::shared_ptr<akv::jose::JsonWebKey>     _keyValue;
};

AuthenticationProofKey::AuthenticationProofKey( const akv::string_t& kty )
{
    unique_ptr<State> state( new State() );

    if ( akv::common::starts_with( kty, akv::jose::JsonWebKey::KeyTypes::Rsa() ) )
    {
        state->_key      = make_shared<akv::cryptography::RsaKey>( __T("proof-key") );
        state->_keyValue = make_shared<akv::jose::JsonWebKey>( state->_key->kid(), state->_key->exportParameters( false ) );
    }
    else
    {
        throw invalid_argument( "kty" );
    }

    _state = state.release();
}

AuthenticationProofKey::~AuthenticationProofKey()
{
    if ( _state != NULL ) delete _state;
}

const std::shared_ptr<jose::JsonWebKey>& AuthenticationProofKey::public_key() const
{
    return _state->_keyValue;
}

web::json::value AuthenticationProofKey::to_json() const
{
    // Serialize the public parameters for the RsaKey as a JsonWebKey
    std::vector<std::pair<akv::string_t, web::json::value>> properties;

    properties.push_back( std::make_pair<akv::string_t, web::json::value>( __T("jwk"), _state->_keyValue->to_json() ) );

    return web::json::value::object( properties );
}

//
// IKey interface
//

akv::string_t AuthenticationProofKey::kid() const
{
    return _state->_key->kid();
}

akv::string_t AuthenticationProofKey::defaultEncryptionAlgorithm() const
{
    return _state->_key->defaultEncryptionAlgorithm();
}

akv::string_t AuthenticationProofKey::defaultKeyWrapAlgorithm() const
{
    return _state->_key->defaultKeyWrapAlgorithm();
}

akv::string_t AuthenticationProofKey::defaultSignatureAlgorithm() const
{
    return _state->_key->defaultSignatureAlgorithm();
}

pplx::task<IKey::DecryptResult> AuthenticationProofKey::decrypt( const akv::string_t&            algorithm,
                                                                    const std::vector<akv::byte_t>& ciphertext,
                                                                    const std::vector<akv::byte_t>& iv,
                                                                    const std::vector<akv::byte_t>& authenticationData,
                                                                    const std::vector<akv::byte_t>& authenticationTag,
                                                                    const pplx::cancellation_token& token ) const
{
    return _state->_key->decrypt( algorithm, ciphertext, iv, authenticationData, authenticationTag, token );
}

pplx::task<IKey::EncryptResult> AuthenticationProofKey::encrypt( const akv::string_t&            algorithm,
                                                                    const std::vector<akv::byte_t>& plaintext,
                                                                    const std::vector<akv::byte_t>& iv,
                                                                    const std::vector<akv::byte_t>& authenticationData,
                                                                    const pplx::cancellation_token& token ) const
{
    return _state->_key->encrypt( algorithm, plaintext, iv, authenticationData, token );
}

pplx::task<IKey::WrapResult> AuthenticationProofKey::wrap( const akv::string_t&            algorithm,
                                                  const std::vector<akv::byte_t>& key,
                                                  const pplx::cancellation_token& token ) const
{
    return _state->_key->wrap( algorithm, key, token );
}

pplx::task<IKey::UnwrapResult> AuthenticationProofKey::unwrap( const akv::string_t&            algorithm,
                                                      const std::vector<akv::byte_t>& encryptedKey,
                                                      const pplx::cancellation_token& token ) const
{
    return _state->_key->unwrap( algorithm, encryptedKey, token );
}

pplx::task<IKey::SignResult> AuthenticationProofKey::signHash( const akv::string_t&            algorithm,
                                                      const std::vector<akv::byte_t>& digest,
                                                      const pplx::cancellation_token& token ) const
{
    return _state->_key->signHash( algorithm, digest, token );
}

pplx::task<IKey::VerifyResult> AuthenticationProofKey::verifyHash( const akv::string_t&            algorithm,
                                                          const std::vector<akv::byte_t>& digest,
                                                          const std::vector<akv::byte_t>& signature,
                                                          const pplx::cancellation_token& token ) const
{
    return _state->_key->verifyHash( algorithm, digest, signature, token );
}

} }
