/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "common/url.h"

#include "akv/authentication/HttpChallenge.h"

using namespace std;

using namespace akv::common;

namespace akv { namespace authentication {

static const akv::string_t Bearer( __T( "Bearer" ) );
static const akv::string_t BearerPrefix( __T( "Bearer " ) );

static const akv::string_t PoP( __T( "PoP" ) );
static const akv::string_t PoPPrefix( __T( "PoP " ) );

static const akv::string_t SchemeHttp( __T( "http" ) );
static const akv::string_t SchemeHttps( __T( "https" ) );

static const akv::string_t Authorization( __T( "authorization" ) );
static const akv::string_t AuthorizationUri( __T( "authorization_uri" ) );
static const akv::string_t Resource( __T( "resource" ) );
static const akv::string_t Scope( __T( "scope" ) );

struct HttpChallenge::State
{
    akv::string_t                          _scheme;
    std::map<akv::string_t, akv::string_t> _parameters;

    akv::string_t                          _sourceUri;
    akv::string_t                          _sourceAuthority;
};

HttpChallenge::HttpChallenge( const akv::string_t& uri, const akv::string_t& challenge )
{
    if ( uri.empty() ) throw invalid_argument( "uri" );
    if ( challenge.empty() ) throw invalid_argument( "challenge" );

    unique_ptr<State> state( new State() );

    auto authority = validateUri( uri );

    state->_sourceAuthority = authority;
    state->_sourceUri = uri;

    auto parsedChallenge = parseChallenge( challenge );

    state->_scheme     = parsedChallenge.first;
    state->_parameters = parsedChallenge.second;

    _state = state.release();
}

HttpChallenge::~HttpChallenge()
{
    if ( _state != NULL ) delete _state;
}

akv::string_t HttpChallenge::scheme() const
{
    return _state->_scheme;
}

akv::string_t HttpChallenge::authority() const
{
    auto result = _state->_parameters.find( Authorization );

    if ( result != _state->_parameters.end() )
        return result->second;

    result = _state->_parameters.find( AuthorizationUri );

    if ( result != _state->_parameters.end() )
        return result->second;

    return akv::string_t();
}

akv::string_t HttpChallenge::resource() const
{
    auto result = _state->_parameters.find( Resource );

    if ( result != _state->_parameters.end() )
        return result->second;

    return akv::string_t();
}

akv::string_t HttpChallenge::scope() const
{
    auto result = _state->_parameters.find( Scope );

    if ( result != _state->_parameters.end() )
        return result->second;

    return akv::string_t();
}

akv::string_t HttpChallenge::getParameter( const akv::string_t& name ) const
{
    auto result = _state->_parameters.find( name );

    if ( result != _state->_parameters.end() )
        return result->second;

    return akv::string_t();
}

akv::string_t HttpChallenge::setParameter( const akv::string_t& name, const akv::string_t& value )
{
    akv::string_t previous = getParameter( name );

    _state->_parameters[name] = value;

    return previous;
}

std::pair<akv::string_t, std::map<akv::string_t, akv::string_t>> HttpChallenge::parseChallenge( const akv::string_t& challenge )
{
    if ( challenge.empty() )
        throw invalid_argument( "challenge" );

    auto trimmedChallenge = trim( challenge );

    // A correct challenge now consists of "scheme [param=value, param=value]
    size_t                    offset = 0;
    size_t                    position = akv::string_t::npos;

    if ( ( position = trimmedChallenge.find( __T( ' ' ), offset ) ) != akv::string_t::npos )
    {
        // found a space character, so offset is now the length of the scheme
        akv::string_t                          scheme = trimmedChallenge.substr( 0, position );
        // The parameter name/value map
        std::map<akv::string_t, akv::string_t> parameters;

        // now parse the parameters
        trimmedChallenge = trimmedChallenge.substr( position + 1, trimmedChallenge.size() - position - 1 );

        // Split the trimmed challenge into a set of name=value strings that
        // are comma separated. The value fields are expected to be within
        // quotation characters that are stripped here.
        vector<akv::string_t> pairs = split( trimmedChallenge, ',' );

        if ( pairs.size() > 0 )
        {
            // Process the name=value strings
            for ( int i = 0; i < pairs.size(); i++ )
            {
                vector<akv::string_t> pair = split( pairs[i], '=' );

                if ( pair.size() == 2 )
                {
                    // We have a key and a value, now need to trim and decode
                    auto key = trim( trim( pair[0] ), '\"' );
                    auto value = trim( trim( pair[1] ), '\"' );

                    if ( !key.empty() )
                    {
                        parameters[key] = value;
                    }
                }
            }
        }

        // Minimum set of parameters
        if ( parameters.size() < 1 )
            throw invalid_argument( "Invalid challenge parameters" );

        return std::pair<akv::string_t, std::map<akv::string_t, akv::string_t>>( scheme, parameters );
    }
    else
    {
        throw invalid_argument( "challenge" );
    }
}

akv::string_t HttpChallenge::validateUri( const akv::string_t& url )
{
    web::uri requestUrl( url );

    if ( requestUrl.host().empty() )
        throw invalid_argument( "The requestUri must be an absolute URI" );

    if ( requestUrl.scheme().compare( SchemeHttp ) != 0 && requestUrl.scheme().compare( SchemeHttps ) != 0 )
        throw invalid_argument( "The requestUri must be HTTP or HTTPS" );

    return full_authority( requestUrl );
}

bool HttpBearerChallenge::isBearerChallenge( const akv::string_t& challenge )
{
    return starts_with( challenge, BearerPrefix );
}

HttpBearerChallenge::HttpBearerChallenge( const akv::string_t& uri, const akv::string_t& challenge ) : HttpChallenge( uri, challenge )
{
    if ( scheme().compare( Bearer ) != 0 )
        throw invalid_argument( "challenge" );

    // Must specify authorization or authorization_uri
    if ( authority().empty() )
        throw invalid_argument( "challenge" );
}

HttpBearerChallenge::~HttpBearerChallenge()
{
}

bool HttpPoPChallenge::isPoPChallenge( const akv::string_t& challenge )
{
    return starts_with( challenge, PoPPrefix );
}

HttpPoPChallenge::HttpPoPChallenge( const akv::string_t& uri, const akv::string_t& challenge ) : HttpChallenge( uri, challenge )
{
    if ( scheme().compare( PoP ) != 0 )
        throw invalid_argument( "challenge" );

    // Must specify authorization or authorization_uri
    if ( authority().empty() )
        throw invalid_argument( "challenge" );
}

HttpPoPChallenge::~HttpPoPChallenge()
{
}

} }
