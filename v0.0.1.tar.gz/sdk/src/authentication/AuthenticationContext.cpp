/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/authentication/AuthenticationException.h"
#include "akv/authentication/ClientCredentials.h"
#include "akv/authentication/AuthenticationContext.h"

#include "authentication/AuthenticationResponse.h"
#include "authentication/AuthenticationContextImpl.h"

using namespace std;

namespace akv { namespace authentication {

struct AccessToken::State
{
    akv::string_t                      _token;
    shared_ptr<AuthenticationProofKey> _key;
    time_t                             _expires;
};

AccessToken::AccessToken( const akv::string_t& token, time_t expires )
{
    if ( token.empty() )
        throw invalid_argument( "token" );

    unique_ptr<AccessToken::State> state( new AccessToken::State() );

    state->_token   = token;
    state->_key     = nullptr;
    state->_expires = expires;

    _state = state.release();
}

AccessToken::AccessToken( const akv::string_t& token, const shared_ptr<AuthenticationProofKey>& key, time_t expires )
{
    if ( token.empty() )
        throw invalid_argument( "token" );

    if ( key == nullptr )
        throw invalid_argument( "key" );

    unique_ptr<AccessToken::State> state( new AccessToken::State() );

    state->_token   = token;
    state->_key     = key;
    state->_expires = expires;

    _state = state.release();
}

akv::string_t AccessToken::token() const
{
    return _state->_token;
}

const shared_ptr<AuthenticationProofKey> AccessToken::key() const
{
    return _state->_key;
}

time_t AccessToken::expires() const
{
    return _state->_expires;
}

AuthenticationContext::AuthenticationContext()
{
    _impl = new Impl();
}

AuthenticationContext::~AuthenticationContext()
{
    delete _impl;
}

pplx::task<shared_ptr<AccessToken>> AuthenticationContext::acquire_token( const akv::string_t&            scheme,
                                                                          const akv::string_t&            authority,
                                                                          const akv::string_t&            resource,
                                                                          const akv::string_t&            scope,
                                                                          const ClientCredentials&        credentials,
                                                                          const pplx::cancellation_token& cancellationToken ) throw( AuthenticationException )
{
    return _impl->acquireToken( scheme, authority, resource, scope, credentials, cancellationToken );
}

void AuthenticationContext::flush()
{
    _impl->flush();
}

} }
