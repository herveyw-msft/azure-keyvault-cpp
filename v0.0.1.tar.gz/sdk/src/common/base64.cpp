/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

using namespace std;

namespace akv { namespace common {

static char base64EncodeTable[64] =
{
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
    'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
};

static char base64encode_urlTable[64] =
{
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
    'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '_'
};

#define NA (255)
#define DECODE(x)     (((unsigned long)(x) < sizeof(base64DecodeTable)) ? base64DecodeTable[x] : NA)
#define DECODE_URL(x) (((unsigned long)(x) < sizeof(base64decode_urlTable)) ? base64decode_urlTable[x] : NA)

static byte_t base64DecodeTable[128] = {                             // character code
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,  // 0-15
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,  // 16-31
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 62, NA, NA, NA, 63,  // 32-47
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, NA, NA, NA,  0, NA, NA,  // 48-63
    NA,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,  // 64-79
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, NA, NA, NA, NA, NA,  // 80-95
    NA, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,  // 96-111
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, NA, NA, NA, NA, NA,  // 112-127
};

static byte_t base64decode_urlTable[128] = {                          // character code
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,  // 0-15
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,  // 16-31
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 62, NA, NA,  // 32-47
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, NA, NA, NA,  0, NA, NA,  // 48-63
    NA,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,  // 64-79
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, NA, NA, NA, NA, 63,  // 80-95
    NA, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,  // 96-111
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, NA, NA, NA, NA, NA,  // 112-127
};

akv::string_t Base64::encode( const std::vector<akv::byte_t>& bytes )
{
    akv::string_t result;

    if ( bytes.size() > 0 )
    {
        size_t cbEncoded = 0;

        // determine the size of the output buffer
        if ( encode( bytes.data(), bytes.size(), NULL, 0, &cbEncoded ) )
        {
            // allocate space for the buffer
            unique_ptr<akv::byte_t[]> pbEncoded( new akv::byte_t[cbEncoded] );

            // convert to base64
            if ( encode( bytes.data(), bytes.size(), pbEncoded.get(), cbEncoded, &cbEncoded ) )
            {
                // WARNING: The result of the encode is a null terminated string that is
                //          _at_most_ cbEncoded bytes. It's therefore important to
                //          reconstitute the akv::string_t from the raw c ptr.
                result = to_platform_string( pbEncoded.get() );
            }
        }
    }

    return result;
}

/// <summary>
/// Base64 encode a set of bytes.
/// </summary>
/// <remarks>
/// See RFC 4648, Section 5.
/// For a good overview of Base64 encoding, see http://en.wikipedia.org/wiki/Base64
/// </remarks>
#if TARGET_OS_WIN32
// Allow for SAL annotations
bool Base64::encode( _In_reads_bytes_(cbBytes) const akv::byte_t *pbBytes, _In_ size_t cbBytes, _Out_writes_bytes_to_opt_(cbEncoded,*pcbEncoded ) akv::byte_t *pbEncoded, _In_ size_t cbEncoded, _Out_opt_ size_t *pcbEncoded )
#else
bool Base64::encode( const akv::byte_t *pbBytes, size_t cbBytes, akv::byte_t *pbEncoded, size_t cbEncoded, size_t *pcbEncoded )
#endif
{
    //
    // Parameters:
    //
    // pbBytes      Pointer to the buffer of bytes to encode
    // cbBytes      The count of bytes in the input buffer
    // pbEncoded    Pointer to the output buffer
    // cbEncoded    The size of the output buffer
    // pcbEncoded   Pointer to the count of bytes produced
    //
    if ( NULL == pbBytes )
        throw invalid_argument( "pbBytes" );

    if ( cbBytes <= 0 )
        throw invalid_argument( "cbBytes" );

    // Calculate encoded string size including padding. The computation
    // is the number of byte triples times 4 radix64 characters plus 1 for null termination.
    size_t encodedSize = 1 + ( cbBytes + 2 ) / 3 * 4;

    if ( pcbEncoded )
        *pcbEncoded = encodedSize;

    // Request for buffer size
    if ( NULL == pbEncoded && 0 == cbEncoded )
        return true;

    // Must have buffer now, and sufficient space
    if ( NULL == pbEncoded )
        throw invalid_argument( "pbEncoded" );

    if ( encodedSize > cbEncoded )
        throw invalid_argument( "cbEncoded too small" );

    // Encode data byte triplets into four-byte clusters.
    int    iBytes;      // raw byte index
    int    iEncoded;    // encoded byte index
    byte_t b0, b1, b2;  // individual bytes for triplet

    iBytes = iEncoded = 0;

    while ( iBytes < cbBytes )
    {
        b0 = pbBytes[iBytes++];
        b1 = (iBytes < cbBytes) ? pbBytes[iBytes++] : 0;                                     // Add extra zero byte if needed
        b2 = (iBytes < cbBytes) ? pbBytes[iBytes++] : 0;                                     // Add extra zero byte if needed

        __analysis_assume( iEncoded + 4 <= encodedSize );

        pbEncoded[iEncoded++] = base64EncodeTable[b0 >> 2];                                  // 6 MSB from byte 0
        pbEncoded[iEncoded++] = base64EncodeTable[((b0 << 4) & 0x30) | ((b1 >> 4) & 0x0f)];  // 2 LSB from byte 0 and 4 MSB from byte 1
        pbEncoded[iEncoded++] = base64EncodeTable[((b1 << 2) & 0x3c) | ((b2 >> 6) & 0x03)];  // 4 LSB from byte 1 and 2 MSB from byte 2
        pbEncoded[iEncoded++] = base64EncodeTable[b2 & 0x3f];                                // 6 LSB from byte 2
    }

    // Now determine padding
    switch ( cbBytes % 3 )
    {
    case 0:
        // No left overs, nothing to pad
        break;

    case 1:
        // One left over, normally pad 2
        pbEncoded[iEncoded - 2] = '=';
        // fall through

    case 2:
        pbEncoded[iEncoded - 1] = '=';
        break;
    }

    // Null-terminate the encoded string.
    __analysis_assume( iEncoded + 1 <= encodedSize );

    pbEncoded[iEncoded++] = '\0';

    return true;
}

vector<akv::byte_t> Base64::decode( const akv::string_t& encodedString )
{
    vector<akv::byte_t> decoded;

    if ( encodedString.size() > 0 )
    {
        // Get to a narrow string
        std::string encoded   = to_string( encodedString );
        size_t      cbDecoded = 0;

        // Get the size of the output buffer
        if ( decode( encoded.data(), encoded.size(), (akv::byte_t *)NULL, 0, &cbDecoded ) )
        {
            decoded.resize( cbDecoded );

            if ( !decode( encoded.data(), encoded.size(), decoded.data(), decoded.size(), &cbDecoded ) )
                throw runtime_error( "Base64::decode failed" );
        }
    }

    return decoded;
}

#if TARGET_OS_WIN32
// Allow for SAL annotations
bool Base64::decode( _In_reads_bytes_(cbEncoded) const char *pbEncoded, _In_ size_t cbEncoded, _Out_writes_bytes_to_opt_(cbDecoded,*pcbDecoded) akv::byte_t *pbDecoded, _In_ size_t cbDecoded, _Out_opt_ size_t *pcbDecoded )
#else
bool Base64::decode( const char *pbEncoded, size_t cbEncoded, akv::byte_t *pbDecoded, size_t cbDecoded, size_t *pcbDecoded )
#endif
{
    // Decode a Base64 encoded string.

    if ( NULL == pbEncoded )
        throw invalid_argument( "pbEncoded" );

    size_t  cbPadding;
    size_t  cbDecodedSize;
    uint8_t b0, b1, b2, b3;

    // Input string is not sized correctly to be base64.
    if ( ( 0 == cbEncoded ) || ( 0 != ( cbEncoded % 4 ) ) )
        throw invalid_argument( "cbEncoded" );

    // Count the padding starting from the end of the string.
    for ( cbPadding = cbEncoded - 1; pbEncoded[cbPadding] == '='; cbPadding-- );

    // Calculate decoded buffer size as 4/3 the encoded size
    cbPadding      = cbEncoded - 1 - cbPadding;
    cbDecodedSize  = ( cbEncoded + 3 ) / 4 * 3;
    cbDecodedSize -= cbPadding;

    // Set returned calculated size
    if ( NULL != pcbDecoded )
        *pcbDecoded = cbDecodedSize;

    // if no buffer, then tell the caller how much they need
    if ( NULL == pbDecoded && cbDecoded == 0 )
        return true;

    // must have buffer now
    if ( NULL == pbDecoded )
        throw invalid_argument( "pbDecoded" );

    // Supplied buffer is too small.
    if ( cbDecodedSize > cbDecoded )
        throw invalid_argument( "cbDecoded" );

    // Decode each four-byte cluster into the corresponding three data bytes,
    // allowing for the fact that the last cluster may be padding and we 
    // cannot go past the computed decoded size.
    int iEncoded = 0;
    int iDecoded = 0;

    while ( iEncoded < cbEncoded )
    {
        b0 = DECODE(pbEncoded[iEncoded]); iEncoded++;
        b1 = (iEncoded < cbEncoded) ? DECODE(pbEncoded[iEncoded]) : 0; iEncoded++;
        b2 = (iEncoded < cbEncoded) ? DECODE(pbEncoded[iEncoded]) : 0; iEncoded++;
        b3 = (iEncoded < cbEncoded) ? DECODE(pbEncoded[iEncoded]) : 0; iEncoded++;

        // Contents of input string are not base64.
        if ( ( NA == b0 ) || ( NA == b1 ) || ( NA == b2 ) || ( NA == b3 ) )
            throw invalid_argument( "pbEncoded" );

        pbDecoded[iDecoded++] = (uint8_t)( (b0 << 2) | (b1 >> 4) );

        if (iDecoded < cbDecodedSize) {
            pbDecoded[iDecoded++] = (uint8_t)( (b1 << 4) | (b2 >> 2) );

            if (iDecoded < cbDecodedSize) {
                pbDecoded[iDecoded++] = (uint8_t)( (b2 << 6) | b3 );
            }
        }
    }

    return true;
}

akv::string_t Base64::encode_url( const std::vector<akv::byte_t>& bytes )
{
    akv::string_t result;

    if ( bytes.size() > 0 )
    {
        size_t cbEncoded = 0;

        // determine the size of the buffer
        if ( encode_url( bytes.data(), bytes.size(), NULL, 0, &cbEncoded ) )
        {
            // allocate space for the buffer
            unique_ptr<akv::byte_t[]> pbEncoded( new akv::byte_t[cbEncoded] );

            // convert to base-64url
            if ( encode_url( bytes.data(), bytes.size(), pbEncoded.get(), cbEncoded, &cbEncoded ) )
            {
                // WARNING: The result of the encode is a null terminated string that is
                //          _at_most_ cbEncoded bytes. It's therefore important to
                //          reconstitute the akv::string_t from the raw c ptr.
                result = to_platform_string( pbEncoded.get() );
            }
        }
    }

    return result;
}

/// <summary>
/// Base64 URL encode a set of bytes.
/// </summary>
/// <remarks>
/// See RFC 4648, Section 5 plus switch characters 62 and 63 and no padding.
/// For a good overview of Base64 encoding, see http://en.wikipedia.org/wiki/Base64
/// </remarks>
#if TARGET_OS_WIN32
// Allow for SAL annotations
bool Base64::encode_url( _In_reads_bytes_(cbBytes) const akv::byte_t *pbBytes, _In_ size_t cbBytes, _Out_writes_bytes_to_opt_(cbEncoded,*pcbEncoded) akv::byte_t *pbEncoded, _In_ size_t cbEncoded, _Out_opt_ size_t *pcbEncoded )
#else
bool Base64::encode_url( const akv::byte_t *pbBytes, size_t cbBytes, akv::byte_t *pbEncoded, size_t cbEncoded, size_t *pcbEncoded )
#endif
{
    //
    // Parameters:
    //
    // pbBytes      Pointer to the buffer of bytes to encode
    // cbBytes      The count of bytes in the input buffer
    // pbEncoded    Pointer to the output buffer
    // cbEncoded    The size of the output buffer
    // pcbEncoded   Pointer to the count of bytes produced
    //
    if ( NULL == pbBytes )
        throw invalid_argument( "pbBytes" );

    if ( cbBytes <= 0 )
        throw invalid_argument( "cbBytes" );

    // Calculate encoded string size including padding. This may be more than is actually
    // required since we will not pad and instead will terminate with null. The computation
    // is the number of byte triples times 4 radix64 characters plus 1 for null termination.
    size_t encodedSize = 1 + ( cbBytes + 2 ) / 3 * 4;

    if ( pcbEncoded )
        *pcbEncoded = encodedSize;

    // Request for buffer size
    if ( NULL == pbEncoded && 0 == cbEncoded )
        return true;

    // Must have buffer now, and sufficient space
    if ( NULL == pbEncoded )
        throw invalid_argument( "pbEncoded" );

    if ( encodedSize > cbEncoded )
        throw invalid_argument( "cbEncoded too small" );

    // Encode data byte triplets into four-byte clusters.
    int    iBytes;      // raw byte index
    int    iEncoded;    // encoded byte index
    byte_t b0, b1, b2;  // individual bytes for triplet

    iBytes = iEncoded = 0;

    while ( iBytes < cbBytes )
    {
        b0 = pbBytes[iBytes++];
        b1 = (iBytes < cbBytes) ? pbBytes[iBytes++] : 0;                                        // Add extra zero byte if needed
        b2 = (iBytes < cbBytes) ? pbBytes[iBytes++] : 0;                                        // Add extra zero byte if needed

        __analysis_assume( iEncoded + 4 <= encodedSize );

        pbEncoded[iEncoded++] = base64encode_urlTable[b0 >> 2];                                  // 6 MSB from byte 0
        pbEncoded[iEncoded++] = base64encode_urlTable[((b0 << 4) & 0x30) | ((b1 >> 4) & 0x0f)];  // 2 LSB from byte 0 and 4 MSB from byte 1
        pbEncoded[iEncoded++] = base64encode_urlTable[((b1 << 2) & 0x3c) | ((b2 >> 6) & 0x03)];  // 4 LSB from byte 1 and 2 MSB from byte 2
        pbEncoded[iEncoded++] = base64encode_urlTable[b2 & 0x3f];                                // 6 LSB from byte 2
    }

    // Where we would have padded it, we instead truncate the string
    switch ( cbBytes % 3 )
    {
    case 0:
        // No left overs, nothing to pad
        break;

    case 1:
        // One left over, normally pad 2
        pbEncoded[iEncoded - 2] = '\0';
        // fall through

    case 2:
        pbEncoded[iEncoded - 1] = '\0';
        break;
    }

    // Null-terminate the encoded string.
    __analysis_assume( iEncoded + 1 <= encodedSize );

    pbEncoded[iEncoded++] = '\0';

    return true;
}

vector<akv::byte_t> Base64::decode_url( const akv::string_t& encodedString )
{
    vector<akv::byte_t> decoded;

    if ( encodedString.size() > 0 )
    {
        // Get to a narrow string
        auto   encoded   = to_string( encodedString );
        size_t cbDecoded = 0;

        // Get the buffer size
        if ( decode_url( encoded.data(), encoded.size(), (byte_t *)NULL, 0, &cbDecoded ) )
        {
            decoded.resize( cbDecoded );

            // decode
            decode_url( encoded.data(), encoded.size(), decoded.data(), decoded.size(), &cbDecoded );
        }
    }

    return decoded;
}

#if TARGET_OS_WIN32
// Allow for SAL annotations
bool Base64::decode_url( _In_reads_bytes_(cbEncoded) const char *pbEncoded, _In_ size_t cbEncoded, _Out_writes_bytes_to_opt_(cbDecoded,*pcbDecoded) akv::byte_t *pbDecoded, _In_ size_t cbDecoded, _Out_opt_ size_t *pcbDecoded )
#else
bool Base64::decode_url( const char *pbEncoded, size_t cbEncoded, akv::byte_t *pbDecoded, size_t cbDecoded, size_t *pcbDecoded )
#endif
{
    /*
    Routine Description:

    Decode a base64url-encoded string.

    This function follows RFC 4648, section 5, and has the following differences
    from a 'normal' base-64 encoder:
    (1) it expects - instead of + and _ instead of /
    (2) it does not expect the trailing = padding

    --*/
    if ( NULL == pbEncoded )
        throw invalid_argument( "pbEncoded" );

    size_t  cbDecodedSize;
    int     ich;
    int     ib;
    uint8_t b0, b1, b2, b3;

    // The input string lacks the usual '=' padding at the end, so the valid end sequences
    // are:
    //      ........XX           (cbEncodedSize % 4) == 2    (2 chars of virtual padding)
    //      ........XXX          (cbEncodedSize % 4) == 3    (1 char of virtual padding)
    //      ........XXXX         (cbEncodedSize % 4) == 0    (no virtual padding)
    // Invalid sequences are:
    //      ........X            (cbEncodedSize % 4) == 1

    // Input string is not sized correctly to be base64.
    if ( ( 0 == cbEncoded ) || ( 1 == ( cbEncoded % 4 ) ) )
        throw invalid_argument( "cbEncoded" );

    // 'virtual padding' is how many trailing '=' characters we would have
    // had under 'normal' base-64 encoding
    int virtualPadding = ( ( cbEncoded % 4 ) == 2 ) ? 2 : ( ( cbEncoded % 4 ) == 3 ) ? 1 : 0;

    // Calculate decoded buffer size.
    cbDecodedSize = (cbEncoded + virtualPadding + 3) / 4 * 3;
    cbDecodedSize -= virtualPadding;

    // Set returned calculated size
    if ( NULL != pcbDecoded )
        *pcbDecoded = cbDecodedSize;

    // if no buffer, then tell the caller how much they need
    if ( NULL == pbDecoded && cbDecoded == 0 )
        return true;

    // must have buffer now
    if ( NULL == pbDecoded )
        throw invalid_argument( "pbDecoded" );

    // Supplied buffer is too small.
    if ( cbDecodedSize > cbDecoded )
        throw invalid_argument( "cbDecoded" );

    // Decode each four-byte cluster into the corresponding three data bytes,
    // allowing for the fact that the last cluster may be less than four bytes
    // (virtual padding).
    ich = ib = 0;

    while ( ich < cbEncoded )
    {
        b0 = DECODE_URL(pbEncoded[ich]); ich++;
        b1 = (ich < cbEncoded) ? DECODE_URL(pbEncoded[ich]) : 0; ich++;
        b2 = (ich < cbEncoded) ? DECODE_URL(pbEncoded[ich]) : 0; ich++;
        b3 = (ich < cbEncoded) ? DECODE_URL(pbEncoded[ich]) : 0; ich++;

        // Contents of input string are not base64.
        if ( ( NA == b0 ) || ( NA == b1 ) || ( NA == b2 ) || ( NA == b3 ) )
            throw invalid_argument( "pbEncoded" );

        pbDecoded[ib++] = (uint8_t)( (b0 << 2) | (b1 >> 4) );

        if (ib < cbDecodedSize) {
            pbDecoded[ib++] = (uint8_t)( (b1 << 4) | (b2 >> 2) );

            if (ib < cbDecodedSize) {
                pbDecoded[ib++] = (uint8_t)( (b2 << 6) | b3 );
            }
        }
    }

    return true;
}

} }
