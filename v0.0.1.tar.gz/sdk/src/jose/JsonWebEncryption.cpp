/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"
#include "akv/akv_cryptography.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/jose/JweFormatException.h"

#include "akv/jose/JweHeader.h"

#include "akv/jose/JweObject.h"

#include "akv/jose/JsonWebEncryption.h"

using namespace akv;
using namespace akv::common;
using namespace akv::cryptography;
using namespace std;
using namespace pplx;

namespace akv { namespace jose {

static const akv::string_t DirectAlgorithm( __T("dir") );

pplx::task<std::shared_ptr<JweObject>> JsonWebEncryption::protect( const IKey&                     dataEncryptionKey,
                                                       const akv::string_t&             dataEncryptionAlgorithm,
                                                       const std::vector<akv::byte_t>&   plaintext,
                                                       const pplx::cancellation_token& cancellationToken )
{
    if ( dataEncryptionAlgorithm.empty() )
        throw invalid_argument( "dataEncryptionAlgorithm" );

    if ( plaintext.size() == 0 )
        throw invalid_argument( "plaintext" );

    // Create the headers with the encryption parameters.
    shared_ptr<JweObject> jwe = CreateHeader( dataEncryptionKey.kid(), DirectAlgorithm, dataEncryptionAlgorithm );

    // In Direct Encryption mode, the content encryption key is the key provided by the caller
    // and there is no wrapped key in the output. The provided data encryption key must be a symmetric encryption key.

    // Generate an iv for the encryption
    vector<akv::byte_t> iv( 16 );

    RandomNumberGenerator::get_bytes( iv );

    jwe->iv( iv );

    // TODO: Correctly handle the AAD case
    return dataEncryptionKey.encrypt( dataEncryptionAlgorithm, plaintext, jwe->iv(), get_bytes( jwe->protected_header_encoded() ), cancellationToken ).then( [jwe]( IKey::EncryptResult result )
    {
        jwe->ciphertext( result.value );
        jwe->authentication_tag( result.tag );

        return jwe;
    }, cancellationToken );
}

pplx::task<shared_ptr<JweObject>> JsonWebEncryption::protect( const IKey&                     keyEncryptionKey,
                                                                   const akv::string_t&            keyEncryptionAlgorithm,
                                                                   const akv::string_t&            dataEncryptionAlgorithm,
                                                                   const std::vector<akv::byte_t>& plaintext,
                                                                   const pplx::cancellation_token& cancellationToken )
{
    // Generate sufficient key material for any of the possible algorithms
    vector<akv::byte_t> dataEncryptionKey( 512 >> 3 );

    RandomNumberGenerator::get_bytes( dataEncryptionKey );

    return protect( keyEncryptionKey, keyEncryptionAlgorithm, dataEncryptionKey, dataEncryptionAlgorithm, plaintext, cancellationToken );
}

pplx::task<shared_ptr<JweObject>> JsonWebEncryption::protect( const IKey&                     keyEncryptionKey,
                                                       const akv::string_t&            keyEncryptionAlgorithm,
                                                       const vector<akv::byte_t>&      dataEncryptionKey,
                                                       const akv::string_t&            dataEncryptionAlgorithm,
                                                       const std::vector<akv::byte_t>& plaintext,
                                                       const pplx::cancellation_token& cancellationToken )
{
    if ( keyEncryptionAlgorithm.empty() )
        throw invalid_argument( "keyEncryptionAlgorithm" );

    if ( dataEncryptionKey.empty() )
        throw invalid_argument( "dataEncryptionKey" );

    if ( dataEncryptionAlgorithm.empty() )
        throw invalid_argument( "dataEncryptionAlgorithm" );

    if ( plaintext.empty() )
        throw invalid_argument( "plaintext" );

    // Create the headers with the encryption parameters.
    shared_ptr<JweObject> jwe = JsonWebEncryption::CreateHeader( keyEncryptionKey.kid(), keyEncryptionAlgorithm, dataEncryptionAlgorithm );

    // In Key Wrapping mode, the key encryption key is used to protect the data encryption key and the encrypted key
    // is carried in the final package. So the first step is to wrap the data encryption key.
    return keyEncryptionKey.wrap( keyEncryptionAlgorithm, dataEncryptionKey, cancellationToken ).then( [dataEncryptionKey, dataEncryptionAlgorithm, plaintext, jwe, cancellationToken]( IKey::WrapResult encryptedKey )
    {
        // Remember the wrapped key and generate an iv for the data encryption
        jwe->encrypted_key( encryptedKey.value );

        vector<akv::byte_t> iv( 16 );

        RandomNumberGenerator::get_bytes( iv );

        jwe->iv( iv );

        // Build a symmetric key object and use that to encrypt the plaintext
        SymmetricKey key( __T("cek"), dataEncryptionKey );

        // TODO: Correctly handle the AAD case
        return key.encrypt( dataEncryptionAlgorithm, plaintext, jwe->iv(), get_bytes( jwe->protected_header_encoded() ), cancellationToken ).then( [jwe]( IKey::EncryptResult result ) -> shared_ptr<JweObject>
        {
            // Remember the ciphertext and the authentication tag
            jwe->ciphertext( result.value );
            jwe->authentication_tag( result.tag );

            return jwe;
        }, cancellationToken );
    }, cancellationToken );
}

pplx::task<akv::string_t> JsonWebEncryption::protect_compact( const IKey & dataEncryptionKey,
                                                                 const akv::string_t& dataEncryptionAlgorithm,
                                                                 const std::vector<akv::byte_t>& plaintext,
                                                                 const pplx::cancellation_token& cancellationToken )
{
    return protect( dataEncryptionKey, dataEncryptionAlgorithm, plaintext, cancellationToken ).then( []( shared_ptr<JweObject> taskResult )
    {
        return taskResult->to_compact_jwe();
    }, cancellationToken );
}

pplx::task<akv::string_t> JsonWebEncryption::protect_compact( const IKey & keyEncryptionKey,
                                                                 const akv::string_t & keyEncryptionAlgorithm,
                                                                 const akv::string_t& dataEncryptionAlgorithm,
                                                                 const std::vector<akv::byte_t>& plaintext, 
                                                                 const pplx::cancellation_token& cancellationToken )
{
    return protect( keyEncryptionKey, keyEncryptionAlgorithm, dataEncryptionAlgorithm, plaintext, cancellationToken ).then( []( shared_ptr<JweObject> taskResult )
    {
        return taskResult->to_compact_jwe();
    }, cancellationToken );
}

pplx::task<akv::string_t> JsonWebEncryption::protect_compact( const IKey&                     keyEncryptionKey,
                                                              const akv::string_t&            keyEncryptionAlgorithm,
                                                              const std::vector<akv::byte_t>& dataEncryptionKey,
                                                              const akv::string_t&            dataEncryptionAlgorithm,
                                                              const std::vector<akv::byte_t>& plaintext,
                                                              const pplx::cancellation_token& cancellationToken )
{
    return protect( keyEncryptionKey, keyEncryptionAlgorithm, dataEncryptionKey, dataEncryptionAlgorithm, plaintext, cancellationToken ).then( []( shared_ptr<JweObject> taskResult )
    {
        return taskResult->to_compact_jwe();
    }, cancellationToken );
}

pplx::task<std::vector<akv::byte_t>> JsonWebEncryption::unprotect( const IKeyResolver&              keyResolver,
                                                                   const std::shared_ptr<JweObject> jwe,
                                                                   const pplx::cancellation_token&  cancellationToken )
{
    if ( jwe->protected_header_encoded().empty() )
        throw invalid_argument( "Protected header is empty" );

    akv::string_t         protectedHeaderEncoded;
    shared_ptr<JweHeader> protectedHeader;

    // Deserialize the header. For security, we ignore jwe.Unprotected.
    protectedHeaderEncoded = jwe->protected_header_encoded();

    // TODO: This can throw. Note that if it succeeds, then it won't
    //       be a nullptr since ProtectedEncoded was not empty
    protectedHeader        = jwe->protected_header();

    if ( protectedHeader->algorithm().empty() || protectedHeader->encryption_algorithm().empty() || protectedHeader->kid().empty() )
        throw JweFormatException( __T( "Malformed protected header" ) );

    // Step 1: Resolve the protection key
    auto baseKey = keyResolver.resolve_key( protectedHeader->kid(), cancellationToken ).get();

    // TODO: Ugh, std::string and std::wstring
    if ( baseKey == nullptr )
        throw JweFormatException( __T("The resolver was unable to resolve key with Kid ") + protectedHeader->kid() );

    // Step 2: Unwrap the CEK according to the specified Key Management Mode
    shared_ptr<IKey> dataEncryptionKey;

    // TODO: lower case compare
    if ( protectedHeader->algorithm().compare( DirectAlgorithm ) == 0 )
    {
        // Direct Encryption
        //if ( encryptedKeyEncoded.empty() )
        //    throw JweFormatException( "Bad JWE value: uses direct encryption, but contains wrapped key." );

        dataEncryptionKey = baseKey;
    }
    else
    {
        // Some form of Key Wrapping algorithm
        auto dataEncryptionKeyBytes = baseKey->unwrap( protectedHeader->algorithm(), jwe->encrypted_key(), cancellationToken ).get();

        if ( dataEncryptionKeyBytes.value.size() == 0 )
            throw JweFormatException( __T( "Unable to unwrap the encryption key" ) );

        dataEncryptionKey.reset( new SymmetricKey( __T("cek"), dataEncryptionKeyBytes.value ) );
    }

    // Step 2: Decrypt
    // TODO: Correctly handle the AAD case
    return dataEncryptionKey->decrypt( protectedHeader->encryption_algorithm(), jwe->ciphertext(), jwe->iv(), get_bytes( protectedHeaderEncoded ), jwe->authentication_tag(), cancellationToken ).then( [](IKey::DecryptResult result )
    {
        return result.value;
    }, cancellationToken );
}

pplx::task<std::vector<akv::byte_t>> JsonWebEncryption::unprotect_compact( const IKeyResolver& resolver,
                                                                             const akv::string_t& compactJwe,
                                                                             const pplx::cancellation_token& cancellationToken )
{
    if ( compactJwe.empty() || compactJwe.size() == 0 )
        throw invalid_argument( "compactJwe" );

    auto jwe = JweObject::from_compact_jwe( compactJwe );

    return unprotect( resolver, jwe, cancellationToken );

}

std::shared_ptr<JweObject> JsonWebEncryption::CreateHeader( const akv::string_t& kid, const akv::string_t& algorithm, const akv::string_t& encryptionAlgorithm )
{
    // Create the protected header
    shared_ptr<JweHeader> header( new JweHeader() );

    header->kid( kid );
    header->algorithm( algorithm );
    header->encryption_algorithm( encryptionAlgorithm );

    // Create the object
    shared_ptr<JweObject> object( new JweObject() );

    object->protected_header( header );

    return object;
}

} }
