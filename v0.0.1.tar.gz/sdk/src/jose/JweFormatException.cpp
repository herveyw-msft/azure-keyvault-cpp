/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/jose/JweFormatException.h"

using namespace std;

namespace akv { namespace jose {

struct JweFormatException::State
{
    unsigned short _status;
    akv::string_t  _error;
    akv::string_t  _error_description;
};

JweFormatException::JweFormatException( const akv::string_t& error )
{
    unique_ptr<State> state( new State() );

    state->_error  = error;

    _state = state.release();
}

JweFormatException::JweFormatException( const akv::string_t& error, const akv::string_t& error_description )
{    
    unique_ptr<State> state( new State() );

    state->_error             = error;
    state->_error_description = error_description;

    _state = state.release();
}

JweFormatException::JweFormatException( const JweFormatException& other )
{
    unique_ptr<State> state( new State() );

    state->_error             = other._state->_error;
    state->_error_description = other._state->_error_description;
    state->_status            = other._state->_status;

    _state = state.release();
}

JweFormatException& JweFormatException::operator = ( const JweFormatException& other )
{
    _state->_error             = other._state->_error;
    _state->_error_description = other._state->_error_description;

    return *this;
}

JweFormatException::JweFormatException( JweFormatException&& other )
{
    _state = other._state;
    other._state = NULL;
}

JweFormatException& JweFormatException::operator = ( JweFormatException&& other )
{
    _state = other._state;
    other._state = NULL;

    return *this;
}

JweFormatException::~JweFormatException()
{
    if ( _state != NULL ) delete _state;
}

const akv::string_t& JweFormatException::error() const
{
    return _state->_error;
}

const akv::string_t& JweFormatException::error_description() const
{
    return _state->_error_description;
}


} }
