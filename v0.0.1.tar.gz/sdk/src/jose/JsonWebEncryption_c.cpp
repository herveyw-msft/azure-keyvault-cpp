/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"
#include "akv/akv_cryptography.h"

#include "akv/jose/JweHeader.h"
#include "akv/jose/JweObject.h"
#include "akv/jose/JsonWebEncryption.h"

using namespace akv;
using namespace akv::cryptography;
using namespace akv::jose;
using namespace std;
using namespace pplx;

#if TARGET_OS_WIN32

namespace
{
    unique_ptr<IKeyResolver> get_key_resolver()
    {
        unique_ptr<IKeyResolver> userStore = make_unique<CertificateStoreKeyResolver>(CertificateStoreKeyResolver::CurrentUser(), L"My");
        unique_ptr<IKeyResolver> machineStore;
        try
        {
            machineStore = make_unique<CertificateStoreKeyResolver>(CertificateStoreKeyResolver::LocalMachine(), L"My");
        }
        catch (const runtime_error&)
        {
            // if we can't open machine store, fall back to user store
            return userStore;
        }

        return make_unique<CombinedKeyResolver>(move(machineStore), move(userStore));
    }
}

extern "C"
{
    HRESULT AKV_EXPORT UnprotectCompact( PCWCHAR pProtected, size_t cbProtected, PBYTE *ppUnprotected, size_t *cbUnprotected )
    {
        // TODO: Validate parameters
        *ppUnprotected = NULL;
        *cbUnprotected = 0;

        akv::string_t compactJwe( pProtected, pProtected + cbProtected );

        cancellation_token_source   cts;
        cancellation_token          cancellationToken = cts.get_token();

        std::unique_ptr<IKeyResolver> resolver = get_key_resolver();
    
        return JsonWebEncryption::unprotect_compact( *resolver, compactJwe, cancellationToken )
            .then( [ppUnprotected, cbUnprotected]( const std::vector<akv::byte_t>& result ) -> HRESULT
            {
                // Assuming all went well...
                auto heap = ::GetProcessHeap();

                if ( nullptr != heap )
                {
                    *ppUnprotected = (PBYTE)::HeapAlloc( heap, HEAP_ZERO_MEMORY, result.size() );

                    if ( nullptr != *ppUnprotected )
                    {
                        *cbUnprotected = result.size();

                        // Copy the data
                        memcpy_s( *ppUnprotected, *cbUnprotected, result.data(), result.size() );

                        return S_OK;
                    }
                }

                return S_FALSE;
            }).get();
    }

    void AKV_EXPORT FreeUnprotectedBuffer( const PBYTE pUnprotected, size_t cbUnprotected )
    {
        // TODO: Parameter validation
        if ( nullptr != pUnprotected )
        {
            auto hHeap = ::GetProcessHeap();

            if ( nullptr != hHeap )
            {
                ::SecureZeroMemory( pUnprotected, cbUnprotected );
                ::HeapFree( hHeap, 0, pUnprotected );
            }
        }
    }

}

#endif
