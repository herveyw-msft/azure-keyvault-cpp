
#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/jose/JwsHeader.h"

using namespace std;
using namespace web;
using namespace akv;

namespace akv { namespace jose {

struct JwsHeader::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    akv::string_t                   _kid;
    akv::string_t                   _algorithm;
    map<akv::string_t, json::value> _properties;
};

shared_ptr<JwsHeader> JwsHeader::from_compact_header( const akv::string_t& compactHeader )
{
    if ( compactHeader.empty() ) throw invalid_argument( "compactHeader" );

    shared_ptr<JwsHeader> result( new JwsHeader() );

    // Decode from Base64Url to obtain a vector<byte> representing the
    // ASCII encoded characters of the serialized header.
    auto header = common::to_platform_string( common::Base64::decode_url( compactHeader ) );
    auto value  = json::value::parse( header );

    if ( value.is_object() )
    {
        auto object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T( "alg" ) ) == 0 )
            {
                result->_state->_algorithm = field->second.as_string();
            }
            else if ( field->first.compare( __T( "kid" ) ) == 0 )
            {
                result->_state->_kid = field->second.as_string();
            }
            else
            {
                // Unrecognized values go to the property bag
                result->_state->_properties[field->first] = field->second;
            }
        }
    }

    return result;
}

JwsHeader::JwsHeader()
{
    _state = new State();
}

JwsHeader::JwsHeader( const JwsHeader& other )
{
    _state = new State( *other._state );
}

JwsHeader::JwsHeader( JwsHeader&& other )
{
    _state = other._state;
    other._state = NULL;
}

JwsHeader& JwsHeader::operator = ( const JwsHeader &other )
{
    _state->operator = ( *other._state );

    return *this;
}

JwsHeader& JwsHeader::operator = ( JwsHeader&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

JwsHeader::~JwsHeader()
{
    if ( _state != NULL ) delete _state;
}

const akv::string_t& JwsHeader::kid() const
{
    return _state->_kid;
}

void JwsHeader::kid( const akv::string_t& kid )
{
    _state->_kid = kid;
}

const akv::string_t& JwsHeader::algorithm() const
{
    return _state->_algorithm;
}

void JwsHeader::algorithm( const akv::string_t& algorithm )
{
    _state->_algorithm = algorithm;
}

void JwsHeader::add_property( const akv::string_t& name, const web::json::value& value )
{
    // Check for reserved names
    if ( name == __T( "alg" ) || name == __T( "kid" ) )
        throw invalid_argument( "name is reserved" );

    _state->_properties[name] = value;
}

json::value JwsHeader::get_property( const akv::string_t& name ) const
{
    return _state->_properties[name];
}

bool JwsHeader::has_property( const akv::string_t& name ) const
{
    return _state->_properties.count( name ) == 1;
}

void JwsHeader::remove_property( const akv::string_t& name )
{
    _state->_properties.erase( name );
}

bool JwsHeader::empty() const
{
    return _state->_algorithm.empty() && _state->_kid.empty() && _state->_properties.empty();
}

akv::string_t JwsHeader::to_compact_header() const
{
    return common::Base64::encode_url( common::get_bytes( to_string() ) );
}

akv::string_t JwsHeader::to_string() const
{
    akv::string_t result;

    result.append( __T("{ \"alg\":\"" ) + _state->_algorithm + __T("\"") );
    result.append( __T(",\"kid\":\"" )  + _state->_kid      + __T("\"") );

    if ( !_state->_properties.empty() )
    {
        // Emit other properties
        for( const auto& pair : _state->_properties )
        {
            result.append( __T( ",\"" ) + pair.first + __T( "\":" ) + pair.second.serialize() );
        }
    }

    // Close the object
    result.append( __T( "}" ) );

    return result;
}

} }
