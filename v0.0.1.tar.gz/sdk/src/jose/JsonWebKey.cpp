
#include "precomp.h"

#include "common/vector.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/cryptography/RsaParameters.h"

#include "akv/jose/JsonWebKey.h"

using namespace std;
using namespace web;
using namespace akv::common;
using namespace akv::cryptography;

namespace akv { namespace jose {

// Key types
static const akv::string_t _Rsa( __T("RSA") );
static const akv::string_t _RsaHsm( __T("RSA-HSM") );

const akv::string_t & jose::JsonWebKey::KeyTypes::Rsa()
{
    return _Rsa;
}

const akv::string_t & jose::JsonWebKey::KeyTypes::RsaHsm()
{
    return _RsaHsm;
}

// Key operations
static const akv::string_t _Encrypt( __T("encrypt") );
static const akv::string_t _Decrypt( __T("decrypt") );
static const akv::string_t _WrapKey( __T("wrapKey") );
static const akv::string_t _UnwrapKey( __T("unwrapKey") );
static const akv::string_t _Sign( __T("sign") );
static const akv::string_t _Verify( __T("verify") );

const akv::string_t & jose::JsonWebKey::KeyOperations::Encrypt()
{
    return _Encrypt;
}

const akv::string_t & jose::JsonWebKey::KeyOperations::Decrypt()
{
    return _Decrypt;
}

const akv::string_t & jose::JsonWebKey::KeyOperations::WrapKey()
{
    return _WrapKey;
}

const akv::string_t & jose::JsonWebKey::KeyOperations::UnwrapKey()
{
    return _UnwrapKey;
}

const akv::string_t & jose::JsonWebKey::KeyOperations::Sign()
{
    return _Sign;
}

const akv::string_t & jose::JsonWebKey::KeyOperations::Verify()
{
    return _Verify;
}

struct JsonWebKey::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()
    {
        SecureZeroMemory(_d),
        SecureZeroMemory(_p),
        SecureZeroMemory(_q),
        SecureZeroMemory(_dp),
        SecureZeroMemory(_dq),
        SecureZeroMemory(_qi),

        SecureZeroMemory(_k);
    }

    akv::string_t                     _kid;
    akv::string_t                     _kty;
    std::unordered_set<akv::string_t> _key_ops;

    // RSA public parameters
    std::vector<akv::byte_t> _n;
    std::vector<akv::byte_t> _e;

    // RSA private parameters
    std::vector<akv::byte_t> _d;
    std::vector<akv::byte_t> _p;
    std::vector<akv::byte_t> _q;
    std::vector<akv::byte_t> _dp;
    std::vector<akv::byte_t> _dq;
    std::vector<akv::byte_t> _qi;

    // Octet parameters
    std::vector<akv::byte_t> _k;
};

shared_ptr<JsonWebKey> JsonWebKey::from_string( const akv::string_t& str )
{
    // TODO: Check for errors from parsing
    std::error_code error;
    auto            value = web::json::value::parse( str, error );

    return JsonWebKey::from_json( value );
}

shared_ptr<JsonWebKey> JsonWebKey::from_json( const web::json::value& value )
{
    shared_ptr<JsonWebKey> result( nullptr );

    if ( value.is_object() )
    {
        auto object = value.as_object();

        result.reset( new JsonWebKey() );

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            // Key identifier
            if ( field->first.compare( __T("kid") ) == 0 )
                result->_state->_kid = field->second.as_string();
            // Key Type
            else if ( field->first.compare( __T("kty") ) == 0 )
                result->_state->_kty = field->second.as_string();
            // Key Operations
            else if ( field->first.compare( __T("key_ops") ) == 0 )
            {
                auto array = field->second.as_array();

                for ( auto elem = array.cbegin(); elem != array.cend(); elem++ )
                {
                    result->_state->_key_ops.insert( elem->as_string() );
                }
            }

            // RSA Public key parameters
            else if ( field->first.compare( __T("n") ) == 0 )
                result->_state->_n = Base64::decode_url( field->second.as_string() );
            else if ( field->first.compare( __T("e") ) == 0 )
                result->_state->_e = Base64::decode_url( field->second.as_string() );

            // RSA private key parameters
            else if ( field->first.compare( __T("d") ) == 0 )
                result->_state->_d = Base64::decode_url( field->second.as_string() );
            else if ( field->first.compare( __T("p") ) == 0 )
                result->_state->_p = Base64::decode_url( field->second.as_string() );
            else if ( field->first.compare( __T("q") ) == 0 )
                result->_state->_q = Base64::decode_url( field->second.as_string() );
            else if ( field->first.compare( __T("dp") ) == 0 )
                result->_state->_dp = Base64::decode_url( field->second.as_string() );
            else if ( field->first.compare( __T("dq") ) == 0 )
                result->_state->_dq = Base64::decode_url( field->second.as_string() );
            else if ( field->first.compare( __T("qi") ) == 0 )
                result->_state->_qi = Base64::decode_url( field->second.as_string() );

            // octet parameters
            else if ( field->first.compare( __T("k") ) == 0 )
                result->_state->_k = Base64::decode_url( field->second.as_string() );
        }

        if ( result->_state->_kty.empty() )
            throw invalid_argument( "value" );

        if ( akv::common::starts_with( result->_state->_kty, akv::string_t(__T("RSA") ) ) )
        {
            // MUST have public key parameters
            if ( result->_state->_n.empty() || result->_state->_e.empty() )
                throw invalid_argument( "value" );

            // MAY have private key parameters, but only ALL or NONE
            std::vector<bool> privateParameters = { result->_state->_d.empty(), result->_state->_dp.empty(), result->_state->_dq.empty(), result->_state->_qi.empty(), result->_state->_p.empty(), result->_state->_q.empty() };

            if ( !( std::all_of( privateParameters.cbegin(), privateParameters.cend(), []( bool value ) { return value; } ) || std::all_of( privateParameters.cbegin(), privateParameters.cend(), []( bool value ) { return !value; } ) ) )
                throw invalid_argument( "value" );
        }

    }

    return result;
}

// Default ctor
JsonWebKey::JsonWebKey()
{
    _state = new State();
}

// Copy ctor
JsonWebKey::JsonWebKey( const JsonWebKey& other )
{
    _state = new State( *other._state );
}

// Move ctor
JsonWebKey::JsonWebKey( JsonWebKey&& other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
JsonWebKey& JsonWebKey::operator = ( const JsonWebKey& other )
{
    _state->operator = ( *other._state );

    return *this;
}

// Move assignment
JsonWebKey& JsonWebKey::operator=( JsonWebKey&& other )
{
    if ( _state != NULL ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

JsonWebKey::JsonWebKey( const akv::string_t& kid, const RsaParameters &rsa )
{
    _state = new State();

    _state->_kid = kid;
    _state->_kty = KeyTypes::Rsa();

    _state->_n = rsa.n();
    _state->_e = rsa.e();

    _state->_d = rsa.d();
    _state->_p = rsa.p();
    _state->_q = rsa.q();

    _state->_dp = rsa.dp();
    _state->_dq = rsa.dq();
    _state->_qi = rsa.qi();
}

JsonWebKey::~JsonWebKey()
{
    if ( _state != NULL ) delete _state;
}

akv::string_t JsonWebKey::kid() const
{
    return _state->_kid;
}

akv::string_t JsonWebKey::kty() const
{
    return _state->_kty;
}

std::unordered_set<akv::string_t>& JsonWebKey::key_ops()
{
    return _state->_key_ops;
}

// RSA Public parameters
std::vector<akv::byte_t> JsonWebKey::n() const
{
    return _state->_n;
}

std::vector<akv::byte_t> JsonWebKey::e() const
{
    return _state->_e;
}

// RSA private parameters
std::vector<akv::byte_t> JsonWebKey::d() const
{
    return _state->_d;
}

std::vector<akv::byte_t> JsonWebKey::p() const
{
    return _state->_p;
}

// RSA Public parameters
std::vector<akv::byte_t> JsonWebKey::q() const
{
    return _state->_q;
}

std::vector<akv::byte_t> JsonWebKey::dp() const
{
    return _state->_dp;
}

// RSA Public parameters
std::vector<akv::byte_t> JsonWebKey::dq() const
{
    return _state->_dq;
}

std::vector<akv::byte_t> JsonWebKey::qi() const
{
    return _state->_qi;
}

// Octet parameters
std::vector<akv::byte_t> JsonWebKey::k() const
{
    return _state->_k;
}

RsaParameters JsonWebKey::to_rsa_parameters( bool includePrivate ) const
{
    if ( _state->_kty.empty() )
        throw logic_error( "JsonWebKey does not have a key type (kty)" );

    if ( _state->_kty.compare( KeyTypes::Rsa() ) != 0 && _state->_kty.compare( KeyTypes::RsaHsm() ) != 0 )
        throw logic_error( "JsonWebKey is not RSA and cannot export parameters" );

    RsaParameters rsa;

    rsa.n( _state->_n );
    rsa.e( _state->_e );

    if ( includePrivate )
    {
        rsa.d( _state->_d );
        rsa.p( _state->_p );
        rsa.q( _state->_q );

        rsa.dp( _state->_dp );
        rsa.dq( _state->_dq );
        rsa.qi( _state->_qi );
    }

    return rsa;
}

web::json::value JsonWebKey::to_json() const
{
    std::vector<std::pair<akv::string_t, web::json::value>> fields;

    if ( _state->_kty.empty() )
        throw logic_error( "JsonWebKey does not have a key type (kty)" );

    if ( _state->_kty.compare( KeyTypes::Rsa() ) != 0 && _state->_kty.compare( KeyTypes::RsaHsm() ) != 0 )
        throw logic_error( "JsonWebKey is not RSA and cannot be serialized" );

    fields.push_back( std::make_pair( __T("kty"), web::json::value::string( _state->_kty ) ) );

    // Key Identifier
    if ( !_state->_kid.empty() )
        fields.push_back( std::make_pair( __T("kid"), web::json::value::string( _state->_kid ) ) );

    // Key Operations
    if ( !_state->_key_ops.empty() )
    {
        std::vector<web::json::value> values;

        for ( auto item = _state->_key_ops.cbegin(); item != _state->_key_ops.cend(); item++ )
        {
            values.push_back( web::json::value::string( *item ) );
        }

        fields.push_back( std::make_pair( __T("key_ops"), web::json::value::array( values ) ) );
    }

    if ( _state->_kty.compare( KeyTypes::Rsa() ) == 0 || _state->_kty.compare( KeyTypes::RsaHsm() ) == 0 )
    {
        fields.push_back( std::make_pair( __T("n"), web::json::value::string( Base64::encode_url( _state->_n ) ) ) );
        fields.push_back( std::make_pair( __T("e"), web::json::value::string( Base64::encode_url( _state->_e ) ) ) );

        if ( !_state->_d.empty() )
        {
            // Private parameters
            fields.push_back( std::make_pair( __T("d"), web::json::value::string( Base64::encode_url( _state->_d ) ) ) );
            fields.push_back( std::make_pair( __T("dp"), web::json::value::string( Base64::encode_url( _state->_dp ) ) ) );
            fields.push_back( std::make_pair( __T("dq"), web::json::value::string( Base64::encode_url( _state->_dq ) ) ) );
            fields.push_back( std::make_pair( __T("p"), web::json::value::string( Base64::encode_url( _state->_p ) ) ) );
            fields.push_back( std::make_pair( __T("q"), web::json::value::string( Base64::encode_url( _state->_q ) ) ) );
            fields.push_back( std::make_pair( __T("qi"), web::json::value::string( Base64::encode_url( _state->_qi ) ) ) );
        }
    }

    return web::json::value::object( fields );
}

akv::string_t JsonWebKey::to_string() const
{
    return to_json().serialize();
}

}
}
