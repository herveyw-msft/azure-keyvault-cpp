
#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"
#include "akv/jose/JweHeader.h"

using namespace std;
using namespace web;
using namespace akv::common;

namespace akv { namespace jose {

struct JweHeader::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    akv::string_t                   _kid;
    akv::string_t                   _algorithm;
    akv::string_t                   _encryptionAlgorithm;
    map<akv::string_t, json::value> _properties;
};

shared_ptr<JweHeader> JweHeader::from_compact_header( const akv::string_t& compactHeader )
{
    if ( compactHeader.empty() ) throw invalid_argument( "compactHeader" );

    shared_ptr<JweHeader> result( new JweHeader() );

    // Decode from Base64Url to obtain a vector<byte>, then convert
    // to the platform native string variant.
    auto header = to_platform_string( Base64::decode_url( compactHeader ) );

    auto value = json::value::parse( header );

    if ( value.is_object() )
    {
        auto object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("alg") ) == 0 )
                result->_state->_algorithm = field->second.as_string();
            else if ( field->first.compare( __T("enc") ) == 0 )
                result->_state->_encryptionAlgorithm = field->second.as_string();
            else if ( field->first.compare( __T("kid") ) == 0 )
                result->_state->_kid = field->second.as_string();
            else
                // Unrecognized values go to the property bag
                result->_state->_properties[field->first] = field->second;
        }
    }

    return result;
}

JweHeader::JweHeader()
{
    _state = new State();
}

JweHeader::JweHeader( const JweHeader& other )
{
    _state = new State( *other._state );
}

JweHeader::JweHeader( JweHeader&& other )
{
    _state = other._state;
    other._state = NULL;
}

JweHeader& JweHeader::operator = ( const JweHeader &other )
{
    _state->operator = ( *other._state );

    return *this;
}

JweHeader& JweHeader::operator = ( JweHeader&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

JweHeader::~JweHeader()
{
    if ( _state != NULL ) delete _state;
}

const akv::string_t& JweHeader::kid() const
{
    return _state->_kid;
}

void JweHeader::kid( const akv::string_t& kid )
{
    _state->_kid = kid;
}

const akv::string_t& JweHeader::algorithm() const
{
    return _state->_algorithm;
}

void JweHeader::algorithm( const akv::string_t& algorithm )
{
    _state->_algorithm = algorithm;
}

const akv::string_t& JweHeader::encryption_algorithm() const
{
    return _state->_encryptionAlgorithm;
}

void JweHeader::encryption_algorithm( const akv::string_t& algorithm )
{
    _state->_encryptionAlgorithm = algorithm;
}

void JweHeader::add_property( const akv::string_t& name, const web::json::value& value )
{
    // Check for reserved names
    if ( name == __T( "alg" ) || name == __T( "kid" ) || name == __T( "enc" ) )
        throw invalid_argument( "name is reserved" );

    _state->_properties[name] = value;
}

json::value JweHeader::get_property( const akv::string_t& name ) const
{
    return _state->_properties[name];
}

bool JweHeader::has_property( const akv::string_t& name ) const
{
    return _state->_properties.count( name ) == 1;
}

void JweHeader::remove_property( const akv::string_t& name )
{
    _state->_properties.erase( name );
}

bool JweHeader::empty() const
{
    return _state->_algorithm.empty() && _state->_encryptionAlgorithm.empty() && _state->_kid.empty() && _state->_properties.empty();
}

akv::string_t JweHeader::to_compact_header() const
{
    return Base64::encode_url( get_bytes( to_string() ) );
}

akv::string_t JweHeader::to_string() const
{
    // TODO: This doesn't allow for an unprotected header without these values
    if ( _state->_algorithm.empty() || _state->_encryptionAlgorithm.empty() || _state->_kid.empty() )
        throw logic_error( "Header is incomplete" );

    akv::string_t result;

    result.append( __T( "{" ) );

    result.append( __T( "\"alg\": \"" ) + _state->_algorithm + __T( "\"" ) );
    result.append( __T( ",\"enc\": \"" ) + _state->_encryptionAlgorithm + __T( "\"" ) );
    result.append( __T( ",\"kid\": \"" ) + _state->_kid + __T( "\"" ) );

    if ( !_state->_properties.empty() )
    {
        // Emit other properties
        for( const auto& pair : _state->_properties )
        {
            result.append( __T( ",\"" ) + pair.first + __T( "\":" ) + pair.second.serialize() );
        }
    }

    // Close the object
    result.append( __T( "}" ) );

    return result;
}

} }
