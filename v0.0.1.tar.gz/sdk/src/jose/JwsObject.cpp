/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/jose/JweFormatException.h"
#include "akv/jose/JwsHeader.h"
#include "akv/jose/JwsObject.h"

using namespace std;
using namespace akv::common;

namespace akv { namespace jose {

class JwsObject::State
{
public:
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    shared_ptr<JwsHeader> _protected;
    akv::string_t         _protectedEncoded;
    shared_ptr<JwsHeader> _unprotected;
    vector<akv::byte_t>   _payload;
    vector<akv::byte_t>   _signature;
};

shared_ptr<JwsObject> JwsObject::from_compact_jws(const akv::string_t& compactJws )
{
    if ( compactJws.empty() )
        throw invalid_argument( "jws" );

    vector<akv::string_t> components = split( compactJws, '.');

    if ( components.empty() || components.size() != 3 )
        throw JweFormatException( __T( "Incorrect number of components" ) );
    
    shared_ptr<JwsObject> result = make_shared<JwsObject>();

    // In the compact case, there is only a protected header
    //result._state->_unprotected  = JwsHeader::fromCompactHeader( components[0] );
    result->_state->_protected    = JwsHeader::from_compact_header( components[0] );
    result->_state->_payload      = components[1].empty() ? vector<akv::byte_t>() : Base64::decode_url( components[1] );
    result->_state->_signature    = components[2].empty() ? vector<akv::byte_t>() : Base64::decode_url( components[2] );

    if ( result->_state->_payload.empty() || result->_state->_signature.empty() )
        throw JweFormatException( __T( "Payload or signature is empty" ) );

    return result;
}

shared_ptr<JwsObject> JwsObject::from_flattened_jws( const akv::string_t& flattenedJws )
{
    if ( flattenedJws.empty() )
        throw invalid_argument( "jws" );

    auto value = web::json::value::parse( flattenedJws );

    if ( value.is_object() )
    {
        auto                  object = value.as_object();
        shared_ptr<JwsObject> jws( new JwsObject );

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T( "header" ) ) == 0 )
            {
                jws->_state->_unprotected = JwsHeader::from_compact_header( field->second.as_string() );
            }
            else if ( field->first.compare( __T( "protected" ) ) == 0 )
            {
                jws->_state->_protectedEncoded = field->second.as_string();
                jws->_state->_protected        = JwsHeader::from_compact_header( jws->_state->_protectedEncoded );
            }
            else if ( field->first.compare( __T( "payload" ) ) == 0 )
            {
                jws->_state->_payload = Base64::decode_url( field->second.as_string() );
            }
            else if ( field->first.compare( __T( "signature" ) ) == 0 )
            {
                jws->_state->_signature = Base64::decode_url( field->second.as_string() );
            }
        }

        return jws;
    }

    throw JweFormatException( __T( "Source is not a valid JSON object" ) );
}

JwsObject::JwsObject()
{
    _state = new State();
}

JwsObject::JwsObject( const JwsObject& other )
{
    _state = new State( *other._state );
}

JwsObject::JwsObject( JwsObject&& other )
{
    _state = other._state;
    other._state = NULL;
}

JwsObject& JwsObject::operator = ( const JwsObject& other )
{
    _state->operator = ( *other._state );

    return *this;
}

JwsObject& JwsObject::operator = ( JwsObject&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

JwsObject::~JwsObject()
{
    if ( _state != NULL ) delete _state;    
}

const shared_ptr<JwsHeader> JwsObject::protected_header() const
{
    return _state->_protected;
}

void JwsObject::protected_header( const shared_ptr<JwsHeader> value )
{
    // Cannot set this to nullptr
    if ( value == nullptr )
        throw invalid_argument( "value" );

    _state->_protected = value;
}

akv::string_t JwsObject::protected_header_encoded() const
{
    if ( _state->_protectedEncoded.empty() )
        return _state->_protected->to_compact_header();
    else
        return _state->_protectedEncoded;
}

const std::vector<akv::byte_t>& JwsObject::payload() const
{
    return _state->_payload;
}

void JwsObject::payload( const std::vector<akv::byte_t>& value )
{
    _state->_payload = value;
}

const shared_ptr<JwsHeader> JwsObject::unprotected_header() const
{
    return _state->_unprotected;
}

void JwsObject::unprotected_header( const shared_ptr<JwsHeader> value )
{
    _state->_unprotected = value;
}

const vector<akv::byte_t>& JwsObject::signature() const
{
    return _state->_signature;
}

void JwsObject::signature( const vector<akv::byte_t>& value )
{
    _state->_signature = value;
}

akv::string_t JwsObject::to_compact_jws() const
{
    if (_state->_payload.empty() || _state->_signature.empty() )
        throw invalid_argument("JWS object is not complete");

    return _state->_protected->to_compact_header() + __T(".") + Base64::encode_url( _state->_payload ) + __T(".") + Base64::encode_url( _state->_signature );
}

akv::string_t JwsObject::to_string() const
{
    akv::string_t result;

    result.append( __T( "{" ) );

    if ( _state->_unprotected != nullptr && !_state->_unprotected->empty() )
        result.append( __T( "\"header\": " ) + _state->_unprotected->to_string() + __T( "," ) );

    result.append( __T( "\"protected\": \"" ) + protected_header_encoded() + __T( "\"," ) );
    result.append( __T( "\"payload\": \"" ) + Base64::encode_url( _state->_payload ) + __T( "\"," ) );
    result.append( __T( "\"signature\": \"" ) + Base64::encode_url( _state->_signature ) + __T( "\"" ) );
    result.append( __T( "}" ) );

    return result;
}

} }
