/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/jose/JweFormatException.h"
#include "akv/jose/JweHeader.h"
#include "akv/jose/JweObject.h"

using namespace std;
using namespace akv::common;

namespace akv { namespace jose {

class JweObject::State
{
public:
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    std::vector<akv::byte_t>   _aad;
    std::vector<akv::byte_t>   _ciphertext;
    std::vector<akv::byte_t>   _encryptedKey;
    std::vector<akv::byte_t>   _iv;
    shared_ptr<JweHeader>      _protected;
    akv::string_t              _protectedEncoded;
    std::vector<akv::byte_t>   _tag;
    shared_ptr<JweHeader>      _unprotected;
};

shared_ptr<JweObject> JweObject::from_compact_jwe( const akv::string_t& compactJwe )
{
    if ( compactJwe.empty() )
        throw invalid_argument( "jwe" );

    vector<akv::string_t> components = split( compactJwe, '.' );

    if ( components.empty() || components.size() != 5 )
        throw JweFormatException( __T( "Incorrect number of components" ) );

    shared_ptr<JweObject> result( new JweObject() );

    // Deserialize, and remember the encoded protected header
    result->_state->_protectedEncoded = components[0];
    result->_state->_protected        = JweHeader::from_compact_header( components[0] );
    result->_state->_encryptedKey     = components[1].empty() ? vector<uint8_t>() : Base64::decode_url( components[1] );
    result->_state->_iv               = components[2].empty() ? vector<uint8_t>() : Base64::decode_url( components[2] );
    result->_state->_ciphertext       = components[3].empty() ? vector<uint8_t>() : Base64::decode_url( components[3] );
    result->_state->_tag              = components[4].empty() ? vector<uint8_t>() : Base64::decode_url( components[4] );

    return result;
}

shared_ptr<JweObject> JweObject::from_flattened_jwe( const akv::string_t& flattenedJwe )
{
    if ( flattenedJwe.empty() )
        throw invalid_argument( "flattenedJwe" );

    auto value = web::json::value::parse( flattenedJwe );

    if ( value.is_object() )
    {
        auto                  object = value.as_object();
        shared_ptr<JweObject> jwe( new JweObject() );

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T( "header" ) ) == 0 )
            {
                jwe->_state->_unprotected = JweHeader::from_compact_header( field->second.as_string() );
            }
            else if ( field->first.compare( __T( "protected" ) ) == 0 )
            {
                jwe->_state->_protectedEncoded = field->second.as_string();
                jwe->_state->_protected        = JweHeader::from_compact_header( jwe->_state->_protectedEncoded );
            }
            else if ( field->first.compare( __T( "ciphertext" ) ) == 0 )
            {
                jwe->_state->_ciphertext = Base64::decode_url( field->second.as_string() );
            }
            else if ( field->first.compare( __T( "encrypted_key" ) ) == 0 )
            {
                jwe->_state->_encryptedKey = Base64::decode_url( field->second.as_string() );
            }
            else if ( field->first.compare( __T( "iv" ) ) == 0 )
            {
                jwe->_state->_iv = Base64::decode_url( field->second.as_string() );
            }
            else if ( field->first.compare( __T( "tag" ) ) == 0 )
            {
                jwe->_state->_tag = Base64::decode_url( field->second.as_string() );
            }
        }

        return jwe;
    }

    throw JweFormatException( __T( "Source is not a valid JSON object" ) );
}


JweObject::JweObject()
{
    _state = new State();
}

JweObject::JweObject( const JweObject& other )
{
    _state = new State( *other._state );
}

JweObject::JweObject( JweObject&& other )
{
    _state = other._state;
    other._state = NULL;
}

JweObject& JweObject::operator = ( const JweObject& other )
{
    _state->operator = ( *other._state );

    return *this;
}

JweObject& JweObject::operator = ( JweObject&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

JweObject::~JweObject()
{
    if ( _state != NULL ) delete _state;    
}

const std::vector<akv::byte_t>& JweObject::authentication_data() const
{
    return _state->_aad;
}

void JweObject::authentication_data( const std::vector<akv::byte_t>& value )
{
    _state->_aad = value;
}

const std::vector<akv::byte_t>& JweObject::ciphertext() const
{
    return _state->_ciphertext;
}

void JweObject::ciphertext( const std::vector<akv::byte_t>& value )
{
    _state->_ciphertext = value;
}

const std::vector<akv::byte_t>&  JweObject::encrypted_key() const
{
    return _state->_encryptedKey;
}

void JweObject::encrypted_key( const std::vector<akv::byte_t>& value )
{
    _state->_encryptedKey = value;
}

const std::vector<akv::byte_t>& JweObject::iv() const
{
    return _state->_iv;
}

void JweObject::iv( const std::vector<akv::byte_t>& value )
{
    _state->_iv = value;
}

const std::vector<akv::byte_t>& JweObject::authentication_tag() const
{
    return _state->_tag;
}

void JweObject::authentication_tag( const std::vector<akv::byte_t>& value )
{
    _state->_tag = value;
}

const shared_ptr<JweHeader> JweObject::protected_header() const
{
    return _state->_protected;
}

void JweObject::protected_header( const shared_ptr<JweHeader> value )
{
    // Cannot set this to nullptr
    if ( value == nullptr )
        throw invalid_argument( "value" );

    _state->_protected = value;
}

akv::string_t JweObject::protected_header_encoded() const
{
    if ( _state->_protectedEncoded.empty() )
        return _state->_protected->to_compact_header();
    else
        return _state->_protectedEncoded;
}

const shared_ptr<JweHeader> JweObject::unprotected_header() const
{
    return _state->_unprotected;
}

void JweObject::unprotected_header( const shared_ptr<JweHeader> value )
{
    _state->_unprotected = value;
}

akv::string_t JweObject::to_compact_jwe() const
{
    if ( _state->_protected->empty() || _state->_iv.empty() || _state->_ciphertext.empty() )
        throw invalid_argument( "JWE object is not complete" );

    return _state->_protected->to_compact_header() + __T(".") + Base64::encode_url( _state->_encryptedKey ) + __T(".") + Base64::encode_url( _state->_iv ) + __T(".") + Base64::encode_url( _state->_ciphertext ) + __T(".") + Base64::encode_url( _state->_tag );
}

akv::string_t JweObject::to_flattened_jwe() const
{
    if ( _state->_protected == nullptr || _state->_protected->empty() || _state->_encryptedKey.empty() || _state->_iv.empty() || _state->_ciphertext.empty() || _state->_tag.empty() )
        throw logic_error( "JWE object is not complete" );

    akv::string_t result;

    result.append( __T( "{" ) );

    if ( _state->_unprotected != nullptr && !_state->_unprotected->empty() )
        result.append( __T( "\"header\": " ) + _state->_unprotected->to_string() + __T( "," ) );

    result.append( __T( "\"protected\": \"" ) + _state->_protected->to_compact_header() + __T( "\"," ) );
    result.append( __T( "\"encrypted_key\": \"" ) + Base64::encode_url( _state->_encryptedKey ) + __T( "\"," ) );
    result.append( __T( "\"iv\": \"" ) + Base64::encode_url( _state->_iv ) + __T( "\"," ) );
    result.append( __T( "\"ciphertext\": \"" ) + Base64::encode_url( _state->_ciphertext ) + __T( "\"," ) );
    result.append( __T( "\"tag\": \"" ) + Base64::encode_url( _state->_tag ) + __T( "\"" ) );
    result.append( __T( "}" ) );

    return result;
}

} }
