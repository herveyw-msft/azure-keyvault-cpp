/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/cryptography/IncrementalHash.h"

#include "akv/jose/JweFormatException.h"
#include "akv/jose/JwsHeader.h"
#include "akv/jose/JwsObject.h"
#include "akv/jose/JsonWebSignature.h"

using namespace akv;
using namespace akv::common;
using namespace akv::cryptography;
using namespace std;
using namespace pplx;

namespace akv { namespace jose {

pplx::task<shared_ptr<JwsObject>> JsonWebSignature::sign( const IKey&                     signature_key,
                                                          const std::vector<akv::byte_t>& payload,
                                                          const pplx::cancellation_token& token )
{
    return sign( signature_key, signature_key.defaultSignatureAlgorithm(), payload, token );    
}

task<shared_ptr<JwsObject>> JsonWebSignature::sign( const IKey&                     signature_key,
                                                    const akv::string_t&            signature_algorithm,
                                                    const std::vector<akv::byte_t>& payload,
                                                    const pplx::cancellation_token& cancellationToken )
{
    if ( signature_algorithm.empty() )
        throw invalid_argument( "signature_algorithm" );

    if ( payload.size() == 0 )
        throw invalid_argument( "payload" );

    // Create the headers with the encryption parameters.
    shared_ptr<JwsObject> object = CreateHeader( signature_key.kid(), signature_algorithm );

    object->payload( payload );

    return sign( signature_key, object, cancellationToken );
}

task<shared_ptr<JwsObject>> JsonWebSignature::sign( const IKey&                     signature_key,
                                                    const shared_ptr<JwsObject>     object,
                                                    const pplx::cancellation_token& cancellationToken )
{
    if ( object->protected_header() == nullptr )
        throw invalid_argument( "Protected Header is not present" );

    if ( object->protected_header()->algorithm().empty() )
        object->protected_header()->algorithm( signature_key.defaultSignatureAlgorithm() );

    if ( object->protected_header()->kid().empty() )
        object->protected_header()->kid( signature_key.kid() );

    if ( object->payload().empty() )
        throw invalid_argument( "Payload is not present" );

    // Copy for the result object
    std::shared_ptr<JwsObject> result( new JwsObject( *object ) );

    // Produce a digest of the protected header + payload
    // This code structure is less than ideal: IKey::sign accepts an algorithm and a digest but
    // has no built in method for creating the digest. This leaves us examining the signatureAlgorithm
    // here and creating the digest which is a very fragile solution.
    shared_ptr<IncrementalHash> hash;

    if ( object->protected_header()->algorithm() == __T( "RS256" ) )
        hash = make_shared<IncrementalHash>( IncrementalHash::SHA256 );
    else if ( object->protected_header()->algorithm() == __T( "RS384" ) )
        hash = make_shared<IncrementalHash>( IncrementalHash::SHA384 );
    else if ( object->protected_header()->algorithm() == __T( "RS512" ) )
        hash = make_shared<IncrementalHash>( IncrementalHash::SHA512 );
    else
        throw invalid_argument( "signatureAlgorithm" );

    // The signature is ASCII( BASE64URL( UTF( Protected ))) || "." || BASE64URL( payload )
    auto material = get_bytes( object->protected_header_encoded() + __T(".") + Base64::encode_url( object->payload() ) );
    auto digest   = hash->updateFinal( material );

    return signature_key.signHash( object->protected_header()->algorithm(), digest, cancellationToken ).then( [result]( IKey::SignResult signResult ) -> shared_ptr<JwsObject>
    {
        result->signature( signResult.value );

        return result;
    }, cancellationToken );
}

pplx::task<akv::string_t> JsonWebSignature::sign_compact( const IKey&                     signature_key,
                                                          const std::vector<akv::byte_t>& payload,
                                                          const pplx::cancellation_token& cancellationToken )
{
    return sign( signature_key, signature_key.defaultSignatureAlgorithm(), payload, cancellationToken ).then( []( shared_ptr<JwsObject> taskResult )
    {
        return taskResult->to_compact_jws();
    }, cancellationToken );
}

pplx::task<akv::string_t> JsonWebSignature::sign_compact( const IKey&                     signature_key,
                                                          const akv::string_t&            signature_algorithm,
                                                          const std::vector<akv::byte_t>& payload,
                                                          const pplx::cancellation_token& cancellationToken )
{
    return sign( signature_key, signature_algorithm, payload, cancellationToken ).then( []( shared_ptr<JwsObject> taskResult )
    {
        return taskResult->to_compact_jws();
    }, cancellationToken );
}

pplx::task<bool> JsonWebSignature::verify( const IKeyResolver&             keyResolver,
                                           const shared_ptr<JwsObject>     jws,
                                           const pplx::cancellation_token& cancellationToken )
{
    if ( jws->protected_header() == nullptr )
        throw invalid_argument( "Missing Protected Header" );

    if ( jws->protected_header()->algorithm().empty() || jws->protected_header()->kid().empty() )
        throw JweFormatException( __T( "Malformed protected header" ) );

    // Capture the deserialized protected header and the original encoded form
    auto protectedHeader        = jws->protected_header();
    auto protectedHeaderEncoded = jws->protected_header_encoded();

    // Resolve the signing key
    auto baseKey = keyResolver.resolve_key( protectedHeader->kid(), cancellationToken ).get();

    // Fail if the signing key could not be resolved
    if ( baseKey == nullptr )
        throw JweFormatException( __T( "The resolver was unable to resolve key with Kid " ) + protectedHeader->kid() );

    // Produce a digest of the protected header + payload
    // This code structure is less than ideal: IKey::sign accepts an algorithm and a digest but
    // has no built in method for creating the digest. This leaves us examining the signatureAlgorithm
    // here and creating the digest which is a very fragile solution.
    shared_ptr<IncrementalHash> hash;

    if ( protectedHeader->algorithm() == __T( "RS256" ) )
        hash = make_shared<IncrementalHash>( IncrementalHash::SHA256 );
    else if ( protectedHeader->algorithm() == __T( "RS384" ) )
        hash = make_shared<IncrementalHash>( IncrementalHash::SHA384 );
    else if ( protectedHeader->algorithm() == __T( "RS512" ) )
        hash = make_shared<IncrementalHash>( IncrementalHash::SHA512 );
    else
        throw invalid_argument( "algorithm" );

    // The signature is ASCII( BASE64URL( UTF( Protected ))) || "." || BASE64URL( payload )
    auto material = get_bytes( protectedHeaderEncoded + __T(".") + Base64::encode_url( jws->payload() ) );
    auto digest   = hash->updateFinal( material );

    // Verify
    return baseKey->verifyHash( protectedHeader->algorithm(), digest, jws->signature(), cancellationToken ).then( [](IKey::VerifyResult result )
    {
        return result.value;
    }, cancellationToken );
}

task<bool> JsonWebSignature::verify_compact( const IKeyResolver&             resolver,
                                            const akv::string_t&            compactJws,
                                            const pplx::cancellation_token& cancellationToken )
{
    if ( compactJws.empty() || compactJws.size() == 0 )
        throw invalid_argument( "compactJwe" );

    auto jwsObject = JwsObject::from_compact_jws( compactJws );

    return verify( resolver, jwsObject, cancellationToken );
}

std::shared_ptr<JwsObject> JsonWebSignature::CreateHeader( const akv::string_t& kid, const akv::string_t& algorithm )
{
    // Create the header
    shared_ptr<JwsHeader> header( new JwsHeader() );

    header->kid( kid );
    header->algorithm( algorithm );

    // Create the object
    shared_ptr<JwsObject> object( new JwsObject() );

    //object->Unprotected( header );
    object->protected_header( header );

    return object;
}

} }
