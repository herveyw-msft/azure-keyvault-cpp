/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

// CPP REST SDK
#include <cpprest/http_client.h>

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/authentication/HttpChallenge.h"
#include "akv/authentication/AuthenticationProofKey.h"

#include "akv/cryptography/AlgorithmNames.h"

#include "akv/client/KeyVaultClientException.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/jose/JweHeader.h"
#include "akv/jose/JweObject.h"
#include "akv/jose/JsonWebEncryption.h"

#include "akv/jose/JwsHeader.h"
#include "akv/jose/JwsObject.h"
#include "akv/jose/JsonWebSignature.h"

#include "client/HttpMessageProtectionKey.h"
#include "client/HttpMessage.h"
#include "client/HttpMessageSecurity.h"
#include "client/KeyVaultRequestResponse.h"

// Internal last
#include "common/time_t.h"
#include "common/url.h"

using namespace std;
using namespace pplx;
using namespace web;
using namespace web::http;
using namespace web::http::client;

namespace akv {

using namespace akv::common;
using namespace akv::authentication;
using namespace akv::cryptography;
using namespace akv::jose;

static const akv::string_t ApiVersion( __T( "?api-version=2016-10-01" ) );
static const akv::string_t ContentTypeJson( __T( "application/json" ) );
static const akv::string_t ContentTypeJoseJson( __T( "application/jose+json" ) );

static std::map<akv::string_t, std::shared_ptr<HttpChallenge>> _challengeMap;

task<shared_ptr<http_request>> RequestWriter::write( const std::shared_ptr<HttpMessage> httpMessage, const std::shared_ptr<HttpMessageSecurity> security )
{
    //request.headers().add(_XPLATSTR("client-request-id"), get_newguid());

    if ( security->clientSignatureKey == nullptr )
    {
        return pplx::create_task( [httpMessage, security]()
        {
            shared_ptr<http_request> httpRequest = make_shared<http_request>( httpMessage->method() );

            // Headers
            httpRequest->headers().add( __T("Accept"), ContentTypeJson );
            httpRequest->headers().add( __T("Authorization"), __T("Bearer ") + security->clientSecurityToken );

            // Body, including ContentType
            if ( !httpMessage->body().empty() )
                httpRequest->set_body( httpMessage->serialize(), ContentTypeJson );

            return httpRequest;
        } );
    }
    else
    {
        shared_ptr<http_request> httpRequest = make_shared<http_request>( httpMessage->method() );

        // Headers
        httpRequest->headers().add( __T( "Accept" ), ContentTypeJoseJson + __T( ", " ) + ContentTypeJson );
        httpRequest->headers().add( __T( "Authorization" ), __T("PoP ") + security->clientSecurityToken );

        if ( httpMessage->body().empty() )
        {
            return pplx::create_task( [httpRequest, security]()
            {
                return httpRequest;
            } );
        }
        else
        {
            // Inject the client response encryption key into the request if one
            // has not already been provided by the client application.
            if ( security->clientEncryptionKey != nullptr )
            {
                auto rek = httpMessage->body().find( __T("rek") );

                if ( rek == httpMessage->body().end() )
                {
                    httpMessage->body()[__T("rek")] = security->clientEncryptionKey->to_json();
                }
            }
            
            // Encrypt the request using the server encryption key
            return JsonWebEncryption::protect( *security->serverEncryptionKey, security->serverEncryptionKey->defaultKeyWrapAlgorithm(), AlgorithmNames::Aes128CbcHmacSha256(), get_bytes( httpMessage->serialize() ) ).then( [httpRequest, security]( shared_ptr<JweObject> jwe )
            {
                // Signature
                shared_ptr<JwsHeader> header( new JwsHeader() );

                header->algorithm( security->clientSignatureKey->defaultSignatureAlgorithm() );
                header->kid( security->clientSignatureKey->kid() );
                header->add_property( __T( "typ" ), json::value::string( __T( "pop" ) ) );
                header->add_property( __T( "at" ), json::value::string( security->clientSecurityToken ) );
                header->add_property( __T( "ts" ), json::value::number( utc_now() ) );
                header->add_property( __T( "p" ), json::value::string( httpRequest->absolute_uri().path() ) );

                shared_ptr<JwsObject> object( new JwsObject() );

                object->protected_header( header );
                object->payload( get_bytes( jwe->to_flattened_jwe() ) );

                return JsonWebSignature::sign( *security->clientSignatureKey, object ).then( [httpRequest]( shared_ptr<JwsObject> signedBody ) -> std::shared_ptr<http_request>
                {
                    auto stringBody = signedBody->to_string();

                    // Body, including ContentType
                    httpRequest->set_body( stringBody, ContentTypeJoseJson );

                    return httpRequest;
                } );

            } );
        }
    }
}


// Reads the response body as a JSON object
task<json::value> ResponseReader::read_json( const http_response& response, const std::shared_ptr<HttpMessageSecurity> security )
{
    akv::string_t rawResponse;

    switch ( response.status_code() )
    {
        case 200:
            if ( contains( response.headers().content_type(), ContentTypeJson ) )
            {
                return response.extract_json();
            }
            else if ( contains( response.headers().content_type(), ContentTypeJoseJson ) )
            {
                // Process the message security. Note that cpprestsdk does not believe
                // that application/jose-json is a text content type and so we extract
                // the response as a vector<char> and convert that to a string to 
                // process it.
                rawResponse = to_platform_string( response.extract_vector().get() );

                auto jws = JwsObject::from_flattened_jws( rawResponse );

                return JsonWebSignature::verify( *security, jws ).then( [jws, security]( bool verified )
                {
                    if ( verified == false )
                        throw KeyVaultClientException( 200, __T( "Response signature verification failed" ) );

                    auto payload = to_platform_string( jws->payload() );
                    auto jwe     = JweObject::from_flattened_jwe( payload );

                    return JsonWebEncryption::unprotect( *security, jwe ).then( [](std::vector<akv::byte_t> bytes)
                    {
                        auto decrypted = to_platform_string( bytes );

                        return json::value::parse( decrypted );
                    } );
                } );
        
            }
            else
            {
                throw KeyVaultClientException( response.status_code(), __T( "The service response ContentType was not recognized" ) );
            }
            break;

        default:
            // TODO: This should be an error response that can be parsed
            rawResponse = response.extract_string().get();

            throw KeyVaultClientException( response.status_code(), rawResponse );
            break;
    }
}

}
