/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/jose/JsonWebKey.h"
#include "akv/client/ObjectAttributes.h"
#include "akv/client/KeyBundle.h"

using namespace std;
using namespace web;

namespace akv {

const akv::string_t ID( __T( "id" ) );
const akv::string_t KEY( __T( "key" ) );

struct KeyBundle::State
{
    State() : _attributes( make_shared<ObjectAttributes>() )
    {
    }

    State( const State& other )
    {
        _attributes = make_shared<ObjectAttributes>( *other._attributes );
        _key        = make_shared<jose::JsonWebKey>( *other._key );
    }

    State& operator = ( const State& other )
    {
        _attributes = make_shared<ObjectAttributes>( *other._attributes );
        _key        = make_shared<jose::JsonWebKey>( *other._key );

        return *this;
    }

    shared_ptr<ObjectAttributes> _attributes;
    shared_ptr<jose::JsonWebKey> _key;
};

std::shared_ptr<KeyBundle> KeyBundle::from_string( const akv::string_t& src )
{
    // TODO: Check for errors from parsing
    std::error_code error;
    auto            value = web::json::value::parse( src, error );

    return KeyBundle::from_json( value );
}

std::shared_ptr<KeyBundle> KeyBundle::from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        std::shared_ptr<KeyBundle> result( new KeyBundle() );
        json::object              object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("key") ) == 0 )
                result->_state->_key = jose::JsonWebKey::from_json( field->second );
            //else if ( field->first.compare( __T("enc") ) == 0 )
            //    result->_state->_encryptionAlgorithm = field->second.as_string();
            else if ( field->first.compare( __T("attributes") ) == 0 )
                result->_state->_attributes = ObjectAttributes::from_json( field->second );
        }

        return result;
    }

    throw invalid_argument( "value" );
}

// Default ctor
KeyBundle::KeyBundle()
{
    _state = new State();
}

KeyBundle::KeyBundle( const akv::jose::JsonWebKey& key )
{
    std::unique_ptr<State> state( new State() );

    state->_key = make_shared<jose::JsonWebKey>( key );

    _state = state.release();
}

// Copy ctor
KeyBundle::KeyBundle( const KeyBundle& other )
{
    _state = new State( *other._state );
}

// Move ctor
KeyBundle::KeyBundle( KeyBundle && other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
KeyBundle& KeyBundle::operator = ( const KeyBundle& other )
{
    _state->operator = ( *other._state );

    return *this;
}

// Move assignment
KeyBundle& KeyBundle::operator = ( KeyBundle&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

KeyBundle::~KeyBundle()
{
    if ( _state != NULL ) delete _state;
}

akv::string_t KeyBundle::id() const
{
    return _state->_key->kid();
}

ObjectAttributes& KeyBundle::attributes() const
{
    return *_state->_attributes;
}

jose::JsonWebKey& KeyBundle::web_key() const
{
    return *_state->_key;
}

web::json::value KeyBundle::to_json() const
{
    std::vector<std::pair<akv::string_t, web::json::value>> properties;
    
    if ( _state->_key != nullptr )
        properties.push_back( std::make_pair( __T("key"), _state->_key->to_json() ) );

    if ( _state->_attributes != nullptr )
    properties.push_back( std::make_pair( __T("attributes"), _state->_attributes->to_json() ) );

    return web::json::value::object( properties );
}

}
