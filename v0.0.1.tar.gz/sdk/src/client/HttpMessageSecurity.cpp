/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

// CPP REST SDK
#include <cpprest/http_client.h>

#include "akv/common/string_t.h"
#include "akv/common/base64.h"

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/Key.h"
#include "akv/cryptography/RsaKey.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/jose/JweHeader.h"
#include "akv/jose/JweObject.h"
#include "akv/jose/JsonWebEncryption.h"

#include "akv/jose/JwsHeader.h"
#include "akv/jose/JwsObject.h"
#include "akv/jose/JsonWebSignature.h"

#include "akv/authentication/AuthenticationProofKey.h"

#include "client/HttpMessageProtectionKey.h"
#include "client/HttpMessageSecurity.h"

// Internal last
#include "common/time_t.h"
#include "common/url.h"

using namespace std;
using namespace pplx;
using namespace web;
using namespace web::http;
using namespace web::http::client;

namespace akv {

using namespace akv::common;
using namespace akv::cryptography;
using namespace akv::jose;

static akv::string_t ApiVersion( __T( "?api-version=2016-10-01" ) );
static akv::string_t ContentTypeJson( __T( "application/json" ) );
static akv::string_t ContentTypeJoseJson( __T( "application/jose+json" ) );
 

HttpMessageSecurity::HttpMessageSecurity() : clientSecurityToken(), clientSignatureKey( nullptr ), clientEncryptionKey( nullptr ), serverSignatureKey( nullptr ), serverEncryptionKey( nullptr )
{
}

pplx::task<std::shared_ptr<akv::IKey>> HttpMessageSecurity::resolve_key( const akv::string_t & kid, const pplx::cancellation_token& token ) const
{
    return pplx::create_task( [this, kid, token]() -> std::shared_ptr<IKey>
    {
        // For the client, prefer the signing key over the encryption key
        // if they have the same kid as it is guaranteed to have a private key.
        if ( clientSignatureKey->kid() == kid )
            return std::static_pointer_cast<akv::IKey>( clientSignatureKey );
		else if ( clientEncryptionKey->kid() == kid )
			return std::static_pointer_cast<akv::IKey>( clientEncryptionKey );
		else if ( serverSignatureKey->kid() == kid )
			return std::static_pointer_cast<akv::IKey>( serverSignatureKey );
		else if ( serverEncryptionKey->kid() == kid )
			return std::static_pointer_cast<akv::IKey>( serverEncryptionKey );
        else
            return std::shared_ptr<IKey>( nullptr );
    }, token );
}

}
