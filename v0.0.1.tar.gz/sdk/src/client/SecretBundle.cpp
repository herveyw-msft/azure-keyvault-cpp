/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/client/ObjectAttributes.h"
#include "akv/client/SecretBundle.h"

namespace akv {

using namespace std;

const akv::string_t Id( __T( "id" ) );
const akv::string_t ContentType( __T( "contentType" ) );
const akv::string_t Kid( __T( "kid" ) );
const akv::string_t Managed( __T( "managed" ) );
const akv::string_t Value( __T( "value" ) );
const akv::string_t Attributes( __T( "attributes" ) );

struct SecretBundle::State
{
    State() { };
    State( const State& )              = default;  
    State& operator = ( const State& ) = default;
    ~State() { };

    akv::string_t    _id;
    akv::string_t    _contentType;
    akv::string_t    _value;
    akv::string_t    _kid;
    bool             _managed;

    ObjectAttributes _attributes;
};

std::shared_ptr<SecretBundle> SecretBundle::from_string( const akv::string_t& src )
{
    if ( src.empty() )
        throw invalid_argument( "src" );

    // TODO: Check for errors from parsing
    std::error_code error;
    auto            value = web::json::value::parse( src, error );

    return SecretBundle::from_json( value );
}

std::shared_ptr<SecretBundle> SecretBundle::from_json( const web::json::value& src )
{
    if ( src.is_object() )
    {
        std::shared_ptr<SecretBundle> result( new SecretBundle() );

        // TODO: Complete parsing
        if ( src.has_field( Id ) )          { result->_state->_id          = src.at( Id ).as_string(); }
        if ( src.has_field( ContentType ) ) { result->_state->_contentType = src.at( ContentType ).as_string(); }
        if ( src.has_field( Value ) )       { result->_state->_value       = src.at( Value ).as_string(); }
        if ( src.has_field( Kid ) )         { result->_state->_kid         = src.at( Kid ).as_string(); }
        if ( src.has_field( Managed ) )     { result->_state->_managed     = src.at( Managed ).as_bool(); }
        if ( src.has_field( Attributes ) )  { result->_state->_attributes  = *ObjectAttributes::from_json( src.at( Attributes ) ); }

        return result;
    }

    throw invalid_argument( "src" );
}

// Default ctor
SecretBundle::SecretBundle()
{
    _state = new State();
}

// Copy ctor
SecretBundle::SecretBundle( const SecretBundle& other )
{
    _state = new State( *other._state );
}

SecretBundle::SecretBundle( SecretBundle&& other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
SecretBundle& SecretBundle::operator = ( const SecretBundle& other )
{
    _state->operator = ( *other._state );

    return *this;
}

// Move assignment
SecretBundle& SecretBundle::operator = ( SecretBundle&& other )
{
    if ( NULL != _state ) delete _state;
    
    _state = other._state;
    other._state = NULL;

    return *this;
}

SecretBundle::~SecretBundle()
{
    if ( _state != NULL ) delete _state;
}

akv::string_t SecretBundle::id() const
{
    return _state->_id;
}

akv::string_t SecretBundle::content_type() const
{
    return _state->_contentType;
}

akv::string_t SecretBundle::value() const
{
    return _state->_value;
}

akv::string_t SecretBundle::kid() const
{
    return _state->_kid;
}

bool SecretBundle::managed() const
{
    return _state->_managed;
}

ObjectAttributes& SecretBundle::attributes()
{
    return _state->_attributes;
}

web::json::value SecretBundle::to_json() const
{
    std::vector<std::pair<akv::string_t, web::json::value>> properties;
    
    properties.push_back( std::make_pair( __T("value"), web::json::value::string( _state->_value ) ) );
    properties.push_back( std::make_pair( __T("contentType"), web::json::value::string( _state->_contentType ) ) );
    properties.push_back( std::make_pair( __T("attributes"), _state->_attributes.to_json() ) );

    return web::json::value::object( properties );
}

}
