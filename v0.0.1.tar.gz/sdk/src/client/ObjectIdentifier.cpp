/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"
#include "common/url.h"

#include "akv/client/ObjectIdentifier.h"

using namespace std;
using namespace web;
using namespace akv;
using namespace akv::common;

namespace akv {

//
// ObjectIdentifier
//
struct ObjectIdentifier::State
{
    State() { };
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State() { }

    akv::string_t _vault;
    akv::string_t _vaultWithoutScheme;
    akv::string_t _name;
    akv::string_t _version;
    akv::string_t _identifier;
    akv::string_t _baseIdentifier;
};

bool ObjectIdentifier::is_object_identifier( const akv::string_t& collection, const akv::string_t& identifier )
{
    if ( collection.empty() ) throw invalid_argument( "collection" );

    if ( identifier.empty() ) return false;

    try
    {
        auto baseUri  = uri( identifier );
        // NOTE: split_path is rather crude if the identifier contains the host name
        auto segments = uri::split_path( baseUri.path() );

        // We expect an identifier with either 2 or 3 segments: collection + name [+ version]
        if ( segments.size() != 2 && segments.size() != 3 )
            return false;

        if ( segments[0] != collection )
            return false;

        return true;
    }
    catch ( ... )
    {
        // Intentionally empty
    }

    return false;
}

// Copy ctor
ObjectIdentifier::ObjectIdentifier( const ObjectIdentifier& other )
{
    _state = new State( *other._state );
}

// Move ctor
ObjectIdentifier::ObjectIdentifier( ObjectIdentifier&& other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
ObjectIdentifier& ObjectIdentifier::operator = ( const ObjectIdentifier& other )
{
    _state->operator = ( *other._state );
    
    return *this;
}

// Move assignment
ObjectIdentifier& ObjectIdentifier::operator = ( ObjectIdentifier&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

ObjectIdentifier::~ObjectIdentifier()
{
    if ( _state != NULL ) delete _state;
}

ObjectIdentifier::ObjectIdentifier( const akv::string_t& collection, const akv::string_t& identifier )
{
    if ( collection.empty() ) throw invalid_argument( "collection" );
    if ( identifier.empty() ) throw invalid_argument( "identifier" );

    uri  baseUri( identifier );
    // NOTE: split_path is rather crude if the identifier contains the host name
    auto segments = uri::split_path( baseUri.path() );

    // We expect an identifier with either 2 or 3 segments: collection + name [+ version]
    if ( segments.size() != 2 && segments.size() != 3 ) throw invalid_argument( "identifier" );

    if ( segments[0] != collection ) throw invalid_argument( "collection" );

    unique_ptr<State> state( new State() );

    // The name is just the name from the identifier without collection or version
    state->_name = segments[1];

    if ( segments.size() == 3 )
        state->_version = segments[2];
    else
        state->_version = __T("");

    state->_vault              = baseUri.scheme() + __T("://") + full_authority( baseUri );
    state->_vaultWithoutScheme = full_authority( baseUri );
    state->_baseIdentifier     = state->_vault + __T("/") + collection + __T("/") + state->_name;
    state->_identifier         = state->_baseIdentifier;

    if ( !state->_version.empty() ) state->_identifier = state->_identifier + __T("/") + state->_version;

    _state = state.release();
}

akv::string_t ObjectIdentifier::vault() const
{
    return _state->_vault;
}

akv::string_t ObjectIdentifier::name() const
{
    return _state->_name;
}

akv::string_t ObjectIdentifier::base_identifier() const
{
    return _state->_baseIdentifier;
}

akv::string_t ObjectIdentifier::identifier() const
{
    return _state->_identifier;
}

//
// SecretIdentifier
//
struct SecretIdentifier::State
{
};

bool SecretIdentifier::is_secret_identifier( const akv::string_t& identifier )
{
    return ObjectIdentifier::is_object_identifier( __T( "secrets" ), identifier );
}

// Default ctor
SecretIdentifier::SecretIdentifier( const akv::string_t& identifier ) : ObjectIdentifier( __T("secrets"), identifier )
{
    _state = new State();
}

// Copy ctor
SecretIdentifier::SecretIdentifier( const SecretIdentifier& other ) : ObjectIdentifier( other )
{
    unique_ptr<State> state( new State() );

    _state = state.release();
}

// Move ctor
SecretIdentifier::SecretIdentifier( SecretIdentifier&& other ) : ObjectIdentifier( other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
SecretIdentifier& SecretIdentifier::operator = ( const SecretIdentifier& other )
{
    ObjectIdentifier::operator = ( other );

    return *this;
}

// Move assignment
SecretIdentifier& SecretIdentifier::operator = ( SecretIdentifier&& other )
{
    ObjectIdentifier::operator = ( other );
    
    delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

SecretIdentifier::~SecretIdentifier()
{
    if ( _state != NULL ) delete _state;
}


//
// KeyIdentifier
//
struct KeyIdentifier::State
{
};

bool KeyIdentifier::is_key_identifier( const akv::string_t& identifier )
{
    return ObjectIdentifier::is_object_identifier( __T( "keys" ), identifier );
}

// Default ctor
KeyIdentifier::KeyIdentifier( const akv::string_t& identifier ) : ObjectIdentifier( __T("keys"), identifier )
{
    _state = new State();
}

// Copy ctor
KeyIdentifier::KeyIdentifier( const KeyIdentifier& other ) : ObjectIdentifier( other )
{
    unique_ptr<State> state( new State() );

    _state = state.release();
}

// Move ctor
KeyIdentifier::KeyIdentifier( KeyIdentifier&& other ) : ObjectIdentifier( other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
KeyIdentifier& KeyIdentifier::operator = ( const KeyIdentifier& other )
{
    ObjectIdentifier::operator = ( other );
    
    return *this;
}

// Move assignment
KeyIdentifier& KeyIdentifier::operator = ( KeyIdentifier&& other )
{
    ObjectIdentifier::operator = ( other );
    
    delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

KeyIdentifier::~KeyIdentifier()
{
    if ( _state != NULL ) delete _state;
}

}
