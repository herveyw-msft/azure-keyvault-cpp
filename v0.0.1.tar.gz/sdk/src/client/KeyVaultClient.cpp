/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

// CPP REST SDK
#include <cpprest/http_client.h>


#include "akv/common/string_t.h"
#include "common/mutex_t.h"
#include "common/time_t.h"
#include "common/url.h"

#include "akv/common/base64.h"

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/authentication/AuthenticationException.h"
#include "akv/authentication/AuthenticationContext.h"
#include "akv/authentication/HttpChallenge.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"
#include "akv/cryptography/Key.h"
#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/RsaKey.h"

#include "akv/client/ObjectIdentifier.h"
#include "akv/client/ObjectAttributes.h"
#include "akv/client/KeyBundle.h"
#include "akv/client/SecretBundle.h"
#include "akv/client/KeyVaultClientException.h"
#include "akv/client/KeyVaultClient.h"

#include "akv/jose/JsonWebKey.h"

#include "client/HttpMessageProtectionKey.h"
#include "client/HttpMessage.h"
#include "client/HttpMessageSecurity.h"
#include "client/KeyVaultRequestResponse.h"

using namespace std;
using namespace pplx;
using namespace web;
using namespace web::http;
using namespace web::http::client;

namespace akv {

using namespace akv::common;
using namespace akv::authentication;
using namespace akv::cryptography;
using namespace akv::jose;

static akv::string_t ApiVersion( __T( "?api-version=2016-10-01" ) );
static akv::string_t ContentTypeJson( __T( "application/json" ) );

// Service Encryption Key Cache
typedef map<akv::string_t, shared_ptr<KeyBundle>>  EncryptionKeyMap;
typedef pair<akv::string_t, shared_ptr<KeyBundle>> EncryptionKeyEntry;

static EncryptionKeyMap _cache;
static akv::mutex_t     _cacheLock;

// Service WWW-Authenticate cache
static std::map<akv::string_t, std::shared_ptr<HttpChallenge>> _challengeMap;

// Check for request to keys namespace
static bool is_key_request( const akv::string_t& identifier )
{
    if ( identifier.empty() ) return false;

    try
    {
        auto baseUri  = uri( identifier );
        // NOTE: split_path is rather crude if the identifier contains the host name
        auto segments = uri::split_path( baseUri.path() );

        // We expect an identifier with either 3 or 4 segments:
        // collection + name + operation
        // collection + name + version + operation
        if ( segments.size() != 3 && segments.size() != 4 )
            return false;

        if ( segments[0] != __T( "keys" ) )
            return false;

        return true;
    }
    catch ( ... )
    {
        // Intentionally empty
    }

    return false;
}

//
// Specialization of from_json for IKey::EncryptResult
//
template<>
std::shared_ptr<IKey::EncryptResult> from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        shared_ptr<IKey::EncryptResult> result( new IKey::EncryptResult() );

        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("kid") ) == 0 )
                result->kid = field->second.as_string();
            else if ( field->first.compare( __T("value") ) == 0 )
                result->value = Base64::decode_url( field->second.as_string() );
        }

        return result;
    }

    throw invalid_argument( "value" );
}

//
// Specialization of from_json for IKey::DecryptResult
//
template<>
std::shared_ptr<IKey::DecryptResult> from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        shared_ptr<IKey::DecryptResult> result( new IKey::DecryptResult() );

        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("kid") ) == 0 )
                result->kid = field->second.as_string();
            else if ( field->first.compare( __T("value") ) == 0 )
                result->value = Base64::decode_url( field->second.as_string() );
        }

        return result;
    }

    throw invalid_argument( "value" );
}

//
// Specialization of from_json for IKey::WrapResult
//
template<>
std::shared_ptr<IKey::WrapResult> from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        shared_ptr<IKey::WrapResult> result( new IKey::WrapResult() );

        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("kid") ) == 0 )
                result->kid = field->second.as_string();
            else if ( field->first.compare( __T("value") ) == 0 )
                result->value = Base64::decode_url( field->second.as_string() );
        }

        return result;
    }

    throw invalid_argument( "value" );
}

//
// Specialization of from_json for IKey::UnwrapResult
//
template<>
std::shared_ptr<IKey::UnwrapResult> from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        shared_ptr<IKey::UnwrapResult> result( new IKey::UnwrapResult() );

        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("kid") ) == 0 )
                result->kid = field->second.as_string();
            else if ( field->first.compare( __T("value") ) == 0 )
                result->value = Base64::decode_url( field->second.as_string() );
        }

        return result;
    }

    throw invalid_argument( "value" );
}

//
// Specialization of from_json for IKey::SignResult
//
template<>
std::shared_ptr<IKey::SignResult> from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        shared_ptr<IKey::SignResult> result( new IKey::SignResult() );

        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("kid") ) == 0 )
                result->kid = field->second.as_string();
            else if ( field->first.compare( __T("value") ) == 0 )
                result->value = Base64::decode_url( field->second.as_string() );
        }

        return result;
    }

    throw invalid_argument( "value" );
}

//
// Specialization of from_json for IKey::VerifyResult
//
template<>
std::shared_ptr<IKey::VerifyResult> from_json( const web::json::value& value )
{
    if ( value.is_object() )
    {
        shared_ptr<IKey::VerifyResult> result( new IKey::VerifyResult() );

        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("kid") ) == 0 )
                result->kid = field->second.as_string();
            else if ( field->first.compare( __T("value") ) == 0 )
                result->value = field->second.as_bool();
        }

        return result;
    }

    throw invalid_argument( "value" );
}

struct KeyVaultClient::State
{
    AuthenticationCallback _authenticationCallback;
};

KeyVaultClient::KeyVaultClient( AuthenticationCallback authenticationCallback )
{
    unique_ptr<State> state( new State() );

    state->_authenticationCallback = authenticationCallback;

    _state = state.release();
}

KeyVaultClient::~KeyVaultClient()
{
    if ( _state != NULL ) delete _state;
}

/// <summary>
/// Attempts to establish the security parameters for a specific message.
/// </summary>
task<shared_ptr<HttpMessageSecurity>> KeyVaultClient::get_message_security( const web::uri& httpUrl, const akv::string_t& httpMethod )
{
    auto challenge = _challengeMap[full_authority( httpUrl )];

    if ( challenge != nullptr )
    {
        // We have a cached challenge, so use its parameters to request a token.
        //
        // NOTE: There is a special dance here for managed dedicated slices in
        //       AKV. If the challenge indicates that the vault supports PoP and
        //       the outgoing call is for the keys namespace, then we swizzle to
        //       a PoP token. The message-kek property only exists on challenges
        //       for managed dedicated slices.
        auto scheme     = challenge->scheme();
        auto messageKek = challenge->getParameter( __T("message-kek") );

        if ( is_key_request( httpUrl.to_string() ) )
        {
            if ( !messageKek.empty() )
            {
                if ( httpMethod.compare( __T( "POST" ) ) == 0 )
                {
                    scheme = __T( "PoP" );
                }
            }
        }
        
        // Request an access token from the containing application using its callback.
        // Note that we use a task based continuation so that exceptions are accessible
        // within our continuation.
        return _state->_authenticationCallback( scheme, challenge->authority(), challenge->resource(), challenge->scope() ).then( [this, scheme, challenge]( task<shared_ptr<AccessToken>> previous )
        {
            shared_ptr<AccessToken> token;

            try
            {
                // Handle any exceptions from the authentication step when triggered by get()
                token = previous.get();
            }
            catch ( AuthenticationException& ex )
            {
                throw KeyVaultClientException( ex.status_code(), ex.error(), ex.error_description() );
            }
            catch ( ... )
            {
                throw KeyVaultClientException( 0, __T( "Authentication Failed" ), __T( "An unknown error occurred in the authentication callback" ) );
            }

            auto messageKek = challenge->getParameter( __T( "message-kek" ) );

            if ( scheme.compare( __T("PoP") ) == 0 && !messageKek.empty() )
            {
                // Attempt to retrieve the message encryption key from the cache
                shared_ptr<KeyBundle> encryption_key = get_cached_key( messageKek );

                if ( encryption_key != nullptr )
                {
                    return create_task( [this, token, encryption_key]()
                    {
                        std::shared_ptr<IKey> inner = make_shared<RsaKey>( encryption_key->web_key().kid(), encryption_key->web_key().to_rsa_parameters() );

                        shared_ptr<HttpMessageSecurity> security( new HttpMessageSecurity() );

                        security->clientSecurityToken = token->token();
                        security->clientSignatureKey  = token->key();
                        security->clientEncryptionKey = make_shared<HttpMessageProtectionKey>( JsonWebKey::KeyTypes::Rsa() );
                        security->serverSignatureKey  = inner;
                        security->serverEncryptionKey = inner;

                        return security;
                    } );
                }
                else
                {
                    return this->key_get( messageKek ).then( [this, messageKek, token]( shared_ptr<KeyBundle> keyBundle )
                    {
                        // Attempt to cache
                        put_cached_key( messageKek, keyBundle );

                        std::shared_ptr<IKey> inner = make_shared<RsaKey>( keyBundle->web_key().kid(), keyBundle->web_key().to_rsa_parameters() );

                        shared_ptr<HttpMessageSecurity> security( new HttpMessageSecurity() );

                        security->clientSecurityToken = token->token();
                        security->clientSignatureKey  = token->key();
                        security->clientEncryptionKey = make_shared<HttpMessageProtectionKey>( JsonWebKey::KeyTypes::Rsa() );
                        security->serverSignatureKey  = inner;
                        security->serverEncryptionKey = inner;

                        return security;
                    } );
                }
            }
            else
            {
                return create_task( [token]()
                {
                    shared_ptr<HttpMessageSecurity> security( new HttpMessageSecurity() );

                    security->clientSecurityToken = token->token();
                    security->clientSignatureKey  = token->key();
                    security->clientEncryptionKey = nullptr;
                    security->serverSignatureKey  = nullptr;
                    security->serverEncryptionKey = nullptr;

                    return security;
                } );
            }
        } );
    }

    return pplx::create_task( []()
    {
        return shared_ptr<HttpMessageSecurity>( nullptr );
    } );
}

// Keys interface

pplx::task<shared_ptr<KeyBundle>> KeyVaultClient::key_import( const akv::string_t& keyIdentifier, const akv::KeyBundle& key, const pplx::cancellation_token& cancel_token )
{
    if ( !KeyIdentifier::is_key_identifier( keyIdentifier ) ) throw invalid_argument( "keyIdentifier" );

    return object_put<KeyBundle>( keyIdentifier, key, cancel_token );
}

pplx::task<shared_ptr<KeyBundle>> KeyVaultClient::key_delete( const akv::string_t& keyIdentifier, const pplx::cancellation_token& cancel_token )
{
    if ( !KeyIdentifier::is_key_identifier( keyIdentifier ) ) throw invalid_argument( "keyIdentifier" );

    return object_delete<KeyBundle>( keyIdentifier, cancel_token );
}

pplx::task<shared_ptr<KeyBundle>> KeyVaultClient::key_get( const akv::string_t& keyIdentifier, const pplx::cancellation_token& cancellationToken )
{
    if ( !KeyIdentifier::is_key_identifier( keyIdentifier ) ) throw invalid_argument( "keyIdentifier" );

    return object_get<KeyBundle>( keyIdentifier, cancellationToken );
}

pplx::task<IKey::EncryptResult> KeyVaultClient::key_encrypt( const akv::string_t& key_identifier, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token )
{
    return key_operation<IKey::EncryptResult>( key_identifier, __T("encrypt"), algorithm_name, value, cancellation_token );
}

pplx::task<IKey::DecryptResult> KeyVaultClient::key_decrypt( const akv::string_t& key_identifier, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token )
{
    return key_operation<IKey::DecryptResult>( key_identifier, __T("decrypt"), algorithm_name, value, cancellation_token );
}

pplx::task<IKey::WrapResult> KeyVaultClient::key_wrap( const akv::string_t& key_identifier, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token )
{
    return key_operation<IKey::WrapResult>( key_identifier, __T("wrapKey"), algorithm_name, value, cancellation_token );
}

pplx::task<IKey::UnwrapResult> KeyVaultClient::key_unwrap( const akv::string_t& key_identifier, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token )
{
    return key_operation<IKey::UnwrapResult>( key_identifier, __T("unwrapKey"), algorithm_name, value, cancellation_token );
}

pplx::task<IKey::SignResult> KeyVaultClient::key_sign( const akv::string_t& key_identifier, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token )
{
    return key_operation<IKey::SignResult>( key_identifier, __T("sign"), algorithm_name, value, cancellation_token );
}

pplx::task<IKey::VerifyResult> KeyVaultClient::key_verify( const akv::string_t& key_identifier, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token )
{
    if ( !KeyIdentifier::is_key_identifier( key_identifier ) ) throw invalid_argument( "key_identifier" );
    if ( algorithm_name.empty() ) throw invalid_argument( "algorithm_name" );
    if ( digest.empty() ) throw invalid_argument( "digest" );
    if ( value.empty() ) throw invalid_argument( "value" );

    std::shared_ptr<HttpMessage> httpMessage( new HttpMessage( methods::POST ) );

    httpMessage->body()[__T( "alg" )]    = web::json::value::string( algorithm_name );
    httpMessage->body()[__T( "digest" )] = web::json::value::string( Base64::encode_url( digest ) );
    httpMessage->body()[__T( "value" )]  = web::json::value::string( Base64::encode_url( value ) );

    return sendMessage<IKey::VerifyResult>( web::uri( key_identifier + __T( "/verify" ) + ApiVersion ), httpMessage, ResponseReader::read<IKey::VerifyResult>, cancellation_token ).then( []( shared_ptr<IKey::VerifyResult> result )
    {
        return *result;
    }, cancellation_token );
}

// Secrets interface

// Get a secret
pplx::task<shared_ptr<SecretBundle>> KeyVaultClient::secret_get( const akv::string_t& secretIdentifier, const pplx::cancellation_token& cancellationToken )
{
    if ( !SecretIdentifier::is_secret_identifier( secretIdentifier ) ) throw invalid_argument( "secretIdentifier" );

    return object_get<SecretBundle>( secretIdentifier, cancellationToken );
}

//Set a secret
pplx::task<shared_ptr<SecretBundle>> KeyVaultClient::secret_set( const akv::string_t&                         secretIdentifier,
                                                                 const akv::string_t&                         value,
                                                                 const akv::string_t&                         content_type,
                                                                 const std::shared_ptr<akv::ObjectAttributes> attributes,
                                                                 const pplx::cancellation_token&              cancel_token )
{
	if ( !SecretIdentifier::is_secret_identifier(secretIdentifier) ) throw invalid_argument("secretIdentifier");

    std::shared_ptr<HttpMessage> httpMessage( new HttpMessage( methods::PUT ) );

    // TODO: How to set content type to empty?
    if ( !content_type.empty() )
        httpMessage->body()[__T( "contentType" )] = web::json::value::string( content_type );

    httpMessage->body()[__T( "value" )] = web::json::value::string( value );

    if ( attributes != nullptr )
        httpMessage->body()[__T( "attributes" )] = attributes->to_json();

    return sendMessage<SecretBundle>( web::uri( secretIdentifier + ApiVersion ), httpMessage, ResponseReader::read<SecretBundle>, cancel_token );
}

//
// Generalized methods
//

template<typename T>
pplx::task<T> KeyVaultClient::key_operation( const akv::string_t& keyIdentifier, const akv::string_t& operation, const akv::string_t& algorithm, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellationToken )
{
    if ( !KeyIdentifier::is_key_identifier( keyIdentifier ) ) throw invalid_argument( "keyIdentifier" );
    if ( algorithm.empty() ) throw invalid_argument( "algorithm" );
    if ( value.empty() ) throw invalid_argument( "value" );

    std::shared_ptr<HttpMessage> httpMessage( new HttpMessage( methods::POST ) );

    httpMessage->body()[__T( "alg" )]    = web::json::value::string( algorithm );
    httpMessage->body()[__T( "value" )]  = web::json::value::string( Base64::encode_url( value ) );

    return sendMessage<T>( web::uri( keyIdentifier + __T( "/" ) + operation + ApiVersion ), httpMessage, ResponseReader::read<T>, cancellationToken ).then( []( shared_ptr<T> result )
    {
        return *result;
    }, cancellationToken );
}

template<typename T>
pplx::task<std::shared_ptr<T>> KeyVaultClient::object_get( const akv::string_t& objectIdentifier, const pplx::cancellation_token& cancellationToken )
{
    std::shared_ptr<HttpMessage> httpMessage( new HttpMessage( methods::GET ) );

    return sendMessage<T>( web::uri( objectIdentifier + ApiVersion ), httpMessage, ResponseReader::read<T>, cancellationToken );
}

template<typename T>
pplx::task<std::shared_ptr<T>> KeyVaultClient::object_delete( const akv::string_t& objectIdentifier, const pplx::cancellation_token& cancellationToken )
{
    std::shared_ptr<HttpMessage> httpMessage( new HttpMessage( methods::DEL ) );

    return sendMessage<T>( web::uri( objectIdentifier + ApiVersion ), httpMessage, ResponseReader::read<T>, cancellationToken );
}

template<typename T>
pplx::task<std::shared_ptr<T>> KeyVaultClient::object_put( const akv::string_t& objectIdentifier, const T& object, const pplx::cancellation_token& cancellationToken )
{
    std::shared_ptr<HttpMessage> httpMessage( new HttpMessage( methods::PUT ) );

    web::json::value json_value = object.to_json();

    if ( json_value.is_object() )
    {
        web::json::object json_object = json_value.as_object();

        for ( auto property = json_object.cbegin(); property != json_object.cend(); property++ )
        {
            httpMessage->body()[property->first] = property->second;
        }

        return sendMessage<T>( web::uri( objectIdentifier + ApiVersion ), httpMessage, ResponseReader::read<T>, cancellationToken );
    }

    throw invalid_argument( "object" );
}

template<typename T>
task<shared_ptr<T>> KeyVaultClient::sendMessage( const uri&                                                                                        httpUrl,
                                                 const std::shared_ptr<HttpMessage>                                                                httpMessage,
                                                 std::function<task<shared_ptr<T>>( const http_response&, const shared_ptr<HttpMessageSecurity> )> httpResponseCallback,
                                                 const pplx::cancellation_token&                                                                   cancellationToken )
{
    // Authentication: attempt to pre-authenticate and then send the request
    return get_message_security( httpUrl, httpMessage->method() ).then( [this, httpUrl, httpMessage, httpResponseCallback, cancellationToken]( shared_ptr<HttpMessageSecurity> security )
    {
        shared_ptr<http_client>  httpClient  = std::make_shared<http_client>( httpUrl.to_string() );
        shared_ptr<http_request> httpRequest;

        // add access token we got from authentication step
        if ( security != nullptr && !security->clientSecurityToken.empty() )
        {
            httpRequest = RequestWriter::write( httpMessage, security ).get();
        }
        else
        {
            // We don't have an access token, so we don't send a real message 
            // to the service until we know how we should authenticate, we just
            // send the bare bones request without an entity body.
            httpRequest = make_shared<http_request>( httpMessage->method() );
            httpRequest->headers()[__T( "Content-Length" )] = __T("0");
        }

        // Make the HTTP request: if we had an access token, this will be the real request; if we didn't, then this is a proxy request with
        // no entity body so that we don't disclose anything to the service.
        return httpClient->request( *httpRequest ).then( [this, httpClient, httpMessage, httpResponseCallback, security, cancellationToken]( http_response response )
        {
            web::uri          httpUrl = httpClient->base_uri();
            utility::string_t header;
            akv::string_t     messageKek;

            switch ( response.status_code() )
            {
            case 401:
                // There may be a separate HTTP header (x-ms-message-key-encryption-key-id) that carries the URL of the key
                // in the key vault that is used to target any encrypted requests.
                header = response.headers()[__T( "x-ms-message-key-encryption-key-id" )];

                if ( !header.empty() )
                {
                    header = trim( header );

                    if ( web::uri::validate( header ) )
                    {
                        messageKek = header;
                    }
                }

                // Not Authorized. Extract the WWW-Authenticate header and see whether it is a challenge that we can handle.
                header = response.headers()[__T("WWW-Authenticate")];

                if ( HttpBearerChallenge::isBearerChallenge( header ) )
                {
                    // Update the map of challenges
                    auto httpChallenge = make_shared<HttpBearerChallenge>( httpUrl.to_string(), header );

                    if ( httpChallenge->getParameter( __T( "supportspop" ) ).compare( __T( "true" ) ) == 0 )
                    {
                        // The service claims PoP support for targeted messages so remember the messageKek
                        if ( !messageKek.empty() )
                            httpChallenge->setParameter( __T( "message-kek" ), messageKek );
                    }

                    // Update the challenge map
                    _challengeMap[ full_authority( httpUrl ) ] = httpChallenge;
                }
                else if ( HttpPoPChallenge::isPoPChallenge( header ) )
                {
                    // Update the map of challenges
                    auto httpChallenge = make_shared<HttpPoPChallenge>( httpUrl.to_string(), header );

                    // The service claims PoP support for targeted messages so remember the messageKek
                    if ( !messageKek.empty() )
                        httpChallenge->setParameter( __T( "message-kek" ), messageKek );

                    _challengeMap[ full_authority( httpUrl ) ] = httpChallenge;
                }
                else
                {
                    throw KeyVaultClientException( response.status_code(), __T( "Unauthorized" ) );
                }
                    
                // Attempt to get a token and re-issue the real request
                return get_message_security( httpUrl, httpMessage->method() ).then( [this, httpClient, httpMessage, httpResponseCallback, security, cancellationToken ]( shared_ptr<HttpMessageSecurity> security )
                {
                    if ( security->clientSecurityToken.empty() )
                    {
                        // This time, if we do not have an access token we cannot proceed.
                        // TODO: We should throw something else here to indicate that we did not get an access token
                        //       although its possible that the get_message_security call may have already throw.
                        throw KeyVaultClientException( 401, __T( "Unauthorized, no authentication token was available" ) );
                    }
                    else
                    {
                        return RequestWriter::write( httpMessage, security ).then( [this, httpClient, httpResponseCallback, security, cancellationToken]( shared_ptr<http_request> httpRequest )
                        {

                            // Make the real request this time, not the proxy request.
                            return httpClient->request( *httpRequest, cancellationToken ).then( [httpResponseCallback, security, cancellationToken]( http_response response )
                            {
                                return httpResponseCallback( response, security );
                            }, cancellationToken );
                        }, cancellationToken );
                    }
                }, cancellationToken );
                break;

            default:
                // Return the response that was received
                return httpResponseCallback( response, security );
            }
        }, cancellationToken );
    }, cancellationToken );
}

// Message Encryption Key Caching

shared_ptr<KeyBundle> KeyVaultClient::get_cached_key( const akv::string_t& key_identifier )
{
    try
    {
        akv::lock_guard_t lock( _cacheLock );

        auto cache_entry = _cache.find( key_identifier );

        if ( cache_entry != _cache.end() )
        {
            time_t current_time;
            double seconds;

            time( &current_time );
            seconds = difftime( cache_entry->second->attributes().exp(), current_time );

            // We allow a 5 minute clock skew: if the token has less than 5 minutes 
            // of life left, then we consider it already expired.
            if ( seconds < 300 )
            {
                _cache.erase( key_identifier );
            }
            else
            {
                return cache_entry->second;
            }
        }
    }
    catch ( ... )
    {
        // Intentionally empty
    }

    // Don't throw here, just return nullptr if there is no token.
    return nullptr;
}

std::shared_ptr<KeyBundle> KeyVaultClient::put_cached_key( const akv::string_t& key_identifier, shared_ptr<KeyBundle> key )
{
    try
    {
        akv::lock_guard_t lock( _cacheLock );

        _cache.insert( EncryptionKeyEntry( key_identifier, key ) );
    }
    catch ( ... )
    {
        // Intentionally empty
    }

    return key;
}

void KeyVaultClient::flush_cached_keys()
{
    try
    {
        akv::lock_guard_t lock( _cacheLock );

        _cache.clear();
    }
    catch ( ... )
    {
        // Intentionally empty
    }
}


}
