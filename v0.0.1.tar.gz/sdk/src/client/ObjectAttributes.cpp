/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/time_t.h"

#include "akv/client/ObjectAttributes.h"

using namespace std;
using namespace web;

namespace akv {

struct ObjectAttributes::State
{
    State()
    {
        _enabled = true;
        _nbf     = 0;
        _exp     = INT64_MAX;
        _created = utc_now();
        _updated = 0;
    };

    State( const State& )              = default;
    State& operator = ( const State& ) = default;

    bool    _enabled;
    int64_t _nbf;
    int64_t _exp;
    int64_t _created;
    int64_t _updated;
};

std::shared_ptr<ObjectAttributes> ObjectAttributes::from_string( const akv::string_t& src )
{
    if ( src.empty() )
        throw invalid_argument( "src" );

    std::error_code error;
    auto            value = web::json::value::parse( src, error );

    return ObjectAttributes::from_json( value );
}

std::shared_ptr<ObjectAttributes> ObjectAttributes::from_json( const web::json::value& value )
{
    std::shared_ptr<ObjectAttributes> result( new ObjectAttributes() );

    if ( value.is_object() )
    {
        json::object object = value.as_object();

        for ( auto field = object.cbegin(); field != object.cend(); field++ )
        {
            if ( field->first.compare( __T("enabled") ) == 0 )
                result->_state->_enabled = field->second.as_bool();
            else if ( field->first.compare( __T("nbf") ) == 0 )
                result->_state->_nbf = field->second.as_integer();
            else if ( field->first.compare( __T("exp") ) == 0 )
                result->_state->_exp = field->second.as_integer();
            else if ( field->first.compare( __T("created") ) == 0 )
                result->_state->_created = field->second.as_integer();
            else if ( field->first.compare( __T("updated") ) == 0 )
                result->_state->_updated = field->second.as_integer();
        }
    }

    return result;
}

// Default ctor
ObjectAttributes::ObjectAttributes()
{
    _state = new State();
}

// Copy ctor
ObjectAttributes::ObjectAttributes( const ObjectAttributes& other )
{
    _state = new State( *other._state );
}

// Move ctor
ObjectAttributes::ObjectAttributes( ObjectAttributes && other )
{
    _state = other._state;
    other._state = NULL;
}

// Copy assignment
ObjectAttributes& ObjectAttributes::operator = ( const ObjectAttributes& other )
{
    _state->operator = ( *other._state );

    return *this;
}

// Move assignment
ObjectAttributes& ObjectAttributes::operator = ( ObjectAttributes&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

ObjectAttributes::~ObjectAttributes()
{
    if ( _state != NULL ) delete _state;
}

bool ObjectAttributes::enabled() const
{
    return _state->_enabled;
}

void ObjectAttributes::enabled( bool value )
{
    _state->_enabled = value;
}

int64_t ObjectAttributes::nbf() const
{
    return _state->_nbf;
}

void ObjectAttributes::nbf( int64_t value )
{
    if ( value < 0 )
        throw invalid_argument( "value" );

    _state->_nbf = value;
}

int64_t ObjectAttributes::exp() const
{
    return _state->_exp;
}

void ObjectAttributes::exp( int64_t value )
{
    if ( value < 0 )
        throw invalid_argument( "value" );

    _state->_exp = value;
}

int64_t ObjectAttributes::created() const
{
    return _state->_created;
}

int64_t ObjectAttributes::updated() const
{
    return _state->_updated;
}

web::json::value ObjectAttributes::to_json() const
{
    std::vector<std::pair<akv::string_t, web::json::value>> properties;

    properties.push_back( std::make_pair( __T("enabled"), web::json::value::boolean( _state->_enabled ) ) );
    properties.push_back( std::make_pair( __T("nbf"), web::json::value::number( _state->_nbf ) ) );
    properties.push_back( std::make_pair( __T("exp"), web::json::value::number( _state->_exp ) ) );

    return web::json::value::object( properties );

}

}
