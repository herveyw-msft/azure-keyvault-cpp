/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/string_t.h"

#include "akv/client/KeyVaultClientException.h"

using namespace std;

namespace akv {

struct KeyVaultClientException::State
{
    unsigned short _status;
    akv::string_t  _error;
    akv::string_t  _error_description;
};

KeyVaultClientException::KeyVaultClientException( unsigned short status, const akv::string_t& error )
{
    unique_ptr<State> state( new State() );

    state->_error  = error;
    state->_status = status;

    _state = state.release();
}

KeyVaultClientException::KeyVaultClientException( unsigned short status, const akv::string_t& error, const akv::string_t& error_description )
{    
    unique_ptr<State> state( new State() );

    state->_error             = error;
    state->_error_description = error_description;
    state->_status            = status;

    _state = state.release();
}

KeyVaultClientException::KeyVaultClientException( const KeyVaultClientException& other )
{
    unique_ptr<State> state( new State() );

    state->_error             = other._state->_error;
    state->_error_description = other._state->_error_description;
    state->_status            = other._state->_status;

    _state = state.release();
}

KeyVaultClientException& KeyVaultClientException::operator = ( const KeyVaultClientException& other )
{
    _state->_error             = other._state->_error;
    _state->_error_description = other._state->_error_description;
    _state->_status            = other._state->_status;

    return *this;
}

KeyVaultClientException::KeyVaultClientException( KeyVaultClientException&& other )
{
    _state = other._state;
    other._state = NULL;
}

KeyVaultClientException& KeyVaultClientException::operator = ( KeyVaultClientException&& other )
{
    _state = other._state;
    other._state = NULL;

    return *this;
}

KeyVaultClientException::~KeyVaultClientException()
{
    if ( _state != NULL ) delete _state;
}

unsigned short KeyVaultClientException::status_code() const
{
    return _state->_status;
}

const akv::string_t& KeyVaultClientException::error() const
{
    return _state->_error;
}

const akv::string_t& KeyVaultClientException::error_description() const
{
    return _state->_error_description;
}

}
