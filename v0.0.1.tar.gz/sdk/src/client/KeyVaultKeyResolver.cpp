/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/common/string_t.h"

#include "akv/cryptography/AlgorithmResolver.h"
#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/Key.h"
#include "akv/cryptography/RsaKey.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/client/KeyBundle.h"
#include "akv/client/KeyVaultClient.h"
#include "akv/client/KeyVaultKey.h"
#include "akv/client/KeyVaultKeyResolver.h"

using namespace akv;
using namespace akv::common;
using namespace akv::cryptography;
using namespace akv::jose;
using namespace std;
using namespace pplx;

namespace akv {

struct KeyVaultKeyResolver::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    shared_ptr<KeyVaultClient> _client;
};

KeyVaultKeyResolver::KeyVaultKeyResolver( KeyVaultClient::AuthenticationCallback callback )
{
    unique_ptr<State> state( new State() );

    state->_client = make_shared<KeyVaultClient>( callback );

    _state = state.release();
}

KeyVaultKeyResolver::~KeyVaultKeyResolver()
{
    if ( NULL != _state ) delete _state;
}

pplx::task<std::shared_ptr<IKey>> KeyVaultKeyResolver::resolve_key( const akv::string_t& kid, const pplx::cancellation_token& cancellationToken ) const
{
    auto self           = this;
    auto resolveKeyTask = _state->_client->key_get( kid, cancellationToken );

    return resolveKeyTask.then( [self]( shared_ptr<KeyBundle> key_bundle ) -> shared_ptr<IKey>
    {
        return make_shared<KeyVaultKey>( self->_state->_client, key_bundle );
    }, cancellationToken );
}

}
