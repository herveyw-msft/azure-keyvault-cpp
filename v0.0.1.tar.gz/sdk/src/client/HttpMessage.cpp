/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "client/HttpMessage.h"

using namespace std;

namespace akv {

akv::string_t HttpMessage::serialize() const
{
    if ( !_body.empty() )
    {
        std::shared_ptr<akv::string_t> result = std::make_shared<akv::string_t>( __T( "{" ) );

        if ( _body.size() != 0 )
        {
            auto begin = _body.cbegin();

            result->append( __T( "\"" ) + begin->first + __T( "\":" ) + begin->second.serialize() );

            begin++;

            std::for_each( begin, _body.cend(), [result]( std::pair<akv::string_t, web::json::value> element ) {

                result->append( __T( ",\"" ) + element.first + __T( "\":" ) + element.second.serialize() );
            } );
        }

        result->append( __T( "}" ) );

        return *result;
    }

    return akv::string_t();
}

HttpMessage::HttpMessage( const web::http::method& method ) : _method( method ), _body( web::json::value::object().as_object() )
{
    if ( _method.empty() )
        throw invalid_argument( "method" );
}

const web::http::method& HttpMessage::method() const
{
    return _method;
}

web::json::object& HttpMessage::body()
{
    return _body;
}

}
