/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/common/string_t.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/Key.h"
#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/RsaKey.h"

#include "akv/jose/JsonWebKey.h"

#include "akv/client/KeyBundle.h"
#include "akv/client/KeyVaultClientException.h"
#include "akv/client/KeyVaultClient.h"
#include "akv/client/KeyVaultKey.h"

using namespace akv;
using namespace std;

namespace akv {

struct KeyVaultKey::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    shared_ptr<KeyVaultClient>   _client;
    unordered_set<akv::string_t> _key_ops;
    shared_ptr<IKey>             _inner;
};

KeyVaultKey::KeyVaultKey( shared_ptr<KeyVaultClient> client, const shared_ptr<KeyBundle> key_bundle )
{
    if ( nullptr == client ) throw invalid_argument( "client" );
    if ( nullptr == key_bundle ) throw invalid_argument( "key_bundle" );

    unique_ptr<State> state( new State() );

    state->_client  = client;
    state->_key_ops = key_bundle->web_key().key_ops();

    // RSA key
    if ( common::starts_with( key_bundle->web_key().kty(), jose::JsonWebKey::KeyTypes::Rsa() ) ||
         common::starts_with( key_bundle->web_key().kty(), jose::JsonWebKey::KeyTypes::RsaHsm() ))
    {
        state->_inner = make_shared<cryptography::RsaKey>( key_bundle->web_key().kid(), key_bundle->web_key().to_rsa_parameters( false ) );
    }
    else
    {
        throw invalid_argument( "key_bundle key type is not supported" );
    }

    _state = state.release();
}

KeyVaultKey::~KeyVaultKey()
{
    if ( NULL != _state ) delete _state;
}

akv::string_t KeyVaultKey::kid() const
{
    return _state->_inner->kid();
}

akv::string_t KeyVaultKey::defaultEncryptionAlgorithm() const
{
    return _state->_inner->defaultEncryptionAlgorithm();
}

akv::string_t KeyVaultKey::defaultKeyWrapAlgorithm() const
{
    return _state->_inner->defaultKeyWrapAlgorithm();
}

akv::string_t KeyVaultKey::defaultSignatureAlgorithm() const
{
    return _state->_inner->defaultSignatureAlgorithm();
}

pplx::task<IKey::DecryptResult> KeyVaultKey::decrypt( const akv::string_t&            algorithm,
                                                      const std::vector<akv::byte_t>& ciphertext,
                                                      const std::vector<akv::byte_t>& iv,
                                                      const std::vector<akv::byte_t>& authenticationData,
                                                      const std::vector<akv::byte_t>& authenticationTag,
                                                      const pplx::cancellation_token& token ) const
{
    // Decrypt must go to the service
    return _state->_client->key_decrypt( _state->_inner->kid(), algorithm, ciphertext, token );
}

pplx::task<IKey::EncryptResult> KeyVaultKey::encrypt( const akv::string_t&            algorithm,
                                                      const std::vector<akv::byte_t>& plaintext,
                                                      const std::vector<akv::byte_t>& iv,
                                                      const std::vector<akv::byte_t>& authenticationData,
                                                      const pplx::cancellation_token& token ) const
{
    // Check allowed
    if ( _state->_key_ops.empty() == false && _state->_key_ops.find( jose::JsonWebKey::KeyOperations::Encrypt() ) == _state->_key_ops.end() )
        throw KeyVaultClientException( 403, __T("The key does not allow the encrypt operation") );

    // Encrypt can be handled locally
    return _state->_inner->encrypt( algorithm, plaintext, iv, authenticationData, token );
}

pplx::task<IKey::WrapResult> KeyVaultKey::wrap( const akv::string_t&            algorithm,
                                                const std::vector<akv::byte_t>& key,
                                                const pplx::cancellation_token& token ) const
{
    // Check allowed
    if ( _state->_key_ops.empty() == false && _state->_key_ops.find( jose::JsonWebKey::KeyOperations::WrapKey() ) == _state->_key_ops.end() )
        throw KeyVaultClientException( 403, __T("The key does not allow the wrap operation") );

    // Wrap can be handled locally
    return _state->_inner->wrap( algorithm, key, token );
}

pplx::task<IKey::UnwrapResult> KeyVaultKey::unwrap( const akv::string_t&            algorithm,
                                                    const std::vector<akv::byte_t>& encryptedKey,
                                                    const pplx::cancellation_token& token ) const
{
    // Unwrap must go to the service
    return _state->_client->key_unwrap( _state->_inner->kid(), algorithm, encryptedKey, token );
}

/// <summary>
/// Signs the specified digest.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="token">Cancellation token</param>
/// <returns>The signature value</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::SignResult> KeyVaultKey::signHash( const akv::string_t&             algorithm,
                                                    const std::vector<akv::byte_t>&   digest,
                                                    const pplx::cancellation_token& token ) const
{
    // Sign must go to the service
    return _state->_client->key_sign( _state->_inner->kid(), algorithm, digest, token );
}

/// <summary>
/// Verifies the specified digest and signature.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="signature">The signature to verify</param>
/// <param name="token">Cancellation token</param>
/// <returns>True if the signature verifies</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::VerifyResult> KeyVaultKey::verifyHash( const akv::string_t&             algorithm,
                                                        const std::vector<akv::byte_t>&   digest,
                                                        const std::vector<akv::byte_t>&   signature,
                                                        const pplx::cancellation_token& token ) const
{
    // Check allowed
    if ( _state->_key_ops.empty() == false && _state->_key_ops.find( jose::JsonWebKey::KeyOperations::Verify() ) == _state->_key_ops.end() )
        throw KeyVaultClientException( 403, __T("The key does not allow the verify operation") );

    // Verify can be handled locally
    return _state->_inner->verifyHash( algorithm, digest, signature, token );
}

}
