/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/common/string_t.h"
#include "common/vector.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/IEncryptionTransform.h"
#include "akv/cryptography/IKeyWrapTransform.h"

#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/SymmetricEncryptionAlgorithm.h"

#include "akv/cryptography/KeyWrapAlgorithm.h"

#include "akv/cryptography/RandomNumberGenerator.h"

#include "akv/cryptography/Key.h"
#include "akv/cryptography/SymmetricKey.h"

using namespace akv;
using namespace std;
using namespace pplx;

namespace akv { namespace cryptography {

// TODO: This default iv is for AESKW
static const std::vector<akv::byte_t> DefaultIv { 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6 };

struct SymmetricKey::_Impl
{
    _Impl() { };
    ~_Impl() { SecureZeroMemory( _key ); };

    std::vector<akv::byte_t> _key;
};

SymmetricKey::SymmetricKey( const akv::string_t & kid ) : SymmetricKey( kid, DefaultKeySize )
{
}

SymmetricKey::SymmetricKey( const akv::string_t& kid, const int keySizeInBytes ) : Key( kid )
{
    // TODO: Parameter validation
    unique_ptr<_Impl> impl( new _Impl() );

    impl->_key = vector<akv::byte_t>( keySizeInBytes );

    RandomNumberGenerator::get_bytes( impl->_key );

    _impl = impl.release();
}

SymmetricKey::SymmetricKey( const akv::string_t& kid, const std::vector<akv::byte_t>& key ) : Key( kid )
{
    // TODO: Parameter validation
    unique_ptr<_Impl> impl( new _Impl() );

    impl->_key = key;

    _impl = impl.release();
}

SymmetricKey::~SymmetricKey()
{
    if ( NULL != _impl ) delete _impl;
}

akv::string_t SymmetricKey::defaultEncryptionAlgorithm() const
{
    switch ( _impl->_key.size() )
    {
    case KeySize128:
        return AlgorithmNames::Aes128Cbc();
        break;

    case KeySize192:
        return AlgorithmNames::Aes192Cbc();
        break;

    case KeySize256:
        return AlgorithmNames::Aes128CbcHmacSha256();
        break;

    case KeySize384:
        return AlgorithmNames::Aes192CbcHmacSha384();
        break;

    case KeySize512:
        return AlgorithmNames::Aes256CbcHmacSha512();
        break;

    default:
        throw runtime_error( "Invalid key size" );
        break;
    }
}

akv::string_t SymmetricKey::defaultKeyWrapAlgorithm() const
{
    switch ( _impl->_key.size() )
    {
    case KeySize128:
        return AlgorithmNames::Aes128Kw();
        break;

    case KeySize192:
        return AlgorithmNames::Aes192Kw();
        break;

    case KeySize256:
    case KeySize384:
    case KeySize512:
        return AlgorithmNames::Aes256Kw();
        break;

    default:
        throw runtime_error( "Invalid key size" );
        break;
    }
}

akv::string_t SymmetricKey::defaultSignatureAlgorithm() const
{
    switch ( _impl->_key.size() )
    {
    case KeySize128:
        return AlgorithmNames::Hs256();
        break;

    case KeySize192:
        return AlgorithmNames::Hs384();
        break;

    case KeySize256:
    case KeySize384:
    case KeySize512:
        return AlgorithmNames::Hs512();
        break;

    default:
        throw runtime_error( "Invalid key size" );
        break;
    }
}

pplx::task<IKey::DecryptResult> SymmetricKey::decrypt( const akv::string_t&            algorithm_name,
                                                       const std::vector<akv::byte_t>& cipher_text,
                                                       const std::vector<akv::byte_t>& iv,
                                                       const std::vector<akv::byte_t>& authentication_data,
                                                       const std::vector<akv::byte_t>& authentication_tag,
                                                       const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<SymmetricEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _impl->_key, iv, authentication_data );

    return decrypt_transform( transform, cipher_text, authentication_tag, token );
}

pplx::task<IKey::EncryptResult> SymmetricKey::encrypt( const akv::string_t&            algorithm_name,
                                                       const std::vector<akv::byte_t>& plain_text,
                                                       const std::vector<akv::byte_t>& iv,
                                                       const std::vector<akv::byte_t>& authentication_data,
                                                       const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<SymmetricEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _impl->_key, iv, authentication_data );

    return encrypt_transform( transform, plain_text, token );
}

pplx::task<IKey::WrapResult> SymmetricKey::wrap( const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& plain_text,
                                                 const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<KeyWrapAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _impl->_key, DefaultIv );

    return wrap_transform( transform, plain_text, token );
}

pplx::task<IKey::UnwrapResult> SymmetricKey::unwrap( const akv::string_t&            algorithm_name,
                                                     const std::vector<akv::byte_t>& cipher_text,
                                                     const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<KeyWrapAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _impl->_key, DefaultIv );

    return unwrap_transform( transform, cipher_text, token );
}

/// <summary>
/// Signs the specified digest.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="token">Cancellation token</param>
/// <returns>The signature value</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::SignResult> SymmetricKey::signHash( const akv::string_t&             algorithm,
                                                     const std::vector<akv::byte_t>&   digest,
                                                     const pplx::cancellation_token& token ) const
{
    throw std::runtime_error( "SymmetricKey::sign" );
}

/// <summary>
/// Verifies the specified digest and signature.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="signature">The signature to verify</param>
/// <param name="token">Cancellation token</param>
/// <returns>True if the signature verifies</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::VerifyResult> SymmetricKey::verifyHash( const akv::string_t&             algorithm,
                                                         const std::vector<akv::byte_t>&   digest,
                                                         const std::vector<akv::byte_t>&   signature,
                                                         const pplx::cancellation_token& token ) const
{
    throw std::runtime_error( "SymmetricKey::verify" );
}

} }
