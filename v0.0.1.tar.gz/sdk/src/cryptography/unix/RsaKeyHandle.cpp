/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include <cryptopp/cryptlib.h>
#include <cryptopp/filters.h>
#include <cryptopp/sha.h>
#include <cryptopp/oaep.h>
#include <cryptopp/pssr.h>
#include <cryptopp/rsa.h>
#include <cryptopp/osrng.h>

#include "akv/common/string_t.h"

#include "akv/cryptography/IncrementalHash.h"
#include "akv/cryptography/RsaParameters.h"

#include "common/vector.h"
#include "cryptography/RsaKeyHandle.h"

using namespace akv;
using namespace akv::common;
using namespace std;
using namespace CryptoPP;

namespace akv { namespace cryptography {

namespace rsa {

static const Integer           twoFiveSix ( 256 );
static const vector<akv::byte_t> sha256Prefix = { 0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00, 0x04, 0x20 };
static const vector<akv::byte_t> sha384Prefix = { 0x30, 0x41, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x02, 0x05, 0x00, 0x04, 0x30 };
static const vector<akv::byte_t> sha512Prefix = { 0x30, 0x51, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x03, 0x05, 0x00, 0x04, 0x40 };

int getOctetLength( const Integer& i ) {
    auto bits = i.BitCount();

    return ( bits % 8 > 0 ) ? ( bits >> 3 ) + 1 : bits >> 3; 
}

/*
 * See https://tools.ietf.org/html/rfc3447#section-4.2
 */
Integer OS2IP( const vector<akv::byte_t>& x ) {
    
    if ( x.size() == 0 ) {
        throw invalid_argument("x");
    }
    
    // TODO: Explicit parameter call does not compile on Linux
    //return Integer( x.data(), x.size(), Integer::Signedness::UNSIGNED, ByteOrder::BIG_ENDIAN_ORDER );
    return Integer( x.data(), x.size() );
}

/*
 * See https://tools.ietf.org/html/rfc3447#section-4.1
 */
vector<akv::byte_t> I2OSP( const Integer& x, int xLen ) {
    
    if ( xLen <= 0 ) {
        throw invalid_argument("xLen");
    }
    
    // if ( x.Compare( twoFiveSix.pow(xLen) ) == 1 ) {
    //     throw invalid_argument("integer too large");
    // }
    
    if ( x.MinEncodedSize() > xLen ) {
        throw invalid_argument("integer too large");
    }
    
    vector<akv::byte_t> bytes( x.MinEncodedSize() );

    x.Encode( bytes.data(), bytes.size(), Integer::Signedness::UNSIGNED );

    // Zero's pad into new buffer
    vector<akv::byte_t> result(xLen);
    
    std::copy( bytes.begin(), bytes.end(), result.end() - bytes.size() );
    // System.arraycopy(bytes, 0, result, xLen - bytes.length, bytes.length);
    
    return result;
}

/*
 * See https://tools.ietf.org/html/rfc3447#section-5.2.1
 */
Integer RSASP1( const InvertibleRSAFunction& K, const Integer& m ) {
    
    Integer n = K.GetModulus();
    Integer d = K.GetPrivateExponent();
    
    if ( m.Compare( Integer::One() ) == -1 || m.Compare(n) != -1 ) {
        throw invalid_argument("message representative out of range");
    }
    
    return a_exp_b_mod_c( m, d, n );
    //return m.modPow(d, n);
}

/*
 * See https://tools.ietf.org/html/rfc3447#section-5.2.2
 */
Integer RSAVP1( const RSAFunction& K, const Integer& s ) {
    
    Integer n = K.GetModulus();
    Integer e = K.GetPublicExponent();
    
    if ( s.Compare( Integer::One() ) == -1 || s.Compare(n) != -1 ) {
        throw invalid_argument("message representative out of range");
    }
    
    return a_exp_b_mod_c( s, e, n );
    //return s.modPow(e, n);
}

/*
 * See https://tools.ietf.org/html/rfc3447#section-9.2
 */
vector<akv::byte_t> EMSA_PKCS1_V1_5_ENCODE_HASH( const vector<akv::byte_t>& h, int emLen, RsaKeyHandle::SignatureMode signatureMode ) {
    
    // Check m
    if ( h.size() == 0 ) {
        throw invalid_argument("m");
    }
    
    vector<akv::byte_t> algorithmPrefix;
    
    // Only supported algorithms
    switch ( signatureMode )
    {
        case RsaKeyHandle::SignatureMode::RS256:
            algorithmPrefix = sha256Prefix;
            
            if ( h.size() != 32 ) throw invalid_argument("h is incorrect length for SHA-256");
            break;

        case RsaKeyHandle::SignatureMode::RS384:
            algorithmPrefix = sha384Prefix;
            
            if ( h.size() != 48 ) throw invalid_argument("h is incorrect length for SHA-384");
            break;

        case RsaKeyHandle::SignatureMode::RS512:
            algorithmPrefix = sha512Prefix;
            
            if ( h.size() != 64 ) throw invalid_argument("h is incorrect length for SHA-512");
            break;

        default:
            throw invalid_argument("signatureMode");
    }
    
    // Construct T, the DER encoded DigestInfo structure
    vector<akv::byte_t> T( algorithmPrefix.size() + h.size() );
    
    std::copy( algorithmPrefix.begin(), algorithmPrefix.end(), T.begin() );
    std::copy( h.begin(), h.end(), T.begin() + algorithmPrefix.size() );
    
    if ( emLen < T.size() + 11 ) {
        throw invalid_argument("intended encoded message length too short");
    }
    
    // Construct PS
    vector<akv::byte_t> PS( emLen - T.size() - 3 );
    
    for ( int i = 0; i < PS.size(); i++ ) PS[i] = (byte) 0xff;
    
    // Construct EM: EM = 0x00 || 0x01 || PS || 0x00 || T
    vector<akv::byte_t> EM( PS.size() + T.size() + 3 );
    
    EM[0] = 0x00; EM[1] = 0x01; EM[PS.size() + 2] = 0x00;
    
    std::copy( PS.begin(), PS.end(), EM.begin() + 2 );
    std::copy( T.begin(), T.end(), EM.begin() + PS.size() + 3 );
    // System.arraycopy(PS, 0, EM, 2, PS.length);
    // System.arraycopy(T, 0, EM, PS.length + 3, T.length);

    return EM;
}

/*
 * See https://tools.ietf.org/html/rfc3447#section-9.2
 */
vector<akv::byte_t> EMSA_PKCS1_V1_5_ENCODE( const vector<akv::byte_t>& m, int emLen, RsaKeyHandle::SignatureMode signatureMode ){
    
    // Check m
    if ( m.size() == 0 ) {
        throw invalid_argument("m");
    }
    
    shared_ptr<IncrementalHash> hash;
    
    // Only supported algorithms
    switch ( signatureMode ) {
        case RsaKeyHandle::SignatureMode::RS256:
            // Initialize digest
            hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA256 );
            break;

        case RsaKeyHandle::SignatureMode::RS384:
            // Initialize digest
            hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA384 );
            break;

        case RsaKeyHandle::SignatureMode::RS512:
            // Initialize digest
            hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA512 );
            break;

        default:
            throw invalid_argument("algorithm");
    }
    
    // Hash the message
    auto digest = hash->updateFinal(m);
    
    // Construct T, the DER encoded DigestInfo structure
    return EMSA_PKCS1_V1_5_ENCODE_HASH( digest, emLen, signatureMode );
}

}

class RSAES_OAEP_SHA256 : public RSAES<OAEP<CryptoPP::SHA256>> {};

struct RsaKeyHandle::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()
    {
    }

    shared_ptr<CryptoPP::RSA::PublicKey>  _public;
    shared_ptr<CryptoPP::RSA::PrivateKey> _private;
};

RsaKeyHandle::RsaKeyHandle()
{
    unique_ptr<State> state( new State() );

    AutoSeededRandomPool rng;

    state->_private = make_shared<InvertibleRSAFunction>();
    state->_private->Initialize( rng, 2048, 65537 );
    state->_public  = state->_private;

    _state = state.release();
}

RsaKeyHandle::RsaKeyHandle( const RsaParameters& parameters )
{
    unique_ptr<State> state( new State() );

    // Create the public key
    state->_public = make_shared<RSAFunction>();

    // Create Integers from the byte arrays
    Integer n( parameters.n().data(), parameters.n().size() );
    Integer e( parameters.e().data(), parameters.e().size() );

    state->_public->Initialize( n, e );

    if ( parameters.hasPrivateParameters() )
    {
        // Create the private key
        state->_private = make_shared<InvertibleRSAFunction>();

        // Create Integers from the byte arrays
        Integer d( parameters.d().data(), parameters.d().size() );
        Integer p( parameters.p().data(), parameters.p().size() );
        Integer q( parameters.q().data(), parameters.q().size() );
        Integer dp( parameters.dp().data(), parameters.dp().size() );
        Integer dq( parameters.dq().data(), parameters.dq().size() );
        Integer qi( parameters.qi().data(), parameters.qi().size() );
        
        state->_private->Initialize(n,e,d,p,q,dp,dq,qi);

    }

    _state = state.release();
}

RsaKeyHandle::~RsaKeyHandle()
{
    if ( NULL != _state ) delete _state;
}

RsaParameters RsaKeyHandle::exportParameters( bool includePrivate )
{
    if ( includePrivate && NULL == _state->_private )
    {
        throw runtime_error( "RsaKeyHandle::exportParameters cannot export private key parameters" );
    }

    RsaParameters parameters;
    RSAFunction  *rsa         = _state->_public.get();

    auto i = rsa->GetModulus();
    vector<byte> encoded( i.MinEncodedSize() );
    i.Encode( encoded.data(), encoded.size() );
    parameters.n( encoded );

    i = rsa->GetPublicExponent();
    encoded.resize( i.MinEncodedSize() );
    i.Encode( encoded.data(), encoded.size() );
    parameters.e( encoded );

    if ( includePrivate )
    {
        InvertibleRSAFunction *rsaPrivate = _state->_private.get();

        i = rsaPrivate->GetPrivateExponent();
        encoded.resize( i.MinEncodedSize() );
        i.Encode( encoded.data(), encoded.size() );
        parameters.d( encoded );

        i = rsaPrivate->GetPrime1();
        encoded.resize( i.MinEncodedSize() );
        i.Encode( encoded.data(), encoded.size() );
        parameters.p( encoded );

        i = rsaPrivate->GetPrime2();
        encoded.resize( i.MinEncodedSize() );
        i.Encode( encoded.data(), encoded.size() );
        parameters.q( encoded );

        i = rsaPrivate->GetModPrime1PrivateExponent();
        encoded.resize( i.MinEncodedSize() );
        i.Encode( encoded.data(), encoded.size() );
        parameters.dp( encoded );

        i = rsaPrivate->GetModPrime2PrivateExponent();
        encoded.resize( i.MinEncodedSize() );
        i.Encode( encoded.data(), encoded.size() );
        parameters.dq( encoded );

        i = rsaPrivate->GetMultiplicativeInverseOfPrime2ModPrime1();
        encoded.resize( i.MinEncodedSize() );
        i.Encode( encoded.data(), encoded.size() );
        parameters.qi( encoded );
    }

    return parameters;
}

vector<byte> RsaKeyHandle::decrypt( const std::vector<akv::byte_t>& ciphertext, PaddingMode paddingMode )
{
    if ( _state->_private != nullptr )
    {
        // Encryption
        AutoSeededRandomPool rng;

        shared_ptr<PK_DecryptorFilter> filter;
        shared_ptr<PK_Decryptor>       decryptor;

        switch ( paddingMode )
        {
            case PaddingMode::PKCS1_5:
                decryptor = make_shared<RSAES_PKCS1v15_Decryptor>( *_state->_private );
                filter    = make_shared<PK_DecryptorFilter>( rng, *decryptor );
                break;

            case PaddingMode::OAEP:
                decryptor = make_shared<RSAES_OAEP_SHA_Decryptor>( *_state->_private );
                filter    = make_shared<PK_DecryptorFilter>( rng, *decryptor );
                break;

            case PaddingMode::OAEP256:
                decryptor = make_shared<RSAES_OAEP_SHA256::Decryptor>( *_state->_private );
                filter    = make_shared<PK_DecryptorFilter>( rng, *decryptor );
                break;

            default:
                break;
        }

        filter->Put( ciphertext.data(), ciphertext.size() );
        filter->MessageEnd();

        vector<akv::byte_t> result( filter->MaxRetrievable() );

        filter->Get( result.data(), result.size() );

        return result;
    }
    else
    {
        throw runtime_error( "RsaKeyHandle::decrypt" );
    }
}

std::vector<akv::byte_t> RsaKeyHandle::encrypt( const std::vector<akv::byte_t>& plaintext, PaddingMode paddingMode )
{
    // Encryption
    AutoSeededRandomPool rng;
    RSAFunction         *rsa = _state->_private != nullptr ? _state->_private.get() : _state->_public.get();

    shared_ptr<PK_EncryptorFilter> filter;
    shared_ptr<PK_Encryptor>       encryptor;

    switch ( paddingMode )
    {
        case PaddingMode::PKCS1_5:
            encryptor = make_shared<RSAES_PKCS1v15_Encryptor>( *rsa );
            filter    = make_shared<PK_EncryptorFilter>( rng, *encryptor );
            break;

        case PaddingMode::OAEP:
            encryptor = make_shared<RSAES_OAEP_SHA_Encryptor>( *rsa );
            filter    = make_shared<PK_EncryptorFilter>( rng, *encryptor );
            break;

        case PaddingMode::OAEP256:
            encryptor = make_shared<RSAES_OAEP_SHA256::Encryptor>( *rsa );
            filter    = make_shared<PK_EncryptorFilter>( rng, *encryptor );
            break;

        default:
            break;
    }

    filter->Put( plaintext.data(), plaintext.size() );
    filter->MessageEnd();

    vector<akv::byte_t> result( filter->MaxRetrievable() );

    filter->Get( result.data(), result.size() );

    return result;
}

std::vector<akv::byte_t> RsaKeyHandle::sign( const std::vector<akv::byte_t>& digest, SignatureMode signatureMode )
{
    if ( _state->_private == nullptr ) {
        throw runtime_error( "RsaKeyHandle::sign - no private key" );
    }

    if ( signatureMode != SignatureMode::RS256 && signatureMode != SignatureMode::RS384 && signatureMode != SignatureMode::RS512 ) throw invalid_argument( "signatureMode" );

    // Signing isn't just a case of encrypting the digest, there is much more to do.
    // For details of the algorithm, see https://tools.ietf.org/html/rfc3447#section-8.2
    
    // Construct the encoded message
    auto EMLength = rsa::getOctetLength( _state->_private->GetModulus() );
    auto EM       = rsa::EMSA_PKCS1_V1_5_ENCODE_HASH( digest, EMLength, signatureMode );
    
    // Convert to integer message
    Integer s = rsa::OS2IP(EM);
    
    // RSASP1(s)
    s = rsa::RSASP1( *(_state->_private), s);
    
    // Convert to octet sequence
    return rsa::I2OSP(s, EMLength );
}

bool RsaKeyHandle::verify( const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& signature, SignatureMode signatureMode )
{
    auto EMLength = rsa::getOctetLength( _state->_public->GetModulus() );

    if ( signature.size() != EMLength ) throw invalid_argument( "invalid signature length");
    if ( signatureMode != SignatureMode::RS256 && signatureMode != SignatureMode::RS384 && signatureMode != SignatureMode::RS512 ) throw invalid_argument( "signatureMode" );
    
    // Convert to integer signature
    Integer s = rsa::OS2IP(signature);
    
    // Convert integer message
    Integer m = rsa::RSAVP1( *(_state->_public), s);
    
    auto EM       = rsa::I2OSP(m, EMLength );
    auto EM2      = rsa::EMSA_PKCS1_V1_5_ENCODE_HASH( digest, EMLength, signatureMode );
    
    // Use constant time compare
    return sequence_equal(EM, EM2);
}

} }
