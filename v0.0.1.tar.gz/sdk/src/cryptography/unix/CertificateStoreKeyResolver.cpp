/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include <openssl/pkcs12.h>

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/Key.h"
#include "akv/cryptography/CertificateKey.h"
#include "akv/cryptography/CertificateStoreKeyResolver.h"

using namespace akv;
using namespace std;
using namespace pplx;

namespace akv { namespace cryptography {

struct CertificateStoreKeyResolver::State
{
    State() { }
    State( const State& )              = delete;
    State& operator = ( const State& ) = delete;
    ~State()
    {
    }

    akv::string_t _location;
    akv::string_t _name;
};

static const akv::string_t _LocalMachine( __T("LocalMachine") );
static const akv::string_t _CurrentUser( __T("CurrentUser") );

const akv::string_t& CertificateStoreKeyResolver::LocalMachine()
{
    return _LocalMachine;
}

const akv::string_t& CertificateStoreKeyResolver::CurrentUser()
{
    return _CurrentUser;
}

CertificateStoreKeyResolver::CertificateStoreKeyResolver( const akv::string_t& storeLocation, const akv::string_t& storeName )
{
    unique_ptr<State> state( new State() );

    state->_location = storeLocation;
    state->_name     = storeName;

    _state = state.release();
}


CertificateStoreKeyResolver::~CertificateStoreKeyResolver()
{
    if ( NULL != _state ) delete _state;
}

pplx::task<std::shared_ptr<IKey>> CertificateStoreKeyResolver::resolve_key( const akv::string_t& kid, const pplx::cancellation_token& token ) const
{
    auto self = this;

    return pplx::create_task( [self, kid]() -> std::shared_ptr<IKey>
    {
        {
            return shared_ptr<IKey>();
        }
    }, token );
}

} }
