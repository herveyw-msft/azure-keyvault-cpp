/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include <cstdlib>

#include <cryptopp/cryptlib.h>
#include <cryptopp/filters.h>
#include <cryptopp/aes.h>
#include <cryptopp/ccm.h>

#include "akv/cryptography/IEncryptionTransform.h"
#include "cryptography/AesEcbEncryptionTransform.h"

using namespace std;
using namespace CryptoPP;

namespace akv { namespace cryptography {

struct AesEcbEncryptionTransform::State
{
    State() { };
    ~State() { };
    
    ECB_Mode<AES>::Encryption _encryptor;
    ECB_Mode<AES>::Decryption _decryptor;
};

//
// ctor
//
AesEcbEncryptionTransform::AesEcbEncryptionTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv )
{
    switch ( key.size() )
    {
        case 128 >> 3:
        case 192 >> 3:
        case 256 >> 3:
            break;

        default:
            throw invalid_argument( "key" );
    }

    if ( iv.empty() == false ) throw invalid_argument( "iv" );

    unique_ptr<State> state( new State() );

    // TODO: Check status!
    state->_encryptor.SetKey( key.data(), key.size() );

    // TODO: Check status!
    state->_decryptor.SetKey( key.data(), key.size() );

    _state = state.release();
}

//
// Move
//
AesEcbEncryptionTransform::AesEcbEncryptionTransform( AesEcbEncryptionTransform&& other )
{
    _state = other._state;
    other._state = NULL;
}

//
// Move Assign
//
AesEcbEncryptionTransform& AesEcbEncryptionTransform::operator = ( AesEcbEncryptionTransform&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

AesEcbEncryptionTransform::~AesEcbEncryptionTransform()
{
    if ( NULL != _state ) delete _state;
}

IEncryptionTransform::EncryptResult AesEcbEncryptionTransform::encrypt( const std::vector<akv::byte_t>& plaintext )
{
    if ( plaintext.empty() ) throw invalid_argument( "plaintext" );

    StreamTransformationFilter filter( _state->_encryptor, NULL, BlockPaddingSchemeDef::NO_PADDING );

    filter.Put( plaintext.data(), plaintext.size() );
    filter.MessageEnd();

    vector<akv::byte_t> result( filter.MaxRetrievable() );

    filter.Get( result.data(), result.size() );

    return IEncryptionTransform::EncryptResult( result );
}

IEncryptionTransform::DecryptResult AesEcbEncryptionTransform::decrypt( const std::vector<akv::byte_t>& ciphertext, const vector<akv::byte_t>& tag )
{
    if ( ciphertext.empty() ) throw invalid_argument( "ciphertext" );
    if ( !tag.empty() ) throw invalid_argument( "tag" );

    StreamTransformationFilter filter( _state->_decryptor, NULL, BlockPaddingSchemeDef::NO_PADDING );

    filter.Put( ciphertext.data(), ciphertext.size() );
    filter.MessageEnd();

    vector<akv::byte_t> result( filter.MaxRetrievable() );

    filter.Get( result.data(), result.size() );

    return IEncryptionTransform::DecryptResult( result );
}

} }

