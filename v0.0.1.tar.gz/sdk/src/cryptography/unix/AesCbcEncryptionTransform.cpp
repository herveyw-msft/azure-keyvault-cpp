/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include <cstdlib>

#include <cryptopp/cryptlib.h>
#include <cryptopp/filters.h>
#include <cryptopp/aes.h>
#include <cryptopp/ccm.h>

#include "akv/cryptography/IEncryptionTransform.h"
#include "cryptography/AesCbcEncryptionTransform.h"

using namespace std;
using namespace CryptoPP;

namespace akv { namespace cryptography {

struct AesCbcEncryptionTransform::State
{
    State() { };
    ~State() { };

    CBC_Mode<AES>::Decryption _decryptor;
    CBC_Mode<AES>::Encryption _encryptor;
};

AesCbcEncryptionTransform::AesCbcEncryptionTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv )
{
    switch ( key.size() )
    {
        case 128 >> 3:
        case 192 >> 3:
        case 256 >> 3:
            break;

        default:
            throw invalid_argument( "key" );
    }

    // AES has 128bit block size, the IV must match that
    if ( iv.size() != 128 >> 3 ) throw invalid_argument( "iv" );

    unique_ptr<State> state( new State() );

    // TODO: Check status!
    state->_encryptor.SetKeyWithIV( key.data(), key.size(), iv.data() );

    // TODO: Check status!
    state->_decryptor.SetKeyWithIV( key.data(), key.size(), iv.data() );

    _state = state.release();
}

//
// Move
//
AesCbcEncryptionTransform::AesCbcEncryptionTransform( AesCbcEncryptionTransform&& other )
{
    _state = other._state;
    other._state = NULL;
}

//
// Move Assign
//
AesCbcEncryptionTransform& AesCbcEncryptionTransform::operator = ( AesCbcEncryptionTransform&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

AesCbcEncryptionTransform::~AesCbcEncryptionTransform()
{
    if ( NULL != _state ) delete _state;
}

AesCbcEncryptionTransform::EncryptResult AesCbcEncryptionTransform::encrypt( const std::vector<akv::byte_t>& plaintext )
{
    if ( plaintext.empty() ) throw invalid_argument( "plaintext" );

    StreamTransformationFilter filter( _state->_encryptor );

    filter.Put( plaintext.data(), plaintext.size() );
    filter.MessageEnd();

    vector<akv::byte_t> result( filter.MaxRetrievable() );

    filter.Get( result.data(), result.size() );

    return AesCbcEncryptionTransform::EncryptResult( result );
}

AesCbcEncryptionTransform::DecryptResult AesCbcEncryptionTransform::decrypt( const std::vector<akv::byte_t>& ciphertext, const vector<akv::byte_t>& tag )
{
    if ( ciphertext.empty() ) throw invalid_argument( "ciphertext" );
    if ( !tag.empty() ) throw invalid_argument( "tag" );

    StreamTransformationFilter filter( _state->_decryptor );

    filter.Put( ciphertext.data(), ciphertext.size() );
    filter.MessageEnd();

    vector<akv::byte_t> result( filter.MaxRetrievable() );

    filter.Get( result.data(), result.size() );

    return AesCbcEncryptionTransform::DecryptResult( result );
}


} }

