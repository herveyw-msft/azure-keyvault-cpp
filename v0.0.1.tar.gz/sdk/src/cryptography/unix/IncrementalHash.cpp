/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include <cryptopp/cryptlib.h>
#include <cryptopp/filters.h>
#include <cryptopp/sha.h>

#include "akv/common/string_t.h"

#include "akv/cryptography/IncrementalHash.h"

using namespace std;
using namespace CryptoPP;

namespace akv { namespace cryptography {

struct IncrementalHash::State
{
    Type                           _type;
    unique_ptr<HashFilter>         _filter;
    unique_ptr<HashTransformation> _hash;
};

IncrementalHash::IncrementalHash( Type hashName )
{
    unique_ptr<State> state( new State() );

    if ( hashName == Type::SHA256 )
    {
        state->_hash.reset( new CryptoPP::SHA256() );
    }
    else if ( hashName == Type::SHA384 )
    {
        state->_hash.reset( new CryptoPP::SHA384() );
    }
    else if ( hashName == Type::SHA512 )
    {
        state->_hash.reset( new CryptoPP::SHA512() );
    }
    else
    {
        throw invalid_argument( "hashName" );
    }

    state->_type = hashName;

    state->_filter.reset( new HashFilter( *(state->_hash.get()) ) );

    _state = state.release();
}

IncrementalHash::~IncrementalHash()
{
    if ( _state != NULL ) delete _state;
}

size_t IncrementalHash::size() const
{
    switch ( _state->_type )
    {
        case Type::SHA256:
            return 32;

        case Type::SHA384:
            return 48;
            
        case Type::SHA512:
            return 64;
            
        default:
            throw runtime_error( "unknown hash type" );
    }
}

void IncrementalHash::update( const std::vector<akv::byte_t>& data )
{
    if ( data.size() == 0 ) throw invalid_argument( "data" );

    _state->_filter->Put( data.data(), data.size() );
}

vector<akv::byte_t> IncrementalHash::updateFinal( const std::vector<akv::byte_t>& data )
{
    if ( data.size() == 0 ) throw invalid_argument( "data" );

    _state->_filter->Put( data.data(), data.size() );
    _state->_filter->MessageEnd();

    vector<akv::byte_t> result( _state->_filter->MaxRetrievable() );

    _state->_filter->Get( result.data(), result.size() );

    return result;
}

} }
