/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/
#define __STDC_WANT_LIB_EXT1__ 1

#include "precomp.h"

#include <string.h>

#if !defined(__STDC_LIB_EXT1__)
#define memcpy_s( a, b, c, d ) memcpy(a, b, d )
#endif

#include "common/vector.h"

#include "akv/cryptography/IEncryptionTransform.h"
#include "cryptography/AesEcbEncryptionTransform.h"

#include "akv/cryptography/IKeyWrapTransform.h"
#include "cryptography/AesKeyWrapTransform.h"

using namespace std;

namespace akv { namespace cryptography {

static std::vector<akv::byte_t> ConvertToBigEndian( int64_t i )
{
    int64_t  target  = i;
    uint8_t *pTarget = reinterpret_cast<uint8_t *>( &target );

    vector<uint8_t> result( pTarget, pTarget + sizeof(int64_t) / sizeof(uint8_t) );

#if TARGET_OS_WIN32 || TARGET_OS_MAC || TARGET_OS_UNIX
    // Windows is little endian
    std::reverse( result.begin(), result.end() );
#else
    // Everyone else is big endian??
#endif

    return result;
}

struct AesKeyWrapTransform::State
{
    State() { };
    virtual ~State() { SecureZeroMemory( _iv ); }
    
    vector<akv::byte_t>                     _iv;
    unique_ptr<AesEcbEncryptionTransform> _transform;
};

AesKeyWrapTransform::AesKeyWrapTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv )
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( iv.empty() || iv.size() != 8 ) throw invalid_argument( "iv" );

    unique_ptr<State> state( new State() );

    state->_iv        = iv;
    state->_transform = unique_ptr<AesEcbEncryptionTransform>( new AesEcbEncryptionTransform( key, vector<akv::byte_t>() ) );

    _state = state.release();
}

AesKeyWrapTransform::~AesKeyWrapTransform()
{
    if ( NULL != _state ) delete _state;
}

AesKeyWrapTransform::WrapResult AesKeyWrapTransform::wrap( const std::vector<akv::byte_t>& key )
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( key.size() % 8 != 0 ) throw invalid_argument( "key" );

    /*

    See https://tools.ietf.org/html/rfc3394#section-2.2.1

    1) Initialize variables.

        Set A = IV, an initial value (see 2.2.3)
        For i = 1 to n
            R[i] = P[i]

    2) Calculate intermediate values.

        For j = 0 to 5
            For i=1 to n
                B = AES(K, A | R[i])
                A = MSB(64, B) ^ t where t = (n*j)+i
                R[i] = LSB(64, B)

    3) Output the results.

        Set C[0] = A
        For i = 1 to n
            C[i] = R[i]
    */

#define BLOCK_START( b, i ) b.begin() + ( ( i ) << 3 )
#define BLOCK_END( b, i )   BLOCK_START( b, i ) + 8

    // The default initialization vector from RFC3394
    vector<akv::byte_t>  A( _state->_iv );

    // The number of input 64bit blocks
    uint64_t           n  = key.size() >> 3;

    // The set of 64bit input blocks
    vector<akv::byte_t>  R( key );

    vector<akv::byte_t>  block( 8 * 2 ); // Two 64bit blocks

    // Calculate intermediate values
    for ( uint64_t j = 0; j < 6; j++ )
    {
        // n 64bit input blocks, i is the block index
        for ( uint64_t i = 0; i < n; i++ )
        {
            // T = ( n * j ) + i
            uint64_t t = (uint64_t)( ( n * j ) + i + 1 );

            // B = AES( K, A | R[i] )

            // First, block = A | R[i] (concatenate)
            std::copy( A.begin(), A.end(), block.begin() );
            std::copy( BLOCK_START( R, i ), BLOCK_END( R, i ), block.begin() + 8 );

            // Second, AES( K, block )
            auto B = _state->_transform->encrypt( block );

            // A = MSB( 64, B )
            std::copy( B.ciphertext.begin(), B.ciphertext.begin() + 8, A.begin() );
            
            // A = A ^ t
            auto bytes = ConvertToBigEndian( t );

            std::transform( A.begin(), A.end(), bytes.begin(), A.begin(), []( akv::byte_t x, akv::byte_t y ) { return x ^ y; } );
            //a.Xor( ConvertToBigEndian( t ), true );
            
            // R[i] = LSB( 64, B )
            std::copy( B.ciphertext.end() - 8, B.ciphertext.end(), BLOCK_START( R, i ) );
        }
    }

    vector<akv::byte_t> C( ( n + 1 ) << 3 );

    std::copy( A.begin(), A.end(), C.begin() );

    for ( uint64_t i = 0; i < n; i++ )
    {
        std::copy( BLOCK_START( R, i ), BLOCK_END( R, i ), BLOCK_START( C, i + 1 ) );
    }

    return C;
}

AesKeyWrapTransform::UnwrapResult AesKeyWrapTransform::unwrap( const std::vector<akv::byte_t>& encryptedKey )
{
    if ( encryptedKey.empty() ) throw invalid_argument( "encryptedKey" );
    if ( encryptedKey.size() % 8 != 0 ) throw invalid_argument( "encryptedKey" );

    /*

    See https://tools.ietf.org/html/rfc3394#section-2.2.2

    1) Initialize variables.

        Set A = C[0]
        For i = 1 to n
            R[i] = C[i]

    2) Compute intermediate values.

        For j = 5 to 0
            For i = n to 1
                B = AES-1(K, (A ^ t) | R[i]) where t = n*j+i
                A = MSB(64, B)
                R[i] = LSB(64, B)

    3) Output results.

    If A is an appropriate initial value (see 2.2.3),
    Then
        For i = 1 to n
            P[i] = R[i]
    Else
        Return an error
    */

    // A = C[0]
    vector<akv::byte_t> A( BLOCK_START( encryptedKey, 0 ), BLOCK_END( encryptedKey, 0 ) );

    // The number of 64bit input blocks
    uint64_t          n  = ( encryptedKey.size() - 8 ) >> 3;

    // The set of input blocks
    vector<akv::byte_t> R( BLOCK_START( encryptedKey, 1 ), encryptedKey.end() );

    vector<akv::byte_t> block( 16 );
    vector<akv::byte_t> tag;

    // Calculate intermediate values
    for ( int64_t j = 5; j >= 0; j-- )
    {
        // NOTE: i is 1 based, not zero based in this loop!
        for ( int64_t i = n; i > 0; i-- )
        {
            // T = ( n * j ) + i
            uint64_t t = (uint64_t)( ( n * j ) + i );

            // B = AES-1(K, (A ^ t) | R[i] )

            // First, A = ( A ^ t )
            auto bytes = ConvertToBigEndian( t );

            std::transform( A.begin(), A.end(), bytes.begin(), A.begin(), []( akv::byte_t x, akv::byte_t y ) { return x ^ y; } );

            // Second, block = ( A | R[i] )
            std::copy( A.begin(), A.end(), block.begin() );
            std::copy( BLOCK_START( R, i - 1 ), BLOCK_END( R, i - 1 ), block.begin() + A.size() );

            // Third, b = AES-1( block )
            auto B = _state->_transform->decrypt( block, tag );

            // A = MSB(64, B)
            std::copy( B.plaintext.begin(), B.plaintext.begin() + 8, A.begin() );

            // R[i] = LSB(64, B)
            std::copy( B.plaintext.end() - 8, B.plaintext.end(), BLOCK_START( R, i - 1 ) );
        }
    }

    if ( sequence_equal( A, _state->_iv ) )
    {
        vector<akv::byte_t> C( n << 3 );

        for ( uint64_t i = 0; i < n; i++ )
        {
            std::copy( BLOCK_START( R, i ), BLOCK_END( R, i ), BLOCK_START( C, i ) );
        }

        return C;
    }
    else
    {
        throw runtime_error( "Data is not authentic" );
    }
}


} }

