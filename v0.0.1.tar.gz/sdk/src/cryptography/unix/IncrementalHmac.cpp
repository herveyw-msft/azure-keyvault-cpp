/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include <cryptopp/cryptlib.h>
#include <cryptopp/filters.h>
#include <cryptopp/sha.h>
#include <cryptopp/hmac.h>

#include "akv/common/string_t.h"
#include "cryptography/IncrementalHmac.h"

using namespace std;
using namespace CryptoPP;

namespace akv { namespace cryptography {

const akv::string_t __SHA256( __T("SHA256") );
const akv::string_t __SHA384( __T("SHA384") );
const akv::string_t __SHA512( __T("SHA512") );

struct IncrementalHmac::State
{
    unique_ptr<HashTransformation> _hash;
    unique_ptr<HashFilter>         _filter;
};

IncrementalHmac::IncrementalHmac( const akv::string_t& hashName, const std::vector<akv::byte_t>& secret )
{
    if ( hashName.size() == 0 ) throw invalid_argument( "hashName" );
    if ( secret.size() == 0 ) throw invalid_argument( "secret" );

    unique_ptr<State> state( new State() );

    if ( __SHA256.compare( hashName ) == 0 )
    {
        state->_hash.reset( new CryptoPP::HMAC<CryptoPP::SHA256>( secret.data(), secret.size() ) );
    }
    else if ( __SHA384.compare( hashName ) == 0 )
    {
        state->_hash.reset( new CryptoPP::HMAC<CryptoPP::SHA384>( secret.data(), secret.size() ) );
    }
    else if ( __SHA512.compare( hashName ) == 0 )
    {
        state->_hash.reset( new CryptoPP::HMAC<CryptoPP::SHA512>( secret.data(), secret.size() ) );
    }
    else
    {
        throw runtime_error( "IncrementalHmac::IncrementalHmac" );
    }

    state->_filter.reset( new HashFilter( *state->_hash ) );

    _state = state.release();
}

IncrementalHmac::~IncrementalHmac()
{
    dispose();
}

void IncrementalHmac::update( const std::vector<akv::byte_t>& data )
{
    if ( data.size() == 0 ) throw invalid_argument( "data" );

    // Run the data through the filter
    _state->_filter->Put( data.data(), data.size() );
}

vector<akv::byte_t> IncrementalHmac::updateFinal( const std::vector<akv::byte_t>& data )
{
    if ( data.size() == 0 ) throw invalid_argument( "data" );

    // Run the data through the filter
    _state->_filter->Put( data.data(), data.size() );

    // Set end of message
    _state->_filter->MessageEnd();

    vector<akv::byte_t> hmac( _state->_filter->MaxRetrievable() );

    _state->_filter->Get( hmac.data(), hmac.size() );

    return hmac;
}

void IncrementalHmac::dispose()
{
    if ( _state )
    {
        delete _state;
        _state = NULL;
    }
}

} }
