/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/RandomNumberGenerator.h"

using namespace std;

namespace akv { namespace cryptography {

void RandomNumberGenerator::get_bytes( vector<akv::byte_t>& target )
{
    // TODO: Consider throwing an exception
    if ( target.size() == 0 )
        return;

    // TODO: Uses non-blocked /dev/urandom, is this good enough?
    FILE *fp = fopen("/dev/urandom", "r");
    
    if (!fp) {
        perror("randgetter");
        exit(-1);
    }
    
    auto value = target.data();

    size_t i;

    for ( i = 0; i < target.size(); i++ )
    {
        *value = (unsigned char)fgetc(fp);
        value++;
    }
    
    fclose(fp);
}

} }
