/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/AsymmetricEncryptionAlgorithm.h"

namespace akv { namespace cryptography {

AsymmetricEncryptionAlgorithm::AsymmetricEncryptionAlgorithm( const akv::string_t& name ) : EncryptionAlgorithm( name )
{
}

AsymmetricEncryptionAlgorithm::~AsymmetricEncryptionAlgorithm()
{
}

} }
