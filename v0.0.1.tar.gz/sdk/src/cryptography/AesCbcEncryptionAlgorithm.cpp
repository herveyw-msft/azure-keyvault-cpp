/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/IEncryptionTransform.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/SymmetricEncryptionAlgorithm.h"

#include "akv/cryptography/AesCbcEncryptionAlgorithm.h"
#include "cryptography/AesCbcEncryptionTransform.h"

using namespace std;

namespace akv { namespace cryptography {

Aes::Aes( const akv::string_t& name ) : SymmetricEncryptionAlgorithm( name )
{
}

Aes::~Aes()
{
}

shared_ptr<IEncryptionTransform> Aes::createTransformCore( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv ) const
{
    return shared_ptr<IEncryptionTransform>( new AesCbcEncryptionTransform( key, iv ) );
}

// AES128

Aes128::Aes128() : Aes( AlgorithmNames::Aes128Cbc() )
{
}

const akv::string_t& Aes128::AlgorithmName()
{
    return AlgorithmNames::Aes128Cbc();
}

shared_ptr<IEncryptionTransform> Aes128::createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( iv.empty() ) throw invalid_argument( "iv" );
    if ( !aad.empty() ) throw invalid_argument( "aad" );
    
    return createTransformCore( take( key, 128 >> 3), iv );
}

// AES192

Aes192::Aes192() : Aes( AlgorithmNames::Aes128Cbc() )
{
}

const akv::string_t& Aes192::AlgorithmName()
{
    return AlgorithmNames::Aes192Cbc();
}

shared_ptr<IEncryptionTransform> Aes192::createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( iv.empty() ) throw invalid_argument( "iv" );
    if ( !aad.empty() ) throw invalid_argument( "aad" );
    
    return createTransformCore( take( key, 192 >> 3), iv );
}

// AES256

Aes256::Aes256() : Aes( AlgorithmNames::Aes128Cbc())
{
}

const akv::string_t& Aes256::AlgorithmName()
{
    return AlgorithmNames::Aes256Cbc();
}

shared_ptr<IEncryptionTransform> Aes256::createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( iv.empty() ) throw invalid_argument( "iv" );
    if ( !aad.empty() ) throw invalid_argument( "aad" );
    
    return createTransformCore( take( key, 256 >> 3), iv );
}

} }
