/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#if TARGET_OS_WIN32

#include "akv/akv_core.h"

#include "akv/cryptography/CombinedKeyResolver.h"

using namespace akv;
using namespace std;
using namespace pplx;

namespace akv {
namespace cryptography {

struct CombinedKeyResolver::State
{
    std::unique_ptr<IKeyResolver> first;
    std::unique_ptr<IKeyResolver> fallback;

    State(std::unique_ptr<IKeyResolver> first, std::unique_ptr<IKeyResolver> fallback)
        : first{ std::move(first) }
        , fallback{ std::move(fallback) }
    {}
};

CombinedKeyResolver::CombinedKeyResolver(std::unique_ptr<IKeyResolver> first, std::unique_ptr<IKeyResolver> fallback)
    : _state{ new State(std::move(first), std::move(fallback)) }
{
}

CombinedKeyResolver::~CombinedKeyResolver()
{
    delete _state;
}

pplx::task<std::shared_ptr<IKey>> CombinedKeyResolver::resolve_key( const akv::string_t& kid, const pplx::cancellation_token& token ) const
{
    return _state->first->resolve_key( kid, token ).then( [this, kid, token]( const std::shared_ptr<IKey>& key )
    {
        /*
        TODO: consider using shared_from_this so that we can capture
        a weak pointer to `this` in the callback. (This will also require that
        CombinedKeyResolver is only creatable as shared_ptr via factory method,
        not the normal constructor.)
        */

        if ( key )
        {
            return pplx::task_from_result( key );
        }

        return _state->fallback->resolve_key( kid, token );
    }, token );
}


} }

#endif
