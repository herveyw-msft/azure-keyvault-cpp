/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/IncrementalHash.h"

#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/ISignatureTransform.h"

#include "cryptography/RsaKeyHandle.h"
#include "cryptography/RsaSignatureTransform.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct RsaSignatureTransform::State
{
    RsaKeyHandle::SignatureMode _mode;
    shared_ptr<RsaKeyHandle>    _handle;
    shared_ptr<IncrementalHash> _hash;
};

//
// RSA
//
RsaSignatureTransform::RsaSignatureTransform( const RsaParameters& parameters, RsaKeyHandle::SignatureMode signatureMode )
{
    unique_ptr<State> state( new State() );

    state->_handle = make_shared<RsaKeyHandle>( parameters );
    state->_mode   = signatureMode;

    switch ( signatureMode )
    {
        case RsaKeyHandle::SignatureMode::RS256:
            state->_hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA256 );
            break;

        case RsaKeyHandle::SignatureMode::RS384:
            state->_hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA384 );
            break;

        case RsaKeyHandle::SignatureMode::RS512:
            state->_hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA512 );
            break;

        default:
            throw invalid_argument( "signatureMode" );
    }

    _state = state.release();
}

RsaSignatureTransform::RsaSignatureTransform( const shared_ptr<RsaKeyHandle>& keyHandle, RsaKeyHandle::SignatureMode signatureMode )
{
    if ( keyHandle == nullptr )
        throw invalid_argument( "keyHandle" );

    unique_ptr<State> state( new State() );

    state->_handle = keyHandle;
    state->_mode   = signatureMode;

    switch ( signatureMode )
    {
        case RsaKeyHandle::SignatureMode::RS256:
            state->_hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA256 );
            break;

        case RsaKeyHandle::SignatureMode::RS384:
            state->_hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA384 );
            break;

        case RsaKeyHandle::SignatureMode::RS512:
            state->_hash = make_shared<IncrementalHash>( IncrementalHash::Type::SHA512 );
            break;

        default:
            throw invalid_argument( "signatureMode" );
    }

    _state = state.release();
}

RsaSignatureTransform::~RsaSignatureTransform()
{
    if ( NULL != _state ) delete _state;
}

ISignatureTransform::SignResult RsaSignatureTransform::signHash( const std::vector<akv::byte_t>& digest )
{
    if ( digest.empty() || digest.size() != _state->_hash->size() ) throw invalid_argument( "digest" );

    return _state->_handle->sign( digest, _state->_mode );
}

ISignatureTransform::VerifyResult RsaSignatureTransform::verifyHash( const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& signature )
{
    if ( digest.empty() || digest.size() != _state->_hash->size() ) throw invalid_argument( "digest" );
    if ( signature.empty() ) throw invalid_argument( "signature" );
    
    return _state->_handle->verify( digest, signature, _state->_mode );
}

ISignatureTransform::SignResult RsaSignatureTransform::signMessage( const std::vector<akv::byte_t>& message )
{
    if ( message.empty() )
        throw invalid_argument( "message" );

    auto digest = _state->_hash->updateFinal( message );

    return signHash( digest );
}

ISignatureTransform::VerifyResult RsaSignatureTransform::verifyMessage( const std::vector<akv::byte_t>& message, const std::vector<akv::byte_t>& signature )
{
    if ( message.empty() )
        throw invalid_argument( "message" );

    if ( signature.empty() )
        throw invalid_argument( "signature" );

    auto digest = _state->_hash->updateFinal( message );

    return verifyHash( digest, signature );
}

//
// RSA SHA 256
//
Rs256SignatureTransform::Rs256SignatureTransform( const RsaParameters& parameters ) : RsaSignatureTransform( parameters, RsaKeyHandle::SignatureMode::RS256 )
{
}

Rs256SignatureTransform::Rs256SignatureTransform( const shared_ptr<RsaKeyHandle>& keyHandle ) : RsaSignatureTransform( keyHandle, RsaKeyHandle::SignatureMode::RS256 )
{
}

Rs256SignatureTransform::~Rs256SignatureTransform()
{
}


//
// RSA SHA 384
//
Rs384SignatureTransform::Rs384SignatureTransform( const RsaParameters& parameters ) : RsaSignatureTransform( parameters, RsaKeyHandle::SignatureMode::RS384 )
{
}

Rs384SignatureTransform::Rs384SignatureTransform( const shared_ptr<RsaKeyHandle>& keyHandle ) : RsaSignatureTransform( keyHandle, RsaKeyHandle::SignatureMode::RS384 )
{
}

Rs384SignatureTransform::~Rs384SignatureTransform()
{
}

//
// RSA SHA 512
//
Rs512SignatureTransform::Rs512SignatureTransform( const RsaParameters& parameters ) : RsaSignatureTransform( parameters, RsaKeyHandle::SignatureMode::RS512 )
{
}

Rs512SignatureTransform::Rs512SignatureTransform( const shared_ptr<RsaKeyHandle>& keyHandle ) : RsaSignatureTransform( keyHandle, RsaKeyHandle::SignatureMode::RS512 )
{
}

Rs512SignatureTransform::~Rs512SignatureTransform()
{
}

} }
