/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/Algorithm.h"

namespace akv { namespace cryptography {

struct Algorithm::_Impl
{
    akv::string_t _name;
};

Algorithm::Algorithm( const akv::string_t& name )
{
    _impl = new _Impl();

    _impl->_name = name;
}

Algorithm::~Algorithm()
{
    delete _impl;
}

const akv::string_t& Algorithm::name() const
{
    return _impl->_name;
}

} }
