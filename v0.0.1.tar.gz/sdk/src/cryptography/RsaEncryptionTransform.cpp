/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/IEncryptionTransform.h"

#include "cryptography/RsaKeyHandle.h"
#include "cryptography/RsaEncryptionTransform.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct RsaEncryptionTransform::State
{
    State() {};
    ~State() { };

    shared_ptr<RsaKeyHandle> _handle;
};

//
// RSA
//
RsaEncryptionTransform::RsaEncryptionTransform( const RsaParameters& parameters )
{
    unique_ptr<State> state( new State() );

    state->_handle = make_shared<RsaKeyHandle>( parameters );

    _state = state.release();
}

RsaEncryptionTransform::RsaEncryptionTransform( const shared_ptr<RsaKeyHandle>& keyHandle )
{
    unique_ptr<State> state( new State() );

    state->_handle = keyHandle;

    _state = state.release();
}

RsaEncryptionTransform::~RsaEncryptionTransform()
{
    if ( NULL != _state ) delete _state;
}

//
// RSAES-PKCS1-v1_5 [RFC3447]
//
Rsa15EncryptionTransform::Rsa15EncryptionTransform( const RsaParameters& parameters ) : RsaEncryptionTransform( parameters )
{
}

Rsa15EncryptionTransform::Rsa15EncryptionTransform( const shared_ptr<RsaKeyHandle>& keyHandle ) : RsaEncryptionTransform( keyHandle )
{
}

Rsa15EncryptionTransform::~Rsa15EncryptionTransform()
{
}

IEncryptionTransform::EncryptResult Rsa15EncryptionTransform::encrypt( const std::vector<akv::byte_t>& plaintext )
{
    return _state->_handle->encrypt( plaintext, RsaKeyHandle::PaddingMode::PKCS1_5 );
}

IEncryptionTransform::DecryptResult Rsa15EncryptionTransform::decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag )
{
    return _state->_handle->decrypt( ciphertext, RsaKeyHandle::PaddingMode::PKCS1_5 );
}

//
// RSA OAEP
//
RsaOaepEncryptionTransform::RsaOaepEncryptionTransform( const RsaParameters& parameters ) : RsaEncryptionTransform( parameters )
{
}

RsaOaepEncryptionTransform::RsaOaepEncryptionTransform( const shared_ptr<RsaKeyHandle>& keyHandle ) : RsaEncryptionTransform( keyHandle )
{
}

RsaOaepEncryptionTransform::~RsaOaepEncryptionTransform()
{
}

IEncryptionTransform::EncryptResult RsaOaepEncryptionTransform::encrypt( const std::vector<akv::byte_t>& plaintext )
{
    return _state->_handle->encrypt( plaintext, RsaKeyHandle::PaddingMode::OAEP );
}

IEncryptionTransform::DecryptResult RsaOaepEncryptionTransform::decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag )
{
    return _state->_handle->decrypt( ciphertext, RsaKeyHandle::PaddingMode::OAEP );
}

//
// RSA OAEP 256
//
RsaOaep256EncryptionTransform::RsaOaep256EncryptionTransform( const RsaParameters& parameters ) : RsaEncryptionTransform( parameters )
{
}

RsaOaep256EncryptionTransform::RsaOaep256EncryptionTransform( const shared_ptr<RsaKeyHandle>& keyHandle ) : RsaEncryptionTransform( keyHandle )
{
}

RsaOaep256EncryptionTransform::~RsaOaep256EncryptionTransform()
{
}

IEncryptionTransform::EncryptResult RsaOaep256EncryptionTransform::encrypt( const std::vector<akv::byte_t>& plaintext )
{
    return _state->_handle->encrypt( plaintext, RsaKeyHandle::PaddingMode::OAEP256 );
}

IEncryptionTransform::DecryptResult RsaOaep256EncryptionTransform::decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag )
{
    return _state->_handle->decrypt( ciphertext, RsaKeyHandle::PaddingMode::OAEP256 );
}

} }
