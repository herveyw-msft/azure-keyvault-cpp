/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/SignatureAlgorithm.h"
#include "akv/cryptography/AsymmetricSignatureAlgorithm.h"
#include "akv/cryptography/RsaSignatureAlgorithm.h"

#include "akv/cryptography/ISignatureTransform.h"

#include "cryptography/RsaKeyHandle.h"
#include "cryptography/RsaSignatureTransform.h"

namespace akv { namespace cryptography {

// Generic RSA Encrytion (abstract)
RsaSignatureAlgorithm::RsaSignatureAlgorithm( const akv::string_t & name ) : AsymmetricSignatureAlgorithm( name )
{
}

RsaSignatureAlgorithm::~RsaSignatureAlgorithm()
{
}

template<typename T>
std::shared_ptr<ISignatureTransform> RsaSignatureAlgorithm::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<T>( parameters );
}

template<typename T>
std::shared_ptr<ISignatureTransform> RsaSignatureAlgorithm::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<T>( keyHandle );
}

// RSA SHA 256
const string_t& Rs256SignatureAlgorithm::AlgorithmName()
{
    return AlgorithmNames::Rs256();
}

Rs256SignatureAlgorithm::Rs256SignatureAlgorithm() : RsaSignatureAlgorithm( AlgorithmNames::Rs256())
{
}

Rs256SignatureAlgorithm::~Rs256SignatureAlgorithm()
{
}

std::shared_ptr<ISignatureTransform> Rs256SignatureAlgorithm::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<Rs256SignatureTransform>( parameters );
}

std::shared_ptr<ISignatureTransform> Rs256SignatureAlgorithm::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<Rs256SignatureTransform>( keyHandle );
}

// RSA SHA 384
const string_t& Rs384SignatureAlgorithm::AlgorithmName()
{
    return AlgorithmNames::Rs384();
}

Rs384SignatureAlgorithm::Rs384SignatureAlgorithm() : RsaSignatureAlgorithm( AlgorithmNames::Rs384())
{
}

Rs384SignatureAlgorithm::~Rs384SignatureAlgorithm()
{
}

std::shared_ptr<ISignatureTransform> Rs384SignatureAlgorithm::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<Rs384SignatureTransform>( parameters );
}

std::shared_ptr<ISignatureTransform> Rs384SignatureAlgorithm::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<Rs384SignatureTransform>( keyHandle );
}

// RSA SHA 512
const string_t& Rs512SignatureAlgorithm::AlgorithmName()
{
    return AlgorithmNames::Rs512();
}

Rs512SignatureAlgorithm::Rs512SignatureAlgorithm() : RsaSignatureAlgorithm( AlgorithmNames::Rs512())
{
}

Rs512SignatureAlgorithm::~Rs512SignatureAlgorithm()
{
}

std::shared_ptr<ISignatureTransform> Rs512SignatureAlgorithm::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<Rs512SignatureTransform>( parameters );
}

std::shared_ptr<ISignatureTransform> Rs512SignatureAlgorithm::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<Rs512SignatureTransform>( keyHandle );
}

} }
