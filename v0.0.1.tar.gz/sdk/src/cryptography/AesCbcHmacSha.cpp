/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/IEncryptionTransform.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/SymmetricEncryptionAlgorithm.h"

#include "akv/cryptography/AesCbcEncryptionAlgorithm.h"
#include "akv/cryptography/AesCbcHmacSha.h"

#include "cryptography/IncrementalHmac.h"

using namespace std;
using namespace akv;

namespace akv { namespace cryptography {

static std::vector<akv::byte_t> ConvertToBigEndian( int64_t i )
{
    int64_t  target  = i;
    uint8_t *pTarget = reinterpret_cast<uint8_t *>( &target );

    vector<uint8_t> result( pTarget, pTarget + sizeof(int64_t) / sizeof(uint8_t) );

#if TARGET_OS_WIN32 || TARGET_OS_MAC || TARGET_OS_UNIX
    // Windows is little endian
    std::reverse( result.begin(), result.end() );
#else
    // Everyone else is big endian??
#endif

    return result;
}

class AesCbcHmacShaTransform : public IEncryptionTransform
{
public:
    AesCbcHmacShaTransform( const akv::string_t& name, const std::vector<akv::byte_t>& key, const vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad )
    {
        _aad = aad;
        _iv  = iv;

        // Split the key to get the AES key, the HMAC key and the HMAC object
        getAlgorithmParameters( name, key );

        // Prime the hash.
        _hmac->update( _aad );
        _hmac->update( _iv );

        // Create the AES provider
        shared_ptr<Algorithm> algorithm;

        if (_aes_key.size() == 16)
            algorithm = AlgorithmResolver::DefaultResolver().getAlgorithm(AlgorithmNames::Aes128Cbc());
        else if (_aes_key.size() == 24)
            algorithm = AlgorithmResolver::DefaultResolver().getAlgorithm(AlgorithmNames::Aes192Cbc());
        else
            algorithm = AlgorithmResolver::DefaultResolver().getAlgorithm( AlgorithmNames::Aes256Cbc());

        auto aes = dynamic_pointer_cast<Aes>( algorithm );

        // TODO: This is the last use of _aes_key, we should not store it
        _transform = aes->createTransform( _aes_key, iv, vector<akv::byte_t>() );
    }

    virtual ~AesCbcHmacShaTransform()
    {
        SecureZeroMemory( _aes_key );
        SecureZeroMemory( _hmac_key);
        SecureZeroMemory( _iv );
        SecureZeroMemory( _aad );
    }

    virtual EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext )
    {
        if ( plaintext.empty() ) throw invalid_argument( "plaintext" );

        EncryptResult result;

        // Encrypt the plaintext
        result.ciphertext = _transform->encrypt( plaintext ).ciphertext;

        // Update the HMAC and build the tag
        _hmac->update( result.ciphertext );
        
        auto tag = _hmac->updateFinal( ConvertToBigEndian( _aad.size() * 8 ) );

        result.tag = vector<akv::byte_t>( tag.data(), tag.data() + _hmac_key.size() );

        return result;
    }

    virtual DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag )
    {
        if ( ciphertext.empty() ) throw invalid_argument( "ciphertext" );
        if ( tag.empty() ) throw invalid_argument( "tag" );

        vector<akv::byte_t> tagNone;
        DecryptResult  result;

        // Add the cipher text to the running hash
        _hmac->update( ciphertext );

        // Add the associated_data_length bytes to the hash
        auto computedTag = _hmac->updateFinal( ConvertToBigEndian( _aad.size() * 8 ) );
        computedTag = vector<uint8_t>( computedTag.data(), computedTag.data() + _hmac_key.size() );

        // TODO: Compare tags
        if ( !sequence_equal( tag, computedTag ) )
            throw runtime_error( "Data is not authentic" );

        result.plaintext = _transform->decrypt( ciphertext, tagNone ).plaintext;

        return result;
    }

protected:

private:
    vector<uint8_t> _hmac_key;
    vector<uint8_t> _aes_key;

    shared_ptr<IEncryptionTransform>  _transform;
    vector<uint8_t>  _iv;
    vector<uint8_t>  _aad;

    unique_ptr<IncrementalHmac>  _hmac;

    void getAlgorithmParameters( const akv::string_t& name, const vector<uint8_t>& key )
    {
        if ( name.compare( AlgorithmNames::Aes128CbcHmacSha256() ) == 0 )
        {
            if ( ( key.size() << 3 ) < 256 )
                throw runtime_error( "{0} key length in bits {1} < 256" );

            _hmac_key = vector<uint8_t>( key.data(), key.data() + 16 );
            _aes_key  = vector<uint8_t>( key.data() + 16, key.data() + 32 );

            _hmac = unique_ptr<IncrementalHmac>( new IncrementalHmac( __T( "SHA256" ), _hmac_key ) );
        }
        else if ( name.compare( AlgorithmNames::Aes192CbcHmacSha384() ) == 0 )
        {
            if ( ( key.size() << 3 ) < 384 )
                throw runtime_error( "{0} key length in bits {1} < 384" );

            _hmac_key = vector<uint8_t>( key.data(), key.data() + 24 );
            _aes_key  = vector<uint8_t>( key.data() + 24, key.data() + 48 );

            _hmac = unique_ptr<IncrementalHmac>( new IncrementalHmac( __T( "SHA384" ), _hmac_key ) );
        }
        else if ( name.compare( AlgorithmNames::Aes256CbcHmacSha512() ) == 0 )
        {
            if ( ( key.size() << 3 ) < 512 )
                throw runtime_error( "{0} key length in bits {1} < 512" );

            _hmac_key = vector<uint8_t>( key.data(), key.data() + 32 );
            _aes_key  = vector<uint8_t>( key.data() + 32, key.data() + 64 );

            _hmac = unique_ptr<IncrementalHmac>( new IncrementalHmac( __T( "SHA512" ), _hmac_key ) );
        }
        else
        {
            throw runtime_error( "Unsupported algorithm: {0}" );
        }
    }

};

AesCbcHmacSha::AesCbcHmacSha( const akv::string_t & name ) : SymmetricEncryptionAlgorithm( name )
{
}

AesCbcHmacSha::~AesCbcHmacSha()
{
}

std::shared_ptr<IEncryptionTransform> AesCbcHmacSha::createTransform( const std::vector<uint8_t>& key, const std::vector<uint8_t>& iv, const std::vector<uint8_t>& aad ) const
{
    return shared_ptr<IEncryptionTransform>( new AesCbcHmacShaTransform( name(), key, iv, aad ) );
}

//
// A128CBCHS256
//
Aes128CbcHmacSha256::Aes128CbcHmacSha256() : AesCbcHmacSha( AlgorithmNames::Aes128CbcHmacSha256())
{
}

Aes128CbcHmacSha256::~Aes128CbcHmacSha256()
{
}

//
// A192CBCHS384
//
const akv::string_t& Aes128CbcHmacSha256::AlgorithmName()
{
    return AlgorithmNames::Aes128CbcHmacSha256();
}

Aes192CbcHmacSha384::Aes192CbcHmacSha384() : AesCbcHmacSha( AlgorithmNames::Aes192CbcHmacSha384())
{
}

Aes192CbcHmacSha384::~Aes192CbcHmacSha384()
{
}

//
// A128CBCHS256
//
const akv::string_t& Aes192CbcHmacSha384::AlgorithmName()
{
    return AlgorithmNames::Aes192CbcHmacSha384();
}

Aes256CbcHmacSha512::Aes256CbcHmacSha512() : AesCbcHmacSha( AlgorithmNames::Aes256CbcHmacSha512())
{
}

Aes256CbcHmacSha512::~Aes256CbcHmacSha512()
{
}

const akv::string_t& Aes256CbcHmacSha512::AlgorithmName()
{
    return AlgorithmNames::Aes256CbcHmacSha512();
}


} }
