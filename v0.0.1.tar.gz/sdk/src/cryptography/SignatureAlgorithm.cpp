/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/SignatureAlgorithm.h"

namespace akv { namespace cryptography {

SignatureAlgorithm::SignatureAlgorithm( const akv::string_t & name ) : Algorithm( name )
{
}

SignatureAlgorithm::~SignatureAlgorithm()
{
}

} }
