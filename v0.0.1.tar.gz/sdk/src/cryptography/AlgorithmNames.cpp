/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/AlgorithmNames.h"

namespace akv {
namespace cryptography {

// Constant Names
static const akv::string_t _Rsa15( __T( "RSA1_5" ) );
static const akv::string_t _RsaOaep( __T( "RSA-OAEP" ) );
static const akv::string_t _RsaOaep256( __T( "RSA-OAEP-256" ) );

static const akv::string_t _Rs256( __T( "RS256" ) );
static const akv::string_t _Rs384( __T( "RS384" ) );
static const akv::string_t _Rs512( __T( "RS512" ) );

static const akv::string_t _Hs256( __T( "HS256" ) );
static const akv::string_t _Hs384( __T( "HS384" ) );
static const akv::string_t _Hs512( __T( "HS512" ) );

static const akv::string_t _Aes128Kw( __T( "A128KW" ) );
static const akv::string_t _Aes192Kw( __T( "A192KW" ) );
static const akv::string_t _Aes256Kw( __T( "A256KW" ) );

static const akv::string_t _Aes128Cbc( __T( "A128CBC" ) );
static const akv::string_t _Aes192Cbc( __T( "A192CBC" ) );
static const akv::string_t _Aes256Cbc( __T( "A256CBC" ) );

static const akv::string_t _Aes128CbcHmacSha256( __T( "A128CBC-HS256" ) );
static const akv::string_t _Aes192CbcHmacSha384( __T( "A192CBC-HS384" ) );
static const akv::string_t _Aes256CbcHmacSha512( __T( "A256CBC-HS512" ) );

// Name functions
const akv::string_t& AlgorithmNames::Rsa15() { return _Rsa15; }
const akv::string_t& AlgorithmNames::RsaOaep() { return _RsaOaep; }
const akv::string_t& AlgorithmNames::RsaOaep256() { return _RsaOaep256; }

const akv::string_t& AlgorithmNames::Rs256() { return _Rs256; }
const akv::string_t& AlgorithmNames::Rs384() { return _Rs384; }
const akv::string_t& AlgorithmNames::Rs512() { return _Rs512; }

const akv::string_t& AlgorithmNames::Hs256() { return _Hs256; }
const akv::string_t& AlgorithmNames::Hs384() { return _Hs384; }
const akv::string_t& AlgorithmNames::Hs512() { return _Hs512; }

const akv::string_t& AlgorithmNames::Aes128Kw() { return _Aes128Kw; }
const akv::string_t& AlgorithmNames::Aes192Kw() { return _Aes192Kw; }
const akv::string_t& AlgorithmNames::Aes256Kw() { return _Aes256Kw; }

const akv::string_t& AlgorithmNames::Aes128Cbc() { return _Aes128Cbc; }
const akv::string_t& AlgorithmNames::Aes192Cbc() { return _Aes192Cbc; }
const akv::string_t& AlgorithmNames::Aes256Cbc() { return _Aes256Cbc; }

const akv::string_t& AlgorithmNames::Aes128CbcHmacSha256() { return _Aes128CbcHmacSha256; }
const akv::string_t& AlgorithmNames::Aes192CbcHmacSha384() { return _Aes192CbcHmacSha384; }
const akv::string_t& AlgorithmNames::Aes256CbcHmacSha512() { return _Aes256CbcHmacSha512; }

}
}
