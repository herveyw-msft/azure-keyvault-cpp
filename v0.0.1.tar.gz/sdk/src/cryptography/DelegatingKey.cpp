/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/cryptography/DelegatingKey.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct DelegatingKey::State
{
    State( const std::shared_ptr<IKey>& inner ) : _inner( inner ) { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    shared_ptr<IKey> _inner;
};

DelegatingKey::DelegatingKey( const std::shared_ptr<akv::IKey>& key ) : _state( new State( key ) )
{
}

DelegatingKey::DelegatingKey( DelegatingKey&& other )
{
    _state = other._state;
    other._state = NULL;
}

DelegatingKey& DelegatingKey::operator = ( DelegatingKey&& other )
{
    if ( _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

DelegatingKey::~DelegatingKey()
{
    if ( NULL != _state ) delete _state;
}

akv::string_t DelegatingKey::kid() const
{
    return _state->_inner->kid();
}

akv::string_t DelegatingKey::defaultEncryptionAlgorithm() const
{
    return _state->_inner->defaultEncryptionAlgorithm();
}

akv::string_t DelegatingKey::defaultKeyWrapAlgorithm() const
{
    return _state->_inner->defaultKeyWrapAlgorithm();
}

akv::string_t DelegatingKey::defaultSignatureAlgorithm() const
{
    return _state->_inner->defaultSignatureAlgorithm();
}

pplx::task<IKey::DecryptResult> DelegatingKey::decrypt( const akv::string_t&            algorithm,
                                                        const std::vector<akv::byte_t>& ciphertext,
                                                        const std::vector<akv::byte_t>& iv,
                                                        const std::vector<akv::byte_t>& authenticationData,
                                                        const std::vector<akv::byte_t>& authenticationTag,
                                                        const pplx::cancellation_token& token ) const
{
    return _state->_inner->decrypt( algorithm, ciphertext, iv, authenticationData, authenticationTag, token );
}

pplx::task<IKey::EncryptResult> DelegatingKey::encrypt( const akv::string_t&            algorithm,
                                                        const std::vector<akv::byte_t>& plaintext,
                                                        const std::vector<akv::byte_t>& iv,
                                                        const std::vector<akv::byte_t>& authenticationData,
                                                        const pplx::cancellation_token& token ) const
{
    return _state->_inner->encrypt( algorithm, plaintext, iv, authenticationData, token );
}

pplx::task<IKey::WrapResult> DelegatingKey::wrap( const akv::string_t&            algorithm,
                                                  const std::vector<akv::byte_t>& key,
                                                  const pplx::cancellation_token& token ) const
{
    return _state->_inner->wrap( algorithm, key, token );
}

pplx::task<IKey::UnwrapResult> DelegatingKey::unwrap( const akv::string_t&            algorithm,
                                                      const std::vector<akv::byte_t>& encryptedKey,
                                                      const pplx::cancellation_token& token ) const
{
    return _state->_inner->unwrap( algorithm, encryptedKey, token );
}

pplx::task<IKey::SignResult> DelegatingKey::signHash( const akv::string_t&            algorithm,
                                                      const std::vector<akv::byte_t>& digest,
                                                      const pplx::cancellation_token& token ) const
{
    return _state->_inner->signHash( algorithm, digest, token );
}

pplx::task<IKey::VerifyResult> DelegatingKey::verifyHash( const akv::string_t&            algorithm,
                                                          const std::vector<akv::byte_t>& digest,
                                                          const std::vector<akv::byte_t>& signature,
                                                          const pplx::cancellation_token& token ) const
{
    return _state->_inner->verifyHash( algorithm, digest, signature, token );
}

} }
