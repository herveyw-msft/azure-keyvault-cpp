/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/common/base64.h"

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/IEncryptionTransform.h"
#include "akv/cryptography/ISignatureTransform.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/AsymmetricEncryptionAlgorithm.h"
#include "akv/cryptography/RsaEncryptionAlgorithm.h"

#include "akv/cryptography/SignatureAlgorithm.h"
#include "akv/cryptography/AsymmetricSignatureAlgorithm.h"
#include "akv/cryptography/RsaSignatureAlgorithm.h"

#include "akv/cryptography/Key.h"
#include "akv/cryptography/CertificateKey.h"

#include "cryptography/RsaKeyHandle.h"

using namespace akv;
using namespace std;
using namespace pplx;

namespace akv { namespace cryptography {

static const std::vector<akv::byte_t> tagNone;

struct CertificateKey::State
{
    shared_ptr<RsaKeyHandle> _handle;
    std::vector<akv::byte_t> _thumbprint;
};

CertificateKey::CertificateKey( const akv::string_t& kid, PCCERT_CONTEXT context ) : Key( kid )
{
    unique_ptr<State> state( new State() );

    state->_handle = make_shared<RsaKeyHandle>( context );

    // Retrieve the thumbprint
    DWORD cbData = 0;

    if ( ::CertGetCertificateContextProperty( context, CERT_HASH_PROP_ID, NULL, &cbData ) == TRUE )
    {
        state->_thumbprint.resize( cbData );

        ::CertGetCertificateContextProperty( context, CERT_HASH_PROP_ID, state->_thumbprint.data(), &cbData );
    }

    _state = state.release();
}

CertificateKey::~CertificateKey()
{
    if ( NULL != _state ) delete _state;
}

const std::vector<akv::byte_t>& CertificateKey::Thumbprint() const
{
    return _state->_thumbprint;
}

akv::string_t CertificateKey::x5t() const
{
    return common::Base64::encode_url( _state->_thumbprint );
}

akv::string_t CertificateKey::defaultEncryptionAlgorithm() const
{
    return AlgorithmNames::RsaOaep();
}

akv::string_t CertificateKey::defaultKeyWrapAlgorithm() const
{
    return AlgorithmNames::RsaOaep();
}

akv::string_t CertificateKey::defaultSignatureAlgorithm() const
{
    return AlgorithmNames::Rs256();
}

pplx::task<IKey::DecryptResult> CertificateKey::decrypt( const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& cipher_text,
                                                 const std::vector<akv::byte_t>& iv,
                                                 const std::vector<akv::byte_t>& authentication_data,
                                                 const std::vector<akv::byte_t>& authentication_tag,
                                                 const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return decrypt_transform( transform, cipher_text, authentication_tag, token );
}

pplx::task<IKey::EncryptResult> CertificateKey::encrypt( const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& plain_text,
                                                 const std::vector<akv::byte_t>& iv,
                                                 const std::vector<akv::byte_t>& authentication_data,
                                                 const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return encrypt_transform( transform, plain_text, token );
}

pplx::task<IKey::WrapResult> CertificateKey::wrap( const akv::string_t&            algorithm_name,
                                           const std::vector<akv::byte_t>& plain_text,
                                           const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    // RSA uses Encrypt and so the result has to be transformed
    return encrypt_transform( transform, plain_text, token ).then( []( EncryptResult result ) -> WrapResult
    {
        return WrapResult( result.kid, result.value );
    }, token );
}

pplx::task<IKey::UnwrapResult> CertificateKey::unwrap( const akv::string_t&            algorithm_name,
                                               const std::vector<akv::byte_t>& cipher_text,
                                               const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    // RSA uses Decrypt and so the result has to be transformed
    return decrypt_transform( transform, cipher_text, tagNone, token ).then( []( DecryptResult result ) -> UnwrapResult
    {
        return UnwrapResult( result.kid, result.value );
    }, token );
}

/// <summary>
/// Signs the specified digest.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="token">Cancellation token</param>
/// <returns>The signature value</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::SignResult> CertificateKey::signHash( const akv::string_t&             algorithm_name,
                                               const std::vector<akv::byte_t>&  digest,
                                               const pplx::cancellation_token&  token ) const
{
    auto algorithm = get_algorithm<RsaSignatureAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return sign_transform( transform, digest, token );
}

/// <summary>
/// Verifies the specified digest and signature.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="signature">The signature to verify</param>
/// <param name="token">Cancellation token</param>
/// <returns>True if the signature verifies</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::VerifyResult> CertificateKey::verifyHash( const akv::string_t&            algorithm_name,
                                                   const std::vector<akv::byte_t>& digest,
                                                   const std::vector<akv::byte_t>& signature,
                                                   const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaSignatureAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return verify_transform( transform, digest, signature, token );
}

} }
