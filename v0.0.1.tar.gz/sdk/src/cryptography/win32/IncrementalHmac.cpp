/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "cryptography/IncrementalHmac.h"

#include <boost/numeric/conversion/cast.hpp>

using namespace std;

namespace akv { namespace cryptography {

struct IncrementalHmac::State
{
    BCRYPT_ALG_HANDLE  _hAlgorithm;
    BCRYPT_HASH_HANDLE _hHash;
    PBYTE              _pbHashObject;
    DWORD              _cbHash;
    PBYTE              _pbHash;
};

IncrementalHmac::IncrementalHmac( const akv::string_t& hashName, const std::vector<akv::byte_t>& secret )
{
    if ( hashName.size() == 0 ) throw invalid_argument( "hashName" );
    if ( secret.size() == 0 ) throw invalid_argument( "secret" );

    _state = new State();

    NTSTATUS           status;
    DWORD              cbData;
    DWORD              cbHashObject;

    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &_state->_hAlgorithm,
                                                             hashName.data(),
                                                             NULL,
                                                             BCRYPT_ALG_HANDLE_HMAC_FLAG ) ) )
    {
        //calculate the size of the buffer to hold the hash object
        if ( NT_SUCCESS( status = ::BCryptGetProperty( _state->_hAlgorithm,
                                                       BCRYPT_OBJECT_LENGTH,
                                                       (PBYTE)&cbHashObject,
                                                       sizeof(DWORD),
                                                       &cbData,
                                                       0 ) ) )
        {
            //allocate the hash object on the heap
            _state->_pbHashObject = (PBYTE)::HeapAlloc (::GetProcessHeap(), 0, cbHashObject);

            if ( NULL != _state->_pbHashObject )
            {
                //calculate the length of the hash
                if( NT_SUCCESS(status = ::BCryptGetProperty( _state->_hAlgorithm,
                                                             BCRYPT_HASH_LENGTH,
                                                             (PBYTE)&_state->_cbHash,
                                                             sizeof(DWORD),
                                                             &cbData,
                                                             0 ) ) )
                {
                    //allocate the hash buffer on the heap
                    _state->_pbHash = (PBYTE)::HeapAlloc (::GetProcessHeap (), 0, _state->_cbHash);

                    if ( NULL != _state->_pbHash)
                    {
                        //create a hash
                        if( NT_SUCCESS(status = ::BCryptCreateHash( _state->_hAlgorithm,
                                                                    &_state->_hHash,
                                                                    _state->_pbHashObject,
                                                                    cbHashObject,
                                                                    (PUCHAR)secret.data(),
                                                                    (DWORD)secret.size(),
                                                                    0 ) ) )
                        {
                            return;
                        }
                    }
                }
            }
        }
        dispose();

        throw runtime_error( "IncrementalHmac::IncrementalHash" );
    }

}

IncrementalHmac::~IncrementalHmac()
{
    dispose();
}

void IncrementalHmac::update( const std::vector<akv::byte_t>& data )
{
    NTSTATUS status;

    //hash some data
    if( !NT_SUCCESS(status = ::BCryptHashData( _state->_hHash, (PBYTE)data.data(), boost::numeric_cast<ULONG, size_t>(data.size()), 0 ) ) )
    {
        throw runtime_error( "IncrementalHmac::update" );
    }
}

vector<akv::byte_t> IncrementalHmac::updateFinal( const std::vector<akv::byte_t>& data )
{
    NTSTATUS status;

    //hash some data
    if( !NT_SUCCESS(status = ::BCryptHashData( _state->_hHash, (PBYTE)data.data(), boost::numeric_cast<ULONG, size_t>(data.size()), 0 ) ) )
    {
        throw runtime_error( "IncrementalHmac::updateFinal" );
    }

    //close the hash
    if ( !NT_SUCCESS(status = ::BCryptFinishHash( _state->_hHash, _state->_pbHash, _state->_cbHash, 0 ) ) )
    {
    }

    return vector<akv::byte_t>( _state->_pbHash, _state->_pbHash + _state->_cbHash );
}

void IncrementalHmac::dispose()
{
    if ( _state )
    {
        if (_state->_hAlgorithm)
        {
            BCryptCloseAlgorithmProvider(_state->_hAlgorithm,0);
        }

        if (_state->_hHash)    
        {
            BCryptDestroyHash(_state->_hHash);
        }

        if (_state->_pbHashObject)
        {
            HeapFree(GetProcessHeap(), 0, _state->_pbHashObject);
        }

        if (_state->_pbHash)
        {
            HeapFree(GetProcessHeap(), 0, _state->_pbHash);
        }

        delete _state;
        _state = NULL;
    }
}

} }
