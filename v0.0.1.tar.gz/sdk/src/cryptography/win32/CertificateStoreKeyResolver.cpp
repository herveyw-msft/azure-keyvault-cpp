/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/core/IKey.h"
#include "akv/core/IKeyResolver.h"

#include "akv/cryptography/Key.h"
#include "akv/cryptography/CertificateKey.h"
#include "akv/cryptography/CertificateStoreKeyResolver.h"

using namespace akv;
using namespace std;
using namespace pplx;

namespace akv { namespace cryptography {

struct CertificateStoreKeyResolver::State
{
    State() { }
    State( const State& )              = delete;
    State& operator = ( const State& ) = delete;
    ~State()
    {
        ::CertCloseStore( _hStore, 0 );
    }

    HCERTSTORE _hStore;
};

static const akv::string_t _LocalMachine( __T("LocalMachine") );
static const akv::string_t _CurrentUser( __T("CurrentUser") );

const akv::string_t& CertificateStoreKeyResolver::LocalMachine()
{
    return _LocalMachine;
}

const akv::string_t& CertificateStoreKeyResolver::CurrentUser()
{
    return _CurrentUser;
}

CertificateStoreKeyResolver::CertificateStoreKeyResolver( const akv::string_t& storeLocation, const akv::string_t& storeName )
{
    DWORD flags = CERT_STORE_READONLY_FLAG;

    if ( _CurrentUser.compare( storeLocation ) == 0 )
        flags |= CERT_SYSTEM_STORE_CURRENT_USER;
    else if ( _LocalMachine.compare( storeLocation ) == 0 )
        flags |= CERT_SYSTEM_STORE_LOCAL_MACHINE;
    else
        throw invalid_argument( "storeLocation" );

    unique_ptr<State> state( new State() );

    state->_hStore = ::CertOpenStore( CERT_STORE_PROV_SYSTEM,   // the store provider type
                                      0,                        // the encoding type is not needed
                                      NULL,                     // use the default HCRYPTPROV
                                      flags,                    // Store Location
                                      storeName.c_str() );      // the store name as a Unicode string

    if ( state->_hStore == nullptr )
    {
        int error = GetLastError();
        throw std::system_error(error, std::system_category());
    }

    _state = state.release();
}


CertificateStoreKeyResolver::~CertificateStoreKeyResolver()
{
    if ( NULL != _state ) delete _state;
}


pplx::task<std::shared_ptr<IKey>> CertificateStoreKeyResolver::resolve_key( const akv::string_t& kid, const pplx::cancellation_token& token ) const
{
    auto self = this;

    return pplx::create_task( [self, kid]() -> std::shared_ptr<IKey>
    {
        PCCERT_CONTEXT certificate = NULL;

        if ( certificate = ::CertFindCertificateInStore( self->_state->_hStore,
                                                         (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING), // Use X509_ASN_ENCODING.
                                                         0,                                         // No dwFlags needed.
                                                         CERT_FIND_HASH_STR,                        // Find a certificate with a hash that matches the string
                                                         kid.c_str(),                               // The Unicode string to be found
                                                         NULL ) )                                   // NULL for the first call to the
                                                                                                    // function. In all subsequent
                                                                                                    // calls, it is the last pointer
                                                                                                    // returned by the function.
        {
            return make_shared<CertificateKey>( kid, certificate );
        }
        else
        {
            return shared_ptr<IKey>();
        }
    }, token );
}

} }
