/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/IEncryptionTransform.h"

#include "cryptography/AesCbcEncryptionTransform.h"

#include <boost/numeric/conversion/cast.hpp>

using namespace std;

namespace akv { namespace cryptography {

struct AesCbcEncryptionTransform::State
{
    State() { };
    ~State()
    {
        if ( _hKey )       ::BCryptDestroyKey( _hKey );
        if ( _hAlgorithm ) ::BCryptCloseAlgorithmProvider( _hAlgorithm, 0 );

        SecureZeroMemory( _iv );
    }

    BCRYPT_ALG_HANDLE      _hAlgorithm = NULL;
    BCRYPT_KEY_HANDLE      _hKey       = NULL;
    std::vector<akv::byte_t> _iv;
};

AesCbcEncryptionTransform::AesCbcEncryptionTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv )
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( iv.empty() ) throw invalid_argument( "iv" );

    // Ensure destruction of any state if we fail
    unique_ptr<State> state( new State() );

    NTSTATUS status                      = -1;
    DWORD    cbBlockLen                  = 0,
             cbData                      = 0;

    // Open an algorithm handle.
    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &state->_hAlgorithm, BCRYPT_AES_ALGORITHM, NULL, 0 ) ) )
    {
        // Calculate the block length for the IV.
        if ( NT_SUCCESS( status = ::BCryptGetProperty( state->_hAlgorithm, BCRYPT_BLOCK_LENGTH, (PBYTE)&cbBlockLen, sizeof(DWORD), &cbData, 0 ) ) )
        {
            // Determine whether the cbBlockLen is not longer than the IV length.
            if ( cbBlockLen <= iv.size() )
            {
                // Allocate a buffer for the IV. The buffer is consumed during the encrypt/decrypt process.
                state->_iv = vector<akv::byte_t>( iv.data(), iv.data() + cbBlockLen );

                // CBC mode
                if ( NT_SUCCESS( status = ::BCryptSetProperty( state->_hAlgorithm, BCRYPT_CHAINING_MODE, (PBYTE)BCRYPT_CHAIN_MODE_CBC, sizeof(BCRYPT_CHAIN_MODE_CBC), 0 ) ) )
                {
                    // Generate the key from supplied input key bytes.
                    status = ::BCryptGenerateSymmetricKey( 
                        state->_hAlgorithm,
                        &state->_hKey,
                        NULL,
                        0,
                        (PBYTE)key.data(),
                        boost::numeric_cast<ULONG, size_t>(key.size()),
                        0
                    );
                }
            }
            else
            {
                // Ensure that we fail
                status = -1;
            }
        }
    }

    if ( NT_SUCCESS( status ) )
    {
        _state = state.release();
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}
//
// Move
//
AesCbcEncryptionTransform::AesCbcEncryptionTransform( AesCbcEncryptionTransform&& other )
{
    _state = other._state;
    other._state = NULL;
}

//
// Move Assign
//
AesCbcEncryptionTransform& AesCbcEncryptionTransform::operator = ( AesCbcEncryptionTransform&& other )
{
    if ( NULL != _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

AesCbcEncryptionTransform::~AesCbcEncryptionTransform()
{
    if ( NULL != _state ) delete _state;
}

AesCbcEncryptionTransform::EncryptResult AesCbcEncryptionTransform::encrypt( const std::vector<akv::byte_t>& plaintext )
{
    NTSTATUS status;
    ULONG    cbResult;
    ULONG    cbOutput;
    PBYTE    pbOutput = NULL;

    vector<uint8_t> result;

    //
    // Get the output buffer size.
    //
    if ( NT_SUCCESS(status = ::BCryptEncrypt( _state->_hKey,
                                              (PUCHAR)plaintext.data(),
                                              boost::numeric_cast<ULONG, size_t>(plaintext.size()),
                                              NULL,
                                              (PUCHAR)_state->_iv.data(),
                                              boost::numeric_cast<ULONG, size_t>(_state->_iv.size()),
                                              NULL,
                                              0,
                                              &cbOutput,
                                              BCRYPT_BLOCK_PADDING ) ) )
    {
        pbOutput = (PBYTE)::HeapAlloc( ::GetProcessHeap (), 0, cbOutput );

        if ( NULL != pbOutput )
        {
            // Use the key to encrypt the plaintext buffer.
            // For block sized messages, block padding will add an extra block.
            if ( NT_SUCCESS(status = ::BCryptEncrypt( _state->_hKey,
                                                      (PUCHAR)plaintext.data(),
                                                      boost::numeric_cast<ULONG, size_t>(plaintext.size()),
                                                      NULL,
                                                      (PUCHAR)_state->_iv.data(),
                                                      boost::numeric_cast<ULONG, size_t>(_state->_iv.size()),
                                                      pbOutput,
                                                      cbOutput,
                                                      &cbResult,
                                                      BCRYPT_BLOCK_PADDING ) ) )
            {
                result = vector<akv::byte_t>( pbOutput, pbOutput + cbOutput );
            }

            ::SecureZeroMemory( pbOutput, cbOutput );
            ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
        }
    }

    if ( NT_SUCCESS( status ) )
    {
        return AesCbcEncryptionTransform::EncryptResult( result );
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

AesCbcEncryptionTransform::DecryptResult AesCbcEncryptionTransform::decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag )
{
    NTSTATUS status;
    ULONG    cbData;
    ULONG    cbOutput;
    PBYTE    pbOutput = NULL;

    vector<akv::byte_t> result;

    //
    // Get the output buffer size.
    //
    if( NT_SUCCESS(status = ::BCryptDecrypt( _state->_hKey,
                                             (PUCHAR)ciphertext.data(),
                                             boost::numeric_cast<ULONG, size_t>(ciphertext.size()),
                                             NULL,
                                             (PUCHAR)_state->_iv.data(),
                                             boost::numeric_cast<ULONG, size_t>(_state->_iv.size()),
                                             NULL,
                                             0,
                                             &cbOutput,
                                             BCRYPT_BLOCK_PADDING ) ) )
    {
        pbOutput = (PBYTE)::HeapAlloc(::GetProcessHeap (), 0, cbOutput );

        if ( NULL != pbOutput)
        {
            // Use the key to encrypt the plaintext buffer.
            // For block sized messages, block padding will add an extra block.
            if ( NT_SUCCESS(status = ::BCryptDecrypt( _state->_hKey,
                                                      (PUCHAR)ciphertext.data(),
                                                      boost::numeric_cast<ULONG, size_t>(ciphertext.size()),
                                                      NULL,
                                                      (PUCHAR)_state->_iv.data(),
                                                      boost::numeric_cast<ULONG, size_t>(_state->_iv.size()),
                                                      pbOutput,
                                                      cbOutput,
                                                      &cbData,
                                                      BCRYPT_BLOCK_PADDING ) ) )
            {
                result = vector<akv::byte_t>( pbOutput, pbOutput + cbData );
            }
            
            ::SecureZeroMemory( pbOutput, cbOutput );
            ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
        }
    }

    if ( NT_SUCCESS( status ) )
    {
        return AesCbcEncryptionTransform::DecryptResult( result );
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

} }

