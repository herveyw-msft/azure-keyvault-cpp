/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/IKeyWrapTransform.h"

#include "cryptography/AesKeyWrapTransform.h"

#include <boost/numeric/conversion/cast.hpp>

using namespace std;

namespace akv { namespace cryptography {

struct AesKeyWrapTransform::State
{
    State() { };
    ~State()
    {
        if ( _hKey )       ::BCryptDestroyKey( _hKey );
        if ( _hAlgorithm ) ::BCryptCloseAlgorithmProvider( _hAlgorithm, 0 );
    }

    BCRYPT_ALG_HANDLE _hAlgorithm = NULL;
    BCRYPT_KEY_HANDLE _hKey       = NULL;
};

AesKeyWrapTransform::AesKeyWrapTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv )
{
    if ( key.empty() ) throw invalid_argument( "key" );
    if ( key.size() != 16 && key.size() != 24 && key.size() != 32 ) throw invalid_argument( "key" );

    if ( iv.empty() ) throw invalid_argument( "iv" );

    // Ensure destruction of any state if we fail
    unique_ptr<State> state( new State() );

    NTSTATUS status                      = -1;
    DWORD    cbBlockLen                  = 0,
             cbResult                    = 0;

    // Open an algorithm handle.
    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &state->_hAlgorithm, BCRYPT_AES_ALGORITHM, NULL, 0 ) ) )
    {
        // Generate the key from supplied input key bytes.
        status = ::BCryptGenerateSymmetricKey( state->_hAlgorithm, &state->_hKey, NULL, 0, (PBYTE)key.data(), boost::numeric_cast<ULONG, size_t>(key.size()), 0 );
    }

    if ( NT_SUCCESS( status ) )
    {
        _state = state.release();
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

AesKeyWrapTransform::~AesKeyWrapTransform()
{
    if ( NULL != _state ) delete _state;
}

AesKeyWrapTransform::WrapResult AesKeyWrapTransform::wrap( const std::vector<akv::byte_t>& key )
{
    // The key to be wrapped must not be empty, and must be a multiple of 64bits
    if ( key.empty() ) throw invalid_argument( "plaintext" );
    if ( key.size() % 8 != 0 ) throw invalid_argument( "key" );

    // Temporary for generating the key to be wrapped
    unique_ptr<State> state( new State() );
    vector<akv::byte_t> result;

    NTSTATUS status   = 0;
    ULONG    cbResult = 0;
    ULONG    cbData   = 0;
    LPBYTE   pbData   = NULL;

    // Open an algorithm handle.
    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &state->_hAlgorithm, BCRYPT_AES_ALGORITHM, NULL, 0 ) ) )
    {
        // Generate the key from supplied input key bytes.
        if ( NT_SUCCESS( status = ::BCryptGenerateSymmetricKey(
            state->_hAlgorithm, 
            &state->_hKey, 
            NULL, 
            0, 
            (PBYTE)key.data(), 
            boost::numeric_cast<ULONG, size_t>(key.size()),
            0 
        ) ) )
        {
            if ( NT_SUCCESS( status = ::BCryptExportKey( state->_hKey, _state->_hKey, BCRYPT_AES_WRAP_KEY_BLOB, NULL, 0, &cbData, 0 ) ) )
            {
                pbData = (LPBYTE)::HeapAlloc( ::GetProcessHeap(), 0, cbData );

                if ( pbData )
                {
                    if ( NT_SUCCESS( status = ::BCryptExportKey( state->_hKey, _state->_hKey, BCRYPT_AES_WRAP_KEY_BLOB, pbData, cbData, &cbResult, 0 ) ) )
                    {
                        result = vector<akv::byte_t>( pbData, pbData + cbData );
                    }

                    ::SecureZeroMemory( pbData, cbData );
                    ::HeapFree( ::GetProcessHeap(), 0, pbData );
                }
            }
        }
    }

    if ( NT_SUCCESS( status ) )
    {
        return IKeyWrapTransform::WrapResult( result );
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

AesKeyWrapTransform::UnwrapResult AesKeyWrapTransform::unwrap( const std::vector<akv::byte_t>& encryptedKey )
{
    // The key to be unwrapped must not be empty, and must be a multiple of 64bits
    if ( encryptedKey.empty() ) throw invalid_argument( "encryptedKey" );
    if ( encryptedKey.size() % 8 != 0 ) throw invalid_argument( "encryptedKey" );

    // Temporary
    unique_ptr<State> state( new State() );
    vector<akv::byte_t> result;

    NTSTATUS status   = 0;
    ULONG    cbResult = 0;
    ULONG    cbData   = 0;
    LPBYTE   pbData   = NULL;

    if ( NT_SUCCESS( status = ::BCryptImportKey( _state->_hAlgorithm,
                                                 _state->_hKey,
                                                 BCRYPT_AES_WRAP_KEY_BLOB,
                                                 &state->_hKey,
                                                 NULL,
                                                 0,
                                                 (PUCHAR)encryptedKey.data(),
                                                 boost::numeric_cast<ULONG, size_t>(encryptedKey.size()),
                                                 0 ) ) )
    {
        if ( NT_SUCCESS( status = ::BCryptExportKey( state->_hKey, NULL, BCRYPT_KEY_DATA_BLOB, NULL, 0, &cbResult, 0 ) ) )
        {
            cbData = cbResult;
            pbData = (LPBYTE)::HeapAlloc( ::GetProcessHeap(), 0, cbData );

            if ( pbData )
            {
                if ( NT_SUCCESS( status = ::BCryptExportKey( state->_hKey, _state->_hKey, BCRYPT_KEY_DATA_BLOB, pbData, cbData, &cbResult, 0 ) ) )
                {
                    BCRYPT_KEY_DATA_BLOB_HEADER *pHeader = (BCRYPT_KEY_DATA_BLOB_HEADER *)pbData;

                    result = vector<akv::byte_t>( pbData + sizeof( BCRYPT_KEY_DATA_BLOB_HEADER ), pbData + sizeof( BCRYPT_KEY_DATA_BLOB_HEADER ) + pHeader->cbKeyData );
                }

                ::SecureZeroMemory( pbData, cbData );
                ::HeapFree( ::GetProcessHeap(), 0, pbData );
            }
        }

    }

    if ( NT_SUCCESS( status ) )
    {
        return IKeyWrapTransform::UnwrapResult( result );
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

} }

