/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/RsaParameters.h"
#include "cryptography/RsaKeyHandle.h"

#include <boost/numeric/conversion/cast.hpp>


using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct RsaKeyHandle::State
{
    State() { }
    State( const State& )              = delete;
    State( State&& )                   = delete;
    State& operator = ( const State& ) = delete;
    State& operator = ( State&& )      = delete;
    ~State()
    {
        if ( NULL != _bcryptHandle )
        {
            ::BCryptDestroyKey( _bcryptHandle );
        }

        if ( NULL != _ncryptHandle && _ncryptFreeHandle )
        {
            ::NCryptFreeObject( _ncryptHandle );
        }

        if ( NULL != _hAlgorithm )
        {
            ::BCryptCloseAlgorithmProvider( _hAlgorithm, 0 );
        }
    }

    BCRYPT_ALG_HANDLE _hAlgorithm     = NULL;

    BCRYPT_KEY_HANDLE _bcryptHandle        = NULL;
    bool              _bcryptPrivateHandle = false;

    NCRYPT_KEY_HANDLE _ncryptHandle     = NULL;
    BOOL              _ncryptFreeHandle = false;
};

RsaKeyHandle::RsaKeyHandle()
{
    unique_ptr<State> state( new State() );

    // Remember we have private key
    state->_bcryptPrivateHandle = true;

    NTSTATUS status = -1;

    // Open an algorithm handle.
    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &state->_hAlgorithm, BCRYPT_RSA_ALGORITHM, NULL, 0 ) ) )
    {
        if ( NT_SUCCESS( status = ::BCryptGenerateKeyPair( state->_hAlgorithm, &state->_bcryptHandle, 2048, 0 ) ) )
        {
            status = ::BCryptFinalizeKeyPair( state->_bcryptHandle, 0 );
        }
    }

    if ( NT_SUCCESS( status ) )
    {
        _state = state.release();
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

RsaKeyHandle::RsaKeyHandle( const RsaParameters& parameters )
{
    unique_ptr<State> state( new State() );

    //
    NTSTATUS status = -1;

    // Open an algorithm handle.
    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &state->_hAlgorithm, BCRYPT_RSA_ALGORITHM, NULL, 0 ) ) )
    {
        // Public key only for the moment
        state->_bcryptPrivateHandle = false;

        // Allocate space for the big blob
        size_t            cbBlob = sizeof( BCRYPT_RSAKEY_BLOB ) +
                                    parameters.e().size() +
                                    parameters.n().size() +
                                    ( parameters.p().size() * 3 ) +
                                    ( parameters.q().size() * 2 ) +
                                    parameters.d().size();
        vector<akv::byte_t> blob( cbBlob );

        // Set up the blob header
        BCRYPT_RSAKEY_BLOB *header    = (BCRYPT_RSAKEY_BLOB *)blob.data();
        LPCWSTR             blob_type = BCRYPT_RSAPUBLIC_BLOB;

        header->Magic       = BCRYPT_RSAPUBLIC_MAGIC;
        // TODO: key bit length; some libraries can pad the data with leading zero bytes
        header->BitLength   = boost::numeric_cast<ULONG, size_t>(parameters.n().size() << 3);
        header->cbModulus   = boost::numeric_cast<ULONG, size_t>(parameters.n().size());
        header->cbPublicExp = boost::numeric_cast<ULONG, size_t>(parameters.e().size());
        header->cbPrime1    = 0;
        header->cbPrime2    = 0;

        size_t offset = sizeof( BCRYPT_RSAKEY_BLOB );

        // Copy the public exponent
        std::copy( parameters.e().begin(), parameters.e().end(), blob.begin() + offset );
        offset += parameters.e().size();

        // Copy the modulus
        std::copy( parameters.n().begin(), parameters.n().end(), blob.begin() + offset );
        offset += parameters.n().size();

        // Now check for private key material
        if ( parameters.hasPrivateParameters() )
        {
            blob_type        = BCRYPT_RSAFULLPRIVATE_BLOB;
            header->Magic    = BCRYPT_RSAFULLPRIVATE_MAGIC;
            header->cbPrime1 = boost::numeric_cast<ULONG, size_t>( parameters.p().size() );
            header->cbPrime2 = boost::numeric_cast<ULONG, size_t>( parameters.q().size() );

            // Copy prime1
            if ( offset + parameters.p().size() > cbBlob ) throw runtime_error( "buffer overrun" );
            std::copy( parameters.p().begin(), parameters.p().end(), blob.begin() + offset );
            offset += parameters.p().size();

            // Copy prime2
            if ( offset + parameters.q().size() > cbBlob ) throw runtime_error( "buffer overrun" );
            std::copy( parameters.q().begin(), parameters.q().end(), blob.begin() + offset );
            offset += parameters.q().size();

            // Copy exponent1
            if ( offset + parameters.dp().size() > cbBlob ) throw runtime_error( "buffer overrun" );
            std::copy( parameters.dp().begin(), parameters.dp().end(), blob.begin() + offset );
            offset += parameters.dp().size();

            // Copy exponent2
            if ( offset + parameters.dq().size() > cbBlob ) throw runtime_error( "buffer overrun" );
            std::copy( parameters.dq().begin(), parameters.dq().end(), blob.begin() + offset );
            offset += parameters.dq().size();

            // Copy coefficient
            if ( offset + parameters.qi().size() > cbBlob ) throw runtime_error( "buffer overrun" );
            std::copy( parameters.qi().begin(), parameters.qi().end(), blob.begin() + offset );
            offset += parameters.qi().size();

            // Copy private exponent
            if ( offset + parameters.d().size() > cbBlob ) throw runtime_error( "buffer overrun" );
            std::copy( parameters.d().begin(), parameters.d().end(), blob.begin() + offset );
            offset += parameters.d().size();

            state->_bcryptPrivateHandle = true;
        }

        status = ::BCryptImportKeyPair( state->_hAlgorithm, 
                                        NULL, 
                                        blob_type, 
                                        &state->_bcryptHandle, 
                                        blob.data(), 
                                        boost::numeric_cast<ULONG, size_t>(blob.size()),
                                        /*BCRYPT_NO_KEY_VALIDATION*/ 0 );
    }

    if ( NT_SUCCESS( status ) )
    {
        _state = state.release();
    }
    else
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }
}

RsaKeyHandle::RsaKeyHandle( PCCERT_CONTEXT context )
{
    unique_ptr<State> state( new State() );

    // Attempt to load the certificates private key, fail back to just the public key
    // TODO: What to do with the keySpec here?
    DWORD             keySpec     = 0;

    if ( !( ::CryptAcquireCertificatePrivateKey( context, 
                                                 CRYPT_ACQUIRE_ONLY_NCRYPT_KEY_FLAG,
                                                 NULL,
                                                 &state->_ncryptHandle,
                                                 &keySpec,
                                                 &state->_ncryptFreeHandle ) ) )
    {
        // Load the cert's public key into a key handle usable by CNG's BCrypt* functions
        if ( !::CryptImportPublicKeyInfoEx2( X509_ASN_ENCODING,
                                             &(context->pCertInfo->SubjectPublicKeyInfo),
                                             0,
                                             NULL,
                                             &state->_bcryptHandle ) )
        {
            throw runtime_error( "RsaOaepEncryptionTransform::RsaOaepEncryptionTransform CryptImportPublicKeyInfoEx2 failed" );
        }

        // Public key only
        state->_bcryptPrivateHandle = false;
    }

    _state = state.release();
}

RsaKeyHandle::~RsaKeyHandle()
{
    if ( NULL != _state ) delete _state;
}

RsaParameters RsaKeyHandle::exportParameters( bool includePrivate )
{
    NTSTATUS status = -1;
    ULONG    cbResult;
    ULONG    cbOutput;
    PBYTE    pbOutput;

    RsaParameters result;

    if ( _state->_bcryptHandle != NULL )
    {
        LPCWSTR blobType = ( _state->_bcryptPrivateHandle == true && includePrivate ) ? BCRYPT_RSAFULLPRIVATE_BLOB : BCRYPT_RSAPUBLIC_BLOB;

        if ( NT_SUCCESS( status = ::BCryptExportKey( _state->_bcryptHandle, NULL, blobType , NULL, 0, &cbOutput, 0 ) ) )
        {
            pbOutput = (PBYTE)::HeapAlloc( ::GetProcessHeap(), 0, cbOutput );

            if ( NULL != pbOutput )
            {
                if ( NT_SUCCESS( status = ::BCryptExportKey( _state->_bcryptHandle, NULL, blobType, pbOutput, cbOutput, &cbResult, 0 ) ) )
                {
                    BCRYPT_RSAKEY_BLOB *pBlob  = (BCRYPT_RSAKEY_BLOB *)pbOutput;
                    PBYTE               pValue = (PBYTE)pbOutput + sizeof( BCRYPT_RSAKEY_BLOB );

                    // Always extract public parameters
                    result.e( vector<byte_t>( pValue, pValue + pBlob->cbPublicExp ) );

                    pValue += pBlob->cbPublicExp;
                    result.n( vector<byte_t>( pValue, pValue + pBlob->cbModulus ) );

                    if ( pBlob->Magic == BCRYPT_RSAFULLPRIVATE_MAGIC )
                    {
                        // Copy prime1
                        pValue += pBlob->cbModulus;
                        result.p( vector<byte_t>( pValue, pValue + pBlob->cbPrime1 ) );

                        // Copy prime2
                        pValue += pBlob->cbPrime1;
                        result.q( vector<byte_t>( pValue, pValue + pBlob->cbPrime2 ) );

                        // Copy exponent1
                        pValue += pBlob->cbPrime2;
                        result.dp( vector<byte_t>( pValue, pValue + pBlob->cbPrime1 ) );

                        // Copy exponent2
                        pValue += pBlob->cbPrime1;
                        result.dq( vector<byte_t>( pValue, pValue + pBlob->cbPrime2 ) );

                        // Copy coefficient
                        pValue += pBlob->cbPrime2;
                        result.qi( vector<byte_t>( pValue, pValue + pBlob->cbPrime1 ) );

                        // Copy private exponent
                        pValue += pBlob->cbPrime1;
                        result.d( vector<byte_t>( pValue, pValue + pBlob->cbModulus ) );
                    }
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }

    if ( ! NT_SUCCESS( status ) )
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }

    return result;
}

vector<byte_t> RsaKeyHandle::decrypt( const std::vector<akv::byte_t>& ciphertext, PaddingMode paddingMode )
{
    BCRYPT_OAEP_PADDING_INFO  oaepPaddingInfo = { BCRYPT_SHA1_ALGORITHM, NULL, 0 };
    BCRYPT_PKCS1_PADDING_INFO pkcsPaddingInfo = { BCRYPT_SHA1_ALGORITHM };
    void                     *pPaddingInfo    = NULL;
    ULONG                     dwFlags         = 0;

    if ( paddingMode == PaddingMode::OAEP )
    {
        oaepPaddingInfo.pszAlgId = BCRYPT_SHA1_ALGORITHM;
        pPaddingInfo             = &oaepPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_OAEP : NCRYPT_PAD_OAEP_FLAG;
    }
    else if ( paddingMode == PaddingMode::OAEP256 )
    {
        oaepPaddingInfo.pszAlgId = BCRYPT_SHA256_ALGORITHM;
        pPaddingInfo             = &oaepPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_OAEP : NCRYPT_PAD_OAEP_FLAG;
    }
    else if ( paddingMode == PaddingMode::PKCS1_5 )
    {
        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA1_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else
    {
        throw invalid_argument( "paddingMode" );
    }

    NTSTATUS status;
    ULONG    cbResult;
    ULONG    cbOutput;
    PBYTE    pbOutput;

    vector<byte_t> result;

    if ( _state->_bcryptHandle && _state->_bcryptPrivateHandle == true )
    {
        //
        // Get the output buffer size.
        //
        if( NT_SUCCESS( status = ::BCryptDecrypt( _state->_bcryptHandle,
                                                  (PUCHAR)ciphertext.data(),
                                                  boost::numeric_cast<ULONG, size_t>(ciphertext.size()),
                                                  pPaddingInfo,
                                                  NULL, 
                                                  0,
                                                  NULL, 
                                                  0,
                                                  &cbOutput,
                                                  dwFlags ) ) )
        {
            pbOutput = (PBYTE)::HeapAlloc( ::GetProcessHeap (), 0, cbOutput );

            if ( NULL != pbOutput)
            {
                // Use the key to encrypt the plaintext buffer.
                // For block sized messages, block padding will add an extra block.
                if ( NT_SUCCESS( status = ::BCryptDecrypt( _state->_bcryptHandle, 
                                                           (PUCHAR)ciphertext.data(), 
                                                           boost::numeric_cast<ULONG, size_t>(ciphertext.size()), 
                                                           pPaddingInfo, 
                                                           NULL, 
                                                           0, 
                                                           pbOutput, 
                                                           cbOutput, 
                                                           &cbResult, 
                                                           dwFlags ) ) )
                {
                    result = vector<akv::byte_t>( pbOutput, pbOutput + cbResult );
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }
    else if ( _state->_ncryptHandle )
    {
        //
        // Get the output buffer size.
        //
        if ( NT_SUCCESS( status = ::NCryptDecrypt( _state->_ncryptHandle, 
                                                   (PUCHAR)ciphertext.data(), 
                                                   boost::numeric_cast<ULONG, size_t>(ciphertext.size()), 
                                                   pPaddingInfo, 
                                                   NULL, 
                                                   0, 
                                                   &cbOutput, 
                                                   dwFlags ) ) )
        {
            pbOutput = (PBYTE)::HeapAlloc( ::GetProcessHeap(), 0, cbOutput );

            if ( NULL != pbOutput)
            {
                // Use the key to encrypt the plaintext buffer.
                // For block sized messages, block padding will add an extra block.
                if ( NT_SUCCESS( status = ::NCryptDecrypt( _state->_ncryptHandle, 
                                                           (PUCHAR)ciphertext.data(), 
                                                           boost::numeric_cast<ULONG, size_t>(ciphertext.size()), 
                                                           pPaddingInfo, 
                                                           pbOutput, 
                                                           cbOutput, 
                                                           &cbResult, 
                                                           dwFlags ) ) )
                {
                    result = vector<akv::byte_t>( pbOutput, pbOutput + cbResult );
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }
    else
    {
        throw runtime_error( "RsaOaepEncryptionTransform::decrypt is not supported" );
    }

    if ( ! NT_SUCCESS( status ) )
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }

    return result;
}

std::vector<akv::byte_t> RsaKeyHandle::encrypt( const std::vector<akv::byte_t>& plaintext, PaddingMode paddingMode )
{
    BCRYPT_OAEP_PADDING_INFO  oaepPaddingInfo = { BCRYPT_SHA1_ALGORITHM, NULL, 0 };
    BCRYPT_PKCS1_PADDING_INFO pkcsPaddingInfo = { BCRYPT_SHA1_ALGORITHM };
    void                     *pPaddingInfo    = NULL;
    ULONG                     dwFlags         = 0;

    if ( paddingMode == PaddingMode::OAEP )
    {
        oaepPaddingInfo.pszAlgId = BCRYPT_SHA1_ALGORITHM;
        pPaddingInfo             = &oaepPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_OAEP : NCRYPT_PAD_OAEP_FLAG;
    }
    else if ( paddingMode == PaddingMode::OAEP256 )
    {
        oaepPaddingInfo.pszAlgId = BCRYPT_SHA256_ALGORITHM;
        pPaddingInfo             = &oaepPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_OAEP : NCRYPT_PAD_OAEP_FLAG;
    }
    else if ( paddingMode == PaddingMode::PKCS1_5 )
    {
        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA1_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else
    {
        throw invalid_argument( "paddingMode" );
    }

    NTSTATUS status;
    ULONG    cbResult;
    ULONG    cbOutput;
    PBYTE    pbOutput;

    std::vector<akv::byte_t> result;

    if ( _state->_bcryptHandle )
    {
        //
        // Get the output buffer size.
        //
        if ( NT_SUCCESS(status = ::BCryptEncrypt( _state->_bcryptHandle, 
                                                  (PUCHAR)plaintext.data(), 
                                                  boost::numeric_cast<ULONG, size_t>(plaintext.size()),
                                                  pPaddingInfo, 
                                                  NULL, 
                                                  0, 
                                                  NULL,
                                                  0,
                                                  &cbOutput, 
                                                  dwFlags ) ) )
        {
            pbOutput = (PBYTE)::HeapAlloc(::GetProcessHeap(), 0, cbOutput );

            if ( NULL != pbOutput)
            {
                // Use the key to encrypt the plaintext buffer. For block sized messages, block padding will add an extra block.
                if ( NT_SUCCESS(status = ::BCryptEncrypt( _state->_bcryptHandle, 
                                                          (PUCHAR)plaintext.data(), 
                                                          boost::numeric_cast<ULONG, size_t>(plaintext.size()),
                                                          pPaddingInfo,
                                                          NULL,
                                                          0, 
                                                          pbOutput,
                                                          cbOutput, 
                                                          &cbResult, 
                                                          dwFlags ) ) )
                {
                    result = vector<akv::byte_t>( pbOutput, pbOutput + cbResult );
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }
    else if ( _state->_ncryptHandle )
    {
        //
        // Get the output buffer size.
        //
        if ( NT_SUCCESS(status = ::NCryptEncrypt( _state->_ncryptHandle,
                                                  (PUCHAR)plaintext.data(),
                                                  boost::numeric_cast<ULONG, size_t>(plaintext.size()),
                                                  pPaddingInfo,
                                                  NULL,
                                                  0,
                                                  &cbOutput,
                                                  dwFlags ) ) )
        {
            pbOutput = (PBYTE)::HeapAlloc( ::GetProcessHeap (), 0, cbOutput );

            if ( NULL != pbOutput)
            {
                // Use the key to encrypt the plaintext buffer.
                // For block sized messages, block padding will add an extra block.
                if ( NT_SUCCESS(status = ::NCryptEncrypt( _state->_ncryptHandle,
                                                          (PUCHAR)plaintext.data(),
                                                          boost::numeric_cast<ULONG, size_t>(plaintext.size()),
                                                          pPaddingInfo,
                                                          pbOutput, 
                                                          cbOutput, 
                                                          &cbResult,
                                                          dwFlags ) ) )
                {
                    result = vector<akv::byte_t>( pbOutput, pbOutput + cbResult );
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }
    else
    {
        throw runtime_error( "RsaKey::encrypt is not supported" );
    }

    if ( ! NT_SUCCESS( status ) )
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }

    return result;
}

std::vector<akv::byte_t> RsaKeyHandle::sign( const std::vector<akv::byte_t>& digest, SignatureMode signatureMode )
{
    BCRYPT_PKCS1_PADDING_INFO pkcsPaddingInfo = { BCRYPT_SHA256_ALGORITHM };
    void                     *pPaddingInfo = NULL;
    ULONG                     dwFlags = 0;

    if ( signatureMode == SignatureMode::RS256 )
    {
        if ( digest.size() != 32 ) throw invalid_argument( "digest" );

        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA256_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else if ( signatureMode == SignatureMode::RS384 )
    {
        if ( digest.size() != 48 ) throw invalid_argument( "digest" );

        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA384_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else if ( signatureMode == SignatureMode::RS512 )
    {
        if ( digest.size() != 64 ) throw invalid_argument( "digest" );

        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA512_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else
    {
        throw invalid_argument( "signatureMode" );
    }

    NTSTATUS status;
    ULONG    cbResult;
    ULONG    cbOutput;
    PBYTE    pbOutput;

    std::vector<akv::byte_t> result;

    if ( _state->_bcryptHandle )
    {
        //
        // Get the output buffer size.
        //
        if ( NT_SUCCESS( status = ::BCryptSignHash( _state->_bcryptHandle,
                                                    pPaddingInfo,
                                                    (PUCHAR)digest.data(),
                                                    boost::numeric_cast<ULONG, size_t>( digest.size() ),
                                                    NULL,
                                                    0,
                                                    &cbOutput,
                                                    dwFlags ) ) )
        {
            pbOutput = ( PBYTE )::HeapAlloc( ::GetProcessHeap(), 0, cbOutput );

            if ( NULL != pbOutput )
            {
                // Use the key to sign the hash.
                if ( NT_SUCCESS( status = ::BCryptSignHash( _state->_bcryptHandle,
                                                            pPaddingInfo,
                                                            (PUCHAR)digest.data(),
                                                            boost::numeric_cast<ULONG, size_t>( digest.size() ),
                                                            pbOutput,
                                                            cbOutput,
                                                            &cbResult,
                                                            dwFlags ) ) )
                {
                    result = vector<akv::byte_t>( pbOutput, pbOutput + cbResult );
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }
    else if ( _state->_ncryptHandle )
    {
        //
        // Get the output buffer size.
        //
        if ( NT_SUCCESS( status = ::NCryptSignHash( _state->_ncryptHandle,
                                                    pPaddingInfo,
                                                    (PUCHAR)digest.data(),
                                                    boost::numeric_cast<ULONG, size_t>( digest.size() ),
                                                    NULL,
                                                    0,
                                                    &cbOutput,
                                                    dwFlags ) ) )
        {
            pbOutput = ( PBYTE )::HeapAlloc( ::GetProcessHeap(), 0, cbOutput );

            if ( NULL != pbOutput )
            {
                // Use the key to encrypt the plaintext buffer.
                // For block sized messages, block padding will add an extra block.
                if ( NT_SUCCESS( status = ::NCryptSignHash( _state->_ncryptHandle,
                                                            pPaddingInfo,
                                                            (PUCHAR)digest.data(),
                                                            boost::numeric_cast<ULONG, size_t>( digest.size() ),
                                                            pbOutput,
                                                            cbOutput,
                                                            &cbResult,
                                                            dwFlags ) ) )
                {
                    result = vector<akv::byte_t>( pbOutput, pbOutput + cbResult );
                }

                ::SecureZeroMemory( pbOutput, cbOutput );
                ::HeapFree( ::GetProcessHeap(), 0, pbOutput );
            }
        }
    }
    else
    {
        throw runtime_error( "RsaKeyHandle::sign is not supported" );
    }

    if ( ! NT_SUCCESS( status ) )
    {
        auto error = ::GetLastError();
        throw std::system_error( error, std::system_category() );
    }

    return result;
}

bool RsaKeyHandle::verify( const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& signature, SignatureMode signatureMode )
{
    BCRYPT_PKCS1_PADDING_INFO pkcsPaddingInfo = { BCRYPT_SHA256_ALGORITHM };
    void                     *pPaddingInfo = NULL;
    ULONG                     dwFlags = 0;

    if ( signatureMode == SignatureMode::RS256 )
    {
        if ( digest.size() != 32 ) throw invalid_argument( "digest" );

        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA256_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else if ( signatureMode == SignatureMode::RS384 )
    {
        if ( digest.size() != 48 ) throw invalid_argument( "digest" );

        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA384_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else if ( signatureMode == SignatureMode::RS512 )
    {
        if ( digest.size() != 64 ) throw invalid_argument( "digest" );

        pkcsPaddingInfo.pszAlgId = BCRYPT_SHA512_ALGORITHM;
        pPaddingInfo             = &pkcsPaddingInfo;
        dwFlags                  = _state->_bcryptHandle ? BCRYPT_PAD_PKCS1 : NCRYPT_PAD_PKCS1_FLAG;
    }
    else
    {
        throw invalid_argument( "signatureMode" );
    }

    NTSTATUS status;

    std::vector<akv::byte_t> result;

    if ( _state->_bcryptHandle )
    {
        status = ::BCryptVerifySignature( _state->_bcryptHandle,
                                          pPaddingInfo,
                                          (PUCHAR)digest.data(),
                                          boost::numeric_cast<ULONG, size_t>( digest.size() ),
                                          (PUCHAR)signature.data(),
                                          boost::numeric_cast<ULONG, size_t>( signature.size() ),
                                          dwFlags );

        return NT_SUCCESS( status ) ? true : false;
    }
    else if ( _state->_ncryptHandle )
    {
        status = ::NCryptVerifySignature( _state->_ncryptHandle,
                                          pPaddingInfo,
                                          (PUCHAR)digest.data(),
                                          boost::numeric_cast<ULONG, size_t>( digest.size() ),
                                          (PUCHAR)signature.data(),
                                          boost::numeric_cast<ULONG, size_t>( signature.size() ),
                                          dwFlags );

        return NT_SUCCESS( status ) ? true : false;
    }
    else
    {
        throw runtime_error( "RsaKeyHandle::verify is not supported" );
    }
}

} }
