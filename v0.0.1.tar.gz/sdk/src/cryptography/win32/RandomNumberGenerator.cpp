/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/RandomNumberGenerator.h"

#include <boost/numeric/conversion/cast.hpp>


using namespace std;

namespace akv { namespace cryptography {

void RandomNumberGenerator::get_bytes( vector<akv::byte_t>& target )
{
    auto status = ::BCryptGenRandom( NULL, target.data(), boost::numeric_cast<ULONG, size_t>(target.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG );

    if ( status != 0 )
    {
        throw std::system_error( ::GetLastError(), std::system_category() );
    }
}

} }
