/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/IncrementalHash.h"

#include <boost/numeric/conversion/cast.hpp>

using namespace std;

namespace akv { namespace cryptography {

struct IncrementalHash::State
{
    State() { };
    ~State()
    {
        if ( _pbHash )       ::HeapFree(GetProcessHeap(), 0, _pbHash);
        if ( _pbHashObject ) ::HeapFree(GetProcessHeap(), 0, _pbHashObject);
        if ( _hHash )        ::BCryptDestroyHash(_hHash);
        if ( _hAlgorithm )   ::BCryptCloseAlgorithmProvider(_hAlgorithm,0);
    }

    Type               _type;

    BCRYPT_ALG_HANDLE  _hAlgorithm;
    BCRYPT_HASH_HANDLE _hHash;
    PBYTE              _pbHashObject;
    DWORD              _cbHash;
    PBYTE              _pbHash;
};

IncrementalHash::IncrementalHash( Type hashName )
{
    unique_ptr<State> state( new State() );

    state->_type = hashName;

    LPCWSTR bcryptHashName;

    switch ( hashName )
    {
        case Type::SHA256:
            bcryptHashName = BCRYPT_SHA256_ALGORITHM;
            break;

        case Type::SHA384:
            bcryptHashName = BCRYPT_SHA384_ALGORITHM;
            break;

        case Type::SHA512:
            bcryptHashName = BCRYPT_SHA512_ALGORITHM;
            break;

        default:
            throw invalid_argument( "hashName" );
    }

    NTSTATUS           status;
    DWORD              cbData;
    DWORD              cbHashObject;

    if ( NT_SUCCESS( status = ::BCryptOpenAlgorithmProvider( &state->_hAlgorithm,
                                                             bcryptHashName,
                                                             NULL,
                                                             0 ) ) )
    {
        //calculate the size of the buffer to hold the hash object
        if ( NT_SUCCESS( status = ::BCryptGetProperty( state->_hAlgorithm,
                                                       BCRYPT_OBJECT_LENGTH,
                                                       (PBYTE)&cbHashObject,
                                                       sizeof( DWORD ),
                                                       &cbData,
                                                       0 ) ) )
        {
            //allocate the hash object on the heap
            state->_pbHashObject = ( PBYTE )::HeapAlloc( ::GetProcessHeap(), 0, cbHashObject );

            if ( NULL != state->_pbHashObject )
            {
                //calculate the length of the hash
                if ( NT_SUCCESS( status = ::BCryptGetProperty( state->_hAlgorithm,
                                                               BCRYPT_HASH_LENGTH,
                                                               (PBYTE)&state->_cbHash,
                                                               sizeof( DWORD ),
                                                               &cbData,
                                                               0 ) ) )
                {
                    //allocate the hash buffer on the heap
                    state->_pbHash = ( PBYTE )::HeapAlloc( ::GetProcessHeap(), 0, state->_cbHash );

                    if ( NULL != state->_pbHash )
                    {
                        //create a hash
                        status = ::BCryptCreateHash( state->_hAlgorithm,
                                                     &state->_hHash,
                                                     state->_pbHashObject,
                                                     cbHashObject,
                                                     NULL,
                                                     0,
                                                     0 );
                    }
                }
            }
        }
    }

    if ( NT_SUCCESS( status ) )
    {
        _state = state.release();
    }
    else
    {
        throw runtime_error( "IncrementalHash::IncrementalHash" );
    }
}

IncrementalHash::~IncrementalHash()
{
    if ( _state != NULL ) delete _state;
}

size_t IncrementalHash::size() const
{
    switch ( _state->_type )
    {
        case Type::SHA256:
            return 32;

        case Type::SHA384:
            return 48;
            
        case Type::SHA512:
            return 64;
            
        default:
            throw runtime_error( "unknown hash type" );
    }
}

void IncrementalHash::update( const std::vector<akv::byte_t>& data )
{
    NTSTATUS status;

    //hash some data
    if( !NT_SUCCESS(status = ::BCryptHashData( _state->_hHash, (PBYTE)data.data(), boost::numeric_cast<ULONG, size_t>(data.size()), 0 ) ) )
    {
        throw runtime_error( "IncrementalHash::update" );
    }
}

vector<akv::byte_t> IncrementalHash::updateFinal( const std::vector<akv::byte_t>& data )
{
    NTSTATUS status;

    //hash some data
    if( !NT_SUCCESS(status = ::BCryptHashData( _state->_hHash, (PBYTE)data.data(), boost::numeric_cast<ULONG, size_t>(data.size()), 0 ) ) )
    {
        throw runtime_error( "IncrementalHash::updateFinal" );
    }

    //close the hash
    if ( !NT_SUCCESS(status = ::BCryptFinishHash( _state->_hHash, _state->_pbHash, _state->_cbHash, 0 ) ) )
    {
    }

    return vector<akv::byte_t>( _state->_pbHash, _state->_pbHash + _state->_cbHash );
}

} }
