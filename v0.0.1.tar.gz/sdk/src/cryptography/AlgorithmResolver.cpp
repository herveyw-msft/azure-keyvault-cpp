/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/Algorithm.h"

#include "akv/cryptography/IEncryptionTransform.h"
#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/AsymmetricEncryptionAlgorithm.h"
#include "akv/cryptography/SymmetricEncryptionAlgorithm.h"

#include "akv/cryptography/IKeyWrapTransform.h"
#include "akv/cryptography/KeyWrapAlgorithm.h"
#include "akv/cryptography/AesKeyWrapAlgorithm.h"

#include "akv/cryptography/ISignatureTransform.h"
#include "akv/cryptography/SignatureAlgorithm.h"
#include "akv/cryptography/AsymmetricSignatureAlgorithm.h"
#include "akv/cryptography/RsaSignatureAlgorithm.h"

#include "akv/cryptography/AesCbcEncryptionAlgorithm.h"
#include "akv/cryptography/AesCbcHmacSha.h"
#include "akv/cryptography/RsaEncryptionAlgorithm.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct AlgorithmResolver::_Impl
{
    std::map<const akv::string_t, std::shared_ptr<Algorithm>> _map;
};

static AlgorithmResolver _defaultResolver;
static bool              _defaultResolverInitialized = false;

AlgorithmResolver & AlgorithmResolver::DefaultResolver()
{
    if ( !_defaultResolverInitialized )
    {
        _defaultResolver.addAlgorithm( Aes128CbcHmacSha256::AlgorithmName(), shared_ptr<Algorithm>( new Aes128CbcHmacSha256() ) );
        _defaultResolver.addAlgorithm( Aes192CbcHmacSha384::AlgorithmName(), shared_ptr<Algorithm>( new Aes192CbcHmacSha384() ) );
        _defaultResolver.addAlgorithm( Aes256CbcHmacSha512::AlgorithmName(), shared_ptr<Algorithm>( new Aes256CbcHmacSha512() ) );

        _defaultResolver.addAlgorithm( Aes128::AlgorithmName(), shared_ptr<Algorithm>( new Aes128() ) );
        _defaultResolver.addAlgorithm( Aes192::AlgorithmName(), shared_ptr<Algorithm>( new Aes192() ) );
        _defaultResolver.addAlgorithm( Aes256::AlgorithmName(), shared_ptr<Algorithm>( new Aes256() ) );

        _defaultResolver.addAlgorithm( AesKw128::AlgorithmName(), shared_ptr<Algorithm>( new AesKw128() ) );
        _defaultResolver.addAlgorithm( AesKw192::AlgorithmName(), shared_ptr<Algorithm>( new AesKw192() ) );
        _defaultResolver.addAlgorithm( AesKw256::AlgorithmName(), shared_ptr<Algorithm>( new AesKw256() ) );

        _defaultResolver.addAlgorithm( RsaOaep::AlgorithmName(), shared_ptr<Algorithm>( new RsaOaep() ) );
        _defaultResolver.addAlgorithm( RsaOaep256::AlgorithmName(), shared_ptr<Algorithm>( new RsaOaep256() ) );

        _defaultResolver.addAlgorithm( Rs256SignatureAlgorithm::AlgorithmName(), shared_ptr<Algorithm>( new Rs256SignatureAlgorithm() ) );
        _defaultResolver.addAlgorithm( Rs384SignatureAlgorithm::AlgorithmName(), shared_ptr<Algorithm>( new Rs384SignatureAlgorithm() ) );
        _defaultResolver.addAlgorithm( Rs512SignatureAlgorithm::AlgorithmName(), shared_ptr<Algorithm>( new Rs512SignatureAlgorithm() ) );

        _defaultResolverInitialized = true;
    }

    return _defaultResolver;
}

AlgorithmResolver::AlgorithmResolver()
{
    _impl = new _Impl();
}


AlgorithmResolver::~AlgorithmResolver()
{
    delete _impl;
}

void AlgorithmResolver::addAlgorithm( const akv::string_t& algorithmName, std::shared_ptr<Algorithm> algorithm )
{
    _impl->_map.insert( pair<const akv::string_t, std::shared_ptr<Algorithm>>(algorithmName, algorithm ) );
}

shared_ptr<Algorithm> AlgorithmResolver::getAlgorithm( const akv::string_t& algorithmName ) const
{
    try
    {
        return _impl->_map.at( algorithmName );
    }
    catch ( ... )
    {
        return shared_ptr<Algorithm>();
    }
}

void AlgorithmResolver::removeAlgorithm( const akv::string_t& algorithmName )
{
    _impl->_map.erase( algorithmName );
}

} }
