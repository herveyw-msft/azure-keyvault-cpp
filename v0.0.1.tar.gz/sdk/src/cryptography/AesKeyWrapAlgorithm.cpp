/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/KeyWrapAlgorithm.h"
#include "akv/cryptography/AesKeyWrapAlgorithm.h"
#include "akv/cryptography/IKeyWrapTransform.h"

#include "cryptography/AesKeyWrapTransform.h"

namespace akv { namespace cryptography {

// RFC3394 default 64bit IV for AES Key Wrap
static const std::vector<akv::byte_t> _DefaultIv { 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6 };

const std::vector<akv::byte_t>& AesKw::DefaultIv()
{
    return _DefaultIv;
}

AesKw::AesKw( const akv::string_t& name ) : KeyWrapAlgorithm( name )
{
}

AesKw::~AesKw()
{
}

std::shared_ptr<IKeyWrapTransform> AesKw::createTransformCore( const std::vector<akv::byte_t>& key,
                                                               const std::vector<akv::byte_t>& iv ) const
{
    return std::make_shared<AesKeyWrapTransform>( key, iv );
}

//
// AAESKW128
//
const akv::string_t& AesKw128::AlgorithmName()
{
    return AlgorithmNames::Aes128Kw();
}

AesKw128::AesKw128() : AesKw( AlgorithmNames::Aes128Kw())
{
}

AesKw128::~AesKw128()
{
}

std::shared_ptr<IKeyWrapTransform> AesKw128::createTransform( const std::vector<akv::byte_t>& key,
                                                              const std::vector<akv::byte_t>& iv ) const
{
    // TODO: Leaves a copy of the key on the stack
    return createTransformCore( take( key, 128 >> 3 ), iv );
}

//
// AAESKW192
//
const akv::string_t& AesKw192::AlgorithmName()
{
    return AlgorithmNames::Aes192Kw();
}

AesKw192::AesKw192() : AesKw( AlgorithmNames::Aes192Kw())
{
}

AesKw192::~AesKw192()
{
}

std::shared_ptr<IKeyWrapTransform> AesKw192::createTransform( const std::vector<akv::byte_t>& key,
                                                              const std::vector<akv::byte_t>& iv ) const
{
    // TODO: Leaves a copy of the key on the stack
    return createTransformCore( take( key, 192 >> 3 ), iv );
}

//
// AAESKW256
//
const akv::string_t& AesKw256::AlgorithmName()
{
    return AlgorithmNames::Aes256Kw();
}

AesKw256::AesKw256() : AesKw( AlgorithmNames::Aes256Kw())
{
}

AesKw256::~AesKw256()
{
}

std::shared_ptr<IKeyWrapTransform> AesKw256::createTransform( const std::vector<akv::byte_t>& key,
                                                              const std::vector<akv::byte_t>& iv ) const
{
    // TODO: Leaves a copy of the key on the stack
    return createTransformCore( take( key, 256 >> 3 ), iv );
}

} }
