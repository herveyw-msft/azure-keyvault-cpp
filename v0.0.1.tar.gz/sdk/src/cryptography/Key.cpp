/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/IEncryptionTransform.h"
#include "akv/cryptography/IKeyWrapTransform.h"
#include "akv/cryptography/ISignatureTransform.h"

#include "akv/cryptography/Key.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct Key::State
{
    akv::string_t _kid;
};

Key::Key( const akv::string_t& kid )
{
    if ( kid.empty() )
        throw invalid_argument( "kid" );

    unique_ptr<State> state( new State() );

    state->_kid    = kid;

    _state = state.release();
}

Key::Key( Key&& other )
{
    _state = other._state;
    other._state = NULL;
}

Key& Key::operator = ( Key&& other )
{
    if ( _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

Key::~Key()
{
    if ( NULL != _state ) delete _state;
}

akv::string_t Key::kid() const
{
    return _state->_kid;
}

pplx::task<IKey::DecryptResult> Key::decrypt_transform( const std::shared_ptr<IEncryptionTransform> transform,
                                                        const std::vector<akv::byte_t>&             cipher_text,
                                                        const std::vector<akv::byte_t>&             authentication_tag,
                                                        const pplx::cancellation_token&             token ) const
{
    if ( transform == nullptr )
        throw invalid_argument( "transform" );

    if ( cipher_text.empty() )
        throw invalid_argument( "cipher_text" );

    auto kid = _state->_kid;

    // Its now safe to leave the local variables behind...
    return pplx::create_task( [transform, kid, cipher_text, authentication_tag]() -> DecryptResult
    {
        auto result = transform->decrypt( cipher_text, authentication_tag );

        return DecryptResult( kid, result.plaintext );
    }, token );
}

pplx::task<IKey::EncryptResult> Key::encrypt_transform( const std::shared_ptr<IEncryptionTransform> transform,
                                                        const std::vector<akv::byte_t>&             plain_text,
                                                        const pplx::cancellation_token&             token ) const
{
    if ( transform == nullptr )
        throw invalid_argument( "transform" );

    if ( plain_text.empty() )
        throw invalid_argument( "plain_text" );

    auto kid = _state->_kid;

    // Its now safe to leave the local variables behind...
    return pplx::create_task( [transform, kid, plain_text]() -> EncryptResult
    {
        auto result = transform->encrypt( plain_text );

        return EncryptResult( kid, result.ciphertext, result.tag );
    }, token );
}

pplx::task<IKey::UnwrapResult> Key::unwrap_transform( const std::shared_ptr<IKeyWrapTransform> transform,
                                                      const std::vector<akv::byte_t>&          cipher_text,
                                                      const pplx::cancellation_token&          token ) const
{
    if ( transform == nullptr )
        throw invalid_argument( "transform" );

    if ( cipher_text.empty() )
        throw invalid_argument( "cipher_text" );

    auto kid = _state->_kid;

    // Its now safe to leave the local variables behind...
    return pplx::create_task( [transform, kid, cipher_text]() -> UnwrapResult
    {
        auto result = transform->unwrap( cipher_text );

        return UnwrapResult( kid, result.value );
    }, token );
}

pplx::task<IKey::WrapResult> Key::wrap_transform( const std::shared_ptr<IKeyWrapTransform> transform,
                                                  const std::vector<akv::byte_t>&          plain_text,
                                                  const pplx::cancellation_token&          token ) const
{
    if ( transform == nullptr )
        throw invalid_argument( "transform" );

    if ( plain_text.empty() )
        throw invalid_argument( "plain_text" );

    auto kid = _state->_kid;

    // Its now safe to leave the local variables behind...
    return pplx::create_task( [transform, kid, plain_text]() -> WrapResult
    {
        auto result = transform->wrap( plain_text );

        return WrapResult( kid, result.value );
    }, token );
}

pplx::task<IKey::SignResult> Key::sign_transform( const std::shared_ptr<ISignatureTransform> transform,
                                                  const std::vector<akv::byte_t>&            digest,
                                                  const pplx::cancellation_token&            token ) const
{
    if ( transform == nullptr )
        throw invalid_argument( "transform" );

    if ( digest.empty() )
        throw invalid_argument( "digest" );

    auto kid = _state->_kid;

    // Its now safe to leave the local variables behind...
    return pplx::create_task( [transform, kid, digest]() -> SignResult
    {
        auto result = transform->signHash( digest );

        return SignResult( kid, result.value );
    }, token );
}

pplx::task<IKey::VerifyResult> Key::verify_transform( const std::shared_ptr<ISignatureTransform> transform,
                                                      const std::vector<akv::byte_t>&            digest,
                                                      const std::vector<akv::byte_t>&            signature,
                                                      const pplx::cancellation_token&            token ) const
{
    if ( transform == nullptr )
        throw invalid_argument( "transform" );

    if ( digest.empty() )
        throw invalid_argument( "digest" );

    if ( signature.empty() )
        throw invalid_argument( "signature" );

    auto kid = _state->_kid;

    // Its now safe to leave the local variables behind...
    return pplx::create_task( [transform, kid, digest, signature]() -> VerifyResult
    {
        auto result = transform->verifyHash( digest, signature );

        return VerifyResult( kid, result.value );
    }, token );
}

} }
