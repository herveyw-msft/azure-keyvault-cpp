/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/SignatureAlgorithm.h"
#include "akv/cryptography/AsymmetricSignatureAlgorithm.h"

namespace akv { namespace cryptography {

AsymmetricSignatureAlgorithm::AsymmetricSignatureAlgorithm( const akv::string_t & name ) : SignatureAlgorithm( name )
{
}

AsymmetricSignatureAlgorithm::~AsymmetricSignatureAlgorithm()
{
}

} }
