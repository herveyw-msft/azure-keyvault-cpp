/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/akv_core.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/AlgorithmResolver.h"

#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/AsymmetricEncryptionAlgorithm.h"
#include "akv/cryptography/RsaEncryptionAlgorithm.h"
#include "akv/cryptography/SignatureAlgorithm.h"
#include "akv/cryptography/AsymmetricSignatureAlgorithm.h"
#include "akv/cryptography/RsaSignatureAlgorithm.h"

#include "akv/cryptography/IEncryptionTransform.h"
#include "akv/cryptography/ISignatureTransform.h"

#include "akv/cryptography/Key.h"

#include "akv/cryptography/RsaParameters.h"
#include "akv/cryptography/RsaKey.h"

#include "cryptography/RsaKeyHandle.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

static const std::vector<akv::byte_t> tagNone;

struct RsaKey::State
{
    State() { }
    State( const State& )              = default;
    State& operator = ( const State& ) = default;
    ~State()                           = default;

    shared_ptr<RsaKeyHandle> _handle;
};

RsaKey::RsaKey( const akv::string_t& kid ) : Key( kid )
{
    unique_ptr<State> state( new State() );

    state->_handle = make_shared<RsaKeyHandle>();

    _state = state.release();
}

RsaKey::RsaKey( const akv::string_t& kid, const RsaParameters& parameters ) : Key( kid )
{
    unique_ptr<State> state( new State() );

    state->_handle     = make_shared<RsaKeyHandle>( parameters );

    _state = state.release();
}

RsaKey::RsaKey( RsaKey&& other ) : Key( std::forward<Key>( other ) )
{
    _state = other._state;
    other._state = NULL;
}

RsaKey& RsaKey::operator = ( RsaKey&& other )
{
    Key::operator = ( std::forward<Key>( other ) );

    if ( _state ) delete _state;

    _state = other._state;
    other._state = NULL;

    return *this;
}

RsaKey::~RsaKey()
{
    if ( NULL != _state ) delete _state;
}

RsaParameters RsaKey::exportParameters( bool includePrivate )
{
    return _state->_handle->exportParameters( includePrivate );
}

akv::string_t RsaKey::defaultEncryptionAlgorithm() const
{
    return AlgorithmNames::RsaOaep();
}

akv::string_t RsaKey::defaultKeyWrapAlgorithm() const
{
    return AlgorithmNames::RsaOaep();
}

akv::string_t RsaKey::defaultSignatureAlgorithm() const
{
    return AlgorithmNames::Rs256();
}

pplx::task<IKey::DecryptResult> RsaKey::decrypt( const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& cipher_text,
                                                 const std::vector<akv::byte_t>& iv,
                                                 const std::vector<akv::byte_t>& authentication_data,
                                                 const std::vector<akv::byte_t>& authentication_tag,
                                                 const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return decrypt_transform( transform, cipher_text, authentication_tag, token );
}

pplx::task<IKey::EncryptResult> RsaKey::encrypt( const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& plain_text,
                                                 const std::vector<akv::byte_t>& iv,
                                                 const std::vector<akv::byte_t>& authentication_data,
                                                 const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return encrypt_transform( transform, plain_text, token );
}

pplx::task<IKey::WrapResult> RsaKey::wrap( const akv::string_t&            algorithm_name,
                                           const std::vector<akv::byte_t>& plain_text,
                                           const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    // RSA uses Encrypt and so the result has to be transformed
    return encrypt_transform( transform, plain_text, token ).then( []( EncryptResult result ) -> WrapResult
    {
        return WrapResult( result.kid, result.value );
    }, token );
}

pplx::task<IKey::UnwrapResult> RsaKey::unwrap( const akv::string_t&            algorithm_name,
                                               const std::vector<akv::byte_t>& cipher_text,
                                               const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaEncryptionAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    // RSA uses Decrypt and so the result has to be transformed
    return decrypt_transform( transform, cipher_text, tagNone, token ).then( []( DecryptResult result ) -> UnwrapResult
    {
        return UnwrapResult( result.kid, result.value );
    }, token );
}

/// <summary>
/// Signs the specified digest.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="token">Cancellation token</param>
/// <returns>The signature value</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::SignResult> RsaKey::signHash( const akv::string_t&             algorithm_name,
                                               const std::vector<akv::byte_t>&  digest,
                                               const pplx::cancellation_token&  token ) const
{
    auto algorithm = get_algorithm<RsaSignatureAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return sign_transform( transform, digest, token );
}

/// <summary>
/// Verifies the specified digest and signature.
/// </summary>
/// <param name="algorithm">The signature algorithm to use</param>
/// <param name="digest">The digest to sign</param>
/// <param name="signature">The signature to verify</param>
/// <param name="token">Cancellation token</param>
/// <returns>True if the signature verifies</returns>
/// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
pplx::task<IKey::VerifyResult> RsaKey::verifyHash( const akv::string_t&            algorithm_name,
                                                   const std::vector<akv::byte_t>& digest,
                                                   const std::vector<akv::byte_t>& signature,
                                                   const pplx::cancellation_token& token ) const
{
    auto algorithm = get_algorithm<RsaSignatureAlgorithm>( algorithm_name );
    auto transform = algorithm->createTransform( _state->_handle );

    return verify_transform( transform, digest, signature, token );
}

} }
