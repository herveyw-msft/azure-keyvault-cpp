/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "akv/cryptography/AlgorithmNames.h"
#include "akv/cryptography/Algorithm.h"
#include "akv/cryptography/EncryptionAlgorithm.h"
#include "akv/cryptography/AsymmetricEncryptionAlgorithm.h"
#include "akv/cryptography/RsaEncryptionAlgorithm.h"

#include "akv/cryptography/IEncryptionTransform.h"

#include "cryptography/RsaEncryptionTransform.h"

namespace akv { namespace cryptography {

// Generic RSA Encrytion (abstract)
RsaEncryptionAlgorithm::RsaEncryptionAlgorithm( const akv::string_t & name ) : AsymmetricEncryptionAlgorithm( name )
{
}

RsaEncryptionAlgorithm::~RsaEncryptionAlgorithm()
{
}

template<typename T>
std::shared_ptr<IEncryptionTransform> RsaEncryptionAlgorithm::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<T>( parameters );
}

template<typename T>
std::shared_ptr<IEncryptionTransform> RsaEncryptionAlgorithm::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<T>( keyHandle );
}

// RSAES-PKCS1-v1_5
const string_t& Rsa15::AlgorithmName()
{
    return AlgorithmNames::Rsa15();
}

Rsa15::Rsa15() : RsaEncryptionAlgorithm( AlgorithmNames::Rsa15())
{
}

Rsa15::~Rsa15()
{
}

std::shared_ptr<IEncryptionTransform> Rsa15::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<Rsa15EncryptionTransform>( parameters );
}

std::shared_ptr<IEncryptionTransform> Rsa15::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<Rsa15EncryptionTransform>( keyHandle );
}

// RSAES OAEP using default parameters
const string_t& RsaOaep::AlgorithmName()
{
    return AlgorithmNames::RsaOaep();
}

RsaOaep::RsaOaep() : RsaEncryptionAlgorithm( AlgorithmNames::RsaOaep())
{
}

RsaOaep::~RsaOaep()
{
}

std::shared_ptr<IEncryptionTransform> RsaOaep::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<RsaOaepEncryptionTransform>( parameters );
}

std::shared_ptr<IEncryptionTransform> RsaOaep::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<RsaOaepEncryptionTransform>( keyHandle );
}

// RSAES OAEP using SHA-256 and MGF1 with SHA-256
const string_t& RsaOaep256::AlgorithmName()
{
    return AlgorithmNames::RsaOaep256();
}

RsaOaep256::RsaOaep256() : RsaEncryptionAlgorithm( AlgorithmNames::RsaOaep256())
{
}

RsaOaep256::~RsaOaep256()
{
}

std::shared_ptr<IEncryptionTransform> RsaOaep256::createTransform( const RsaParameters& parameters ) const
{
    return std::make_shared<RsaOaep256EncryptionTransform>( parameters );
}

std::shared_ptr<IEncryptionTransform> RsaOaep256::createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const
{
    return std::make_shared<RsaOaep256EncryptionTransform>( keyHandle );
}

} }
