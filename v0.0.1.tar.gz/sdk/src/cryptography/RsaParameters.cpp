/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#include "precomp.h"

#include "common/vector.h"

#include "akv/cryptography/RsaParameters.h"

using namespace akv;
using namespace std;

namespace akv { namespace cryptography {

struct RsaParameters::State
{
    State() { }
    State( const State& )              = default; // copy
    State& operator = ( const State& ) = default; // copy assign

#if _MSC_VER && _MSC_VER >= 1900
	State( State&& )              = default; // move
	State& operator = ( State&& ) = default; // move assign
#endif
    
    bool operator == ( const State& other )
    {
        if ( _n == other._n && _e == other._e )
        {
            return ( _d == other._d && _p == other._p && _q == other._q && _dp == other._dp && _dq == other._dq && _qi == other._qi );
        }

        return false;
    }

    ~State()
    {
        SecureZeroMemory(_n),
        SecureZeroMemory(_e),
        SecureZeroMemory(_d),
        SecureZeroMemory(_p),
        SecureZeroMemory(_q),
        SecureZeroMemory(_dp),
        SecureZeroMemory(_dq),
        SecureZeroMemory(_qi);
    }

    // RSA public parameters
    std::vector<akv::byte_t> _n;
    std::vector<akv::byte_t> _e;

    // RSA private parameters
    std::vector<akv::byte_t> _d;
    std::vector<akv::byte_t> _p;
    std::vector<akv::byte_t> _q;
    std::vector<akv::byte_t> _dp;
    std::vector<akv::byte_t> _dq;
    std::vector<akv::byte_t> _qi;
};

RsaParameters::RsaParameters()
{
    _state = new State();
}

RsaParameters::RsaParameters( const RsaParameters& other )
{
    _state = new State( *other._state );
}

RsaParameters::RsaParameters( RsaParameters&& other )
{
    _state = other._state;
    other._state = NULL;
}

RsaParameters& RsaParameters::operator = ( const RsaParameters& other )
{
    _state->operator = ( *other._state );

    return *this;
}

RsaParameters& RsaParameters::operator = ( RsaParameters&& other )
{
    if ( _state != NULL ) delete _state;
    
    _state = other._state;
    other._state = NULL;

    return *this;
}

bool RsaParameters::operator == ( const RsaParameters& other )
{
    // This should never be true, but here just in case
    if ( _state == other._state ) return true;

    return ( *_state == *other._state );
}

RsaParameters::~RsaParameters()
{
    if ( _state != NULL ) delete _state;
}

/*
result.Modulus = RemoveLeadingZeros(N);
result.Exponent = ForceLength("E", E, 4);

if (includePrivateParameters)
{
var bitlen = result.Modulus.Length * 8;

result.D = ForceLength("D", D, bitlen / 8);
result.DP = ForceLength("DP", DP, bitlen / 16);
result.DQ = ForceLength("DQ", DQ, bitlen / 16);
result.InverseQ = ForceLength("IQ", QI, bitlen / 16);
result.P = ForceLength("P", P, bitlen / 16);
result.Q = ForceLength("Q", Q, bitlen / 16);
};*/

const std::vector<akv::byte_t>& RsaParameters::n() const
{
    return _state->_n;
}

void RsaParameters::n( const std::vector<akv::byte_t>& value )
{
    _state->_n = value;
}

const std::vector<akv::byte_t>& RsaParameters::e() const
{
    return _state->_e;
}

void RsaParameters::e( const std::vector<akv::byte_t>& value )
{
    _state->_e = value;
}

// RSA private parameters
bool RsaParameters::hasPrivateParameters() const
{
    return _state->_d.size() &&
           _state->_p.size() &&
           _state->_q.size() &&
           _state->_dp.size() &&
           _state->_dq.size() &&
           _state->_qi.size();
}

const std::vector<akv::byte_t>& RsaParameters::d() const
{
    return _state->_d;
}

void RsaParameters::d( const std::vector<akv::byte_t>& value )
{
    _state->_d = value;
}

const std::vector<akv::byte_t>& RsaParameters::p() const
{
    return _state->_p;
}

void RsaParameters::p( const std::vector<akv::byte_t>& value )
{
    _state->_p = value;
}

const std::vector<akv::byte_t>& RsaParameters::q() const
{
    return _state->_q;
}

void RsaParameters::q( const std::vector<akv::byte_t>& value )
{
    _state->_q = value;
}

const std::vector<akv::byte_t>& RsaParameters::dp() const
{
    return _state->_dp;
}

void RsaParameters::dp( const std::vector<akv::byte_t>& value )
{
    _state->_dp = value;
}

const std::vector<akv::byte_t>& RsaParameters::dq() const
{
    return _state->_dq;
}

void RsaParameters::dq( const std::vector<akv::byte_t>& value )
{
    _state->_dq = value;
}

const std::vector<akv::byte_t>& RsaParameters::qi() const
{
    return _state->_qi;
}

void RsaParameters::qi( const std::vector<akv::byte_t>& value )
{
    _state->_qi = value;
}

} }
