/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace common {

class AKV_EXPORT Base64
{
public:
    static akv::string_t            encode( const std::vector<akv::byte_t>& bytes );
    static std::vector<akv::byte_t> decode( const akv::string_t& encoded );

    static akv::string_t            encode_url( const std::vector<akv::byte_t>& bytes );
    static std::vector<akv::byte_t> decode_url( const akv::string_t& encoded );

    Base64() = delete;

protected:

private:

#if TARGET_OS_WIN32

    // Encode a set of bytes to a Base64Url string
    static bool encode( _In_reads_bytes_(cbBytes) const akv::byte_t *pbBytes, _In_ size_t cbBytes, _Out_writes_bytes_to_opt_(cbEncoded,*pcbEncoded ) akv::byte_t *pbEncoded, _In_ size_t cbEncoded, _Out_opt_ size_t *pcbEncoded );
    // Decode a string to set of bytes
    static bool decode( _In_reads_bytes_(cbEncoded) const char *pbEncoded, _In_ size_t cbEncoded, _Out_writes_bytes_to_opt_(cbDecoded,*pcbDecoded) akv::byte_t *pbDecoded, _In_ size_t cbDecoded, _Out_opt_ size_t *pcbDecoded );
    // Encode a set of bytes to a Base64Url string
    static bool encode_url( _In_reads_bytes_(cbBytes) const akv::byte_t *pbBytes, _In_ size_t cbBytes, _Out_writes_bytes_to_opt_(cbEncoded,*pcbEncoded) akv::byte_t *pbEncoded, _In_ size_t cbEncoded, _Out_opt_ size_t *pcbEncoded );
    // Decode a string to set of bytes
    static bool decode_url( _In_reads_bytes_(cbEncoded) const char *pbEncoded, _In_ size_t cbEncoded, _Out_writes_bytes_to_opt_(cbDecoded,*pcbDecoded) akv::byte_t *pbDecoded, _In_ size_t cbDecoded, _Out_opt_ size_t *pcbDecoded );

#else

    // Encode a set of bytes to a Base64Url string
    static bool encode( const akv::byte_t *pbBytes, size_t cbBytes, akv::byte_t *pbEncoded, size_t cbEncoded, size_t *pcbEncoded );
    // Decode a string to set of bytes
    static bool decode( const char *pbEncoded, size_t cbEncoded, akv::byte_t *pbDecoded, size_t cbDecoded, size_t *pcbDecoded );
    // Encode a set of bytes to a Base64Url string
    static bool encode_url( const akv::byte_t *pbBytes, size_t cbBytes, akv::byte_t *pbEncoded, size_t cbEncoded, size_t *pcbEncoded );
    // Decode a string to set of bytes
    static bool decode_url( const char *pbEncoded, size_t cbEncoded, akv::byte_t *pbDecoded, size_t cbDecoded, size_t *pcbDecoded );

#endif
};

} }
