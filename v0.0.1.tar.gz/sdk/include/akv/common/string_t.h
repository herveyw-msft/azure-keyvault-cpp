/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

#if _WIN32
#include <codecvt>
#endif

namespace akv { namespace common {

/// <summary>
/// Converts an integer to its narrow string representation
/// </summary>
inline std::string to_string( const int value ) throw ( std::runtime_error )
{
    return std::to_string( value );
}
inline std::string to_string( const long value ) throw ( std::runtime_error )
{
    return std::to_string( value );
}

inline std::string to_string( const char *value ) throw ( std::runtime_error )
{
    return std::string( value );
}

inline std::string to_string( const unsigned char *value ) throw ( std::runtime_error )
{
    return std::string( (const char *)value );
}

/// <summary>
/// Converts a vector of char to its narrow string representation
/// </summary>
inline std::string to_string( const std::vector<char>& value ) throw( std::runtime_error )
{
    return std::string( std::begin( value ), std::end( value ) );
}

/// <summary>
/// Converts a vector of unsigned char to its narrow string representation
/// </summary>
inline std::string to_string( const std::vector<unsigned char>& value ) throw( std::runtime_error )
{
    return std::string( std::begin( value ), std::end( value ) );
}

/// <summary>
/// Converts a std::string to it narrow string representation
/// </summary>
inline std::string to_string( const std::string& value ) throw( std::runtime_error )
{
    return std::string( value );
}

#if _WIN32

/// <summary>
/// Converts a std::wstring to its narrow string representation
/// </summary>
inline std::string to_string( const std::wstring& value ) throw( std::runtime_error )
{
    // TODO: Parameter checking
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>, wchar_t> convert;

    return convert.to_bytes( value );
}

inline std::wstring to_wide_string( const int value ) throw ( std::runtime_error )
{
    return std::to_wstring( value );
}

inline std::wstring to_wide_string( const long value ) throw ( std::runtime_error )
{
    return std::to_wstring( value );
}

// For time_t on Windows
inline std::wstring to_wide_string( const int64_t value ) throw ( std::runtime_error )
{
    return std::to_wstring( value );
}

inline std::wstring to_wide_string( const char *value ) throw ( std::runtime_error )
{
     // TODO: Parameter checking
     std::wstring_convert<std::codecvt_utf8_utf16<akv::char_t>, akv::char_t> convert;

     return convert.from_bytes( value );
}

inline std::wstring to_wide_string( const unsigned char *value ) throw ( std::runtime_error )
{
     // TODO: Parameter checking
     std::wstring_convert<std::codecvt_utf8_utf16<akv::char_t>, akv::char_t> convert;

     return convert.from_bytes( (const char *)value );
}

inline std::wstring to_wide_string( const wchar_t *value ) throw ( std::runtime_error )
{
    return std::wstring( value );
}

/// <summary>
/// Converts a vector of char to its wide string representation.
/// </summary>
inline std::wstring to_wide_string( const std::vector<char>& value ) throw( std::runtime_error )
{
    // TODO: Parameter checking
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>, wchar_t> convert;

    return convert.from_bytes( value.data(), value.data() + value.size() );
}

/// <summary>
/// Converts a vector of unsigned char to its wide string representation.
/// </summary>
inline std::wstring to_wide_string( const std::vector<unsigned char>& value ) throw( std::runtime_error )
{
    // TODO: Parameter checking
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>, wchar_t> convert;

    return convert.from_bytes( (const char *)value.data(), (const char *)value.data() + value.size() );
}

/// <summary>
/// Converts a std::string to a wide string
/// </summary>
inline std::wstring to_wide_string( const std::string& value ) throw( std::runtime_error )
{
    // TODO: Parameter checking
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>, wchar_t> convert;

    return convert.from_bytes( value );
}

/// <summary>
/// Converts and arbitrary object to the platform native form.
/// </summary>
template<typename T>
inline akv::string_t to_platform_string( const T& value ) throw( std::runtime_error )
{
    return to_wide_string( value );
}

/// <summary>
/// Converts a pointer to an arbitrary object to the platform native string form.
/// </summary>
template<typename T>
inline akv::string_t to_platform_string( const T* value ) throw( std::runtime_error )
{
    return to_wide_string( value );
}

#else

/// <summary>
/// Converts a reference to an arbitrary object to the platform native string form.
/// </summary>
template<typename T>
inline akv::string_t to_platform_string( const T& value ) throw( std::runtime_error )
{
    return to_string( value );
}

/// <summary>
/// Converts a pointer to an arbitrary object to the platform native string form.
/// </summary>
template<typename T>
inline akv::string_t to_platform_string( const T* value ) throw( std::runtime_error )
{
    return to_string( *value );
}

#endif

inline bool contains( const akv::string_t& source, const akv::string_t& match )
{
    return source.find( match ) == akv::string_t::npos ? false : true;
}

inline std::vector<akv::byte_t> get_bytes( const akv::string_t& src )
{
    // Convert to narrow string
    std::string str = to_string( src );

    return std::vector<akv::byte_t>( std::begin( str ), std::end( str ) );
}

inline std::vector<akv::string_t> split( const akv::string_t& source, const akv::char_t& delimiter )
{
    size_t                    offset   = 0;
    size_t                    position = akv::string_t::npos;
    std::vector<akv::string_t> result;

    while ( ( position = source.find( delimiter, offset ) ) != akv::string_t::npos )
    {
        result.push_back( source.substr( offset, position - offset  ) );

        offset = position + 1;
    }

    if ( offset < source.size() )
    {
        result.push_back( source.substr( offset, source.size() - offset  ) );
    }

    return result;
}

template<class T>
inline bool starts_with( const T& source, const T& match )
{
    if ( source.size() >= match.size() )
    {
        return std::equal( match.begin(), match.end(), source.begin() );
    }

    return false;
}

inline akv::string_t trim( const akv::string_t& source, const akv::char_t character = __T( ' ' ) )
{
    auto begin = source.c_str();
    auto end   = begin + source.size() - 1;

    while ( begin <= end   && *begin == character ) begin++;
    while ( end   >= begin && *end   == character ) end--;

    if ( end > begin )
        return source.substr( begin - source.c_str(), end - begin + 1 );
    else
        return akv::string_t();
}

} }
