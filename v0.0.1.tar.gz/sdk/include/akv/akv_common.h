/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

#if defined(__cplusplus)

#include <akv/common/string_t.h>
#include <akv/common/base64.h>

#else

#error Microsoft Azure Key Vault Core requires C++

#endif