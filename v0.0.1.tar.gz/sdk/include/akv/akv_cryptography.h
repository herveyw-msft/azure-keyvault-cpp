/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

#if defined(__cplusplus)

#if !_WIN32
#include <openssl/pkcs12.h>
#endif

// Cryptography needs types and core
#include <akv/akv_types.h>
#include <akv/akv_core.h>

#include <akv/cryptography/Algorithm.h>
#include <akv/cryptography/AlgorithmNames.h>
#include <akv/cryptography/AlgorithmResolver.h>

#include <akv/cryptography/IEncryptionTransform.h>
#include <akv/cryptography/IKeyWrapTransform.h>
#include <akv/cryptography/ISignatureTransform.h>

#include <akv/cryptography/EncryptionAlgorithm.h>
#include <akv/cryptography/AsymmetricEncryptionAlgorithm.h>
#include <akv/cryptography/SymmetricEncryptionAlgorithm.h>

#include <akv/cryptography/IncrementalHash.h>
#include <akv/cryptography/RandomNumberGenerator.h>

#include <akv/cryptography/AesCbcEncryptionAlgorithm.h>
#include <akv/cryptography/AesCbcHmacSha.h>

#include <akv/cryptography/KeyWrapAlgorithm.h>
#include <akv/cryptography/AesKeyWrapAlgorithm.h>

#include <akv/cryptography/Key.h>

#include <akv/cryptography/RsaParameters.h>
#include <akv/cryptography/RsaKey.h>
#include <akv/cryptography/SymmetricKey.h>

#include <akv/cryptography/CertificateKey.h>
#include <akv/cryptography/CertificateStoreKeyResolver.h>

#include <akv/cryptography/CombinedKeyResolver.h>

#else

#error Microsoft Azure Key Vault Cryptography requires C++

#endif
