/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

#if defined(__cplusplus)

// JOSE needs types and code
#include <akv/akv_types.h>
#include <akv/akv_core.h>

#include <akv/jose/JsonWebKey.h>

#include <akv/jose/JweHeader.h>
#include <akv/jose/JweObject.h>
#include <akv/jose/JsonWebEncryption.h>

#include <akv/jose/JwsHeader.h>
#include <akv/jose/JwsObject.h>
#include <akv/jose/JsonWebSignature.h>

#endif

//
// Windows only interface for JSON Web Encryption
//
// NOTE: Experimental
//
#ifdef _WIN32

extern "C"
{
    /***
    * Upacks the compact representation of a JSON Web Encryption object. This function
    * assumes that the JWE object has been protected using an X509Certificate that
    * is installed in the Windows LocalMachine or CurrentUser 'My' store and is accessible to the
    * caller. The function returns a pointer to a buffer containing the decrypted
    * payload of the JWE object and this buffer should be freed using the FreeUnprotectedBuffer
    * function.
    * 
    */
    HRESULT AKV_EXPORT UnprotectCompact( PCWCHAR  pProtected,
                                         size_t   cbProtected,
                                         PBYTE   *ppUnprotected,
                                         size_t  *cbUnprotected );

    void AKV_EXPORT FreeUnprotectedBuffer(const PBYTE pUnprotected, size_t cbUnprotected);
}

#endif
