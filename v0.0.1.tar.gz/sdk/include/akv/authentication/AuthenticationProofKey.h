/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

namespace jose {

class AKV_EXPORT JsonWebKey;
}

namespace authentication {

class AuthenticationProofKey : public akv::IKey
{
public:
    typedef std::map<akv::string_t, web::json::value>::iterator iterator;

    AuthenticationProofKey( const akv::string_t& kty );
    AuthenticationProofKey( const AuthenticationProofKey& )              = delete;
    AuthenticationProofKey& operator = ( const AuthenticationProofKey& ) = delete;
    virtual ~AuthenticationProofKey();

    const std::shared_ptr<akv::jose::JsonWebKey>& public_key() const;
    web::json::value to_json() const;

    // IKey Interface
    virtual akv::string_t kid() const;

    virtual akv::string_t defaultEncryptionAlgorithm() const;
    virtual akv::string_t defaultKeyWrapAlgorithm() const;
    virtual akv::string_t defaultSignatureAlgorithm() const;

    virtual pplx::task<DecryptResult> decrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& ciphertext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const std::vector<akv::byte_t>& authenticationTag,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<EncryptResult> encrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<WrapResult> wrap( const akv::string_t&            algorithm,
                                         const std::vector<akv::byte_t>& key,
                                         const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<UnwrapResult> unwrap( const akv::string_t&            algorithm,
                                             const std::vector<akv::byte_t>& encryptedKey,
                                             const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<SignResult> signHash( const akv::string_t&             algorithm,
                                             const std::vector<akv::byte_t>&   digest,
                                             const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<VerifyResult> verifyHash( const akv::string_t&             algorithm,
                                                 const std::vector<akv::byte_t>&   digest,
                                                 const std::vector<akv::byte_t>&   signature,
                                                 const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;
    

protected:

private:
    class State;
    State *_state;

};

} }
