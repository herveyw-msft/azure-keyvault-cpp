/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {
    
namespace cryptography {
class AKV_EXPORT CertificateKey;
}

namespace authentication {

class AKV_EXPORT ClientCredentials
{
public:
    ClientCredentials() { };
    virtual ~ClientCredentials() { };

    // Encode the credentials for use with the OAuth2 request
    virtual akv::string_t encode( const akv::string_t& audience ) const = 0;

protected:

private:

};

class AKV_EXPORT ClientSecretCredentials : public ClientCredentials
{
public:
    ClientSecretCredentials( const akv::string_t& client_id, const akv::string_t& client_secret );

    ClientSecretCredentials( const ClientSecretCredentials& );
    ClientSecretCredentials& operator = ( const ClientSecretCredentials& );

    ClientSecretCredentials( ClientSecretCredentials&& );
    ClientSecretCredentials& operator = ( ClientSecretCredentials&& );
    virtual ~ClientSecretCredentials();

    virtual akv::string_t encode( const akv::string_t& audience ) const;

protected:

private:
    struct State;
    State *_state;
};

class AKV_EXPORT ClientCertificateCredentials : public ClientCredentials
{
public:
    ClientCertificateCredentials( const akv::string_t& client_id, const std::shared_ptr<akv::cryptography::CertificateKey>& certificate );

    ClientCertificateCredentials( const ClientCertificateCredentials& );
    ClientCertificateCredentials& operator = ( const ClientCertificateCredentials& );

    ClientCertificateCredentials( ClientCertificateCredentials&& );
    ClientCertificateCredentials& operator = ( ClientCertificateCredentials&& );
    virtual ~ClientCertificateCredentials();

    virtual akv::string_t encode( const akv::string_t& audience ) const;

protected:

private:
    struct State;
    State *_state;
};

} }
