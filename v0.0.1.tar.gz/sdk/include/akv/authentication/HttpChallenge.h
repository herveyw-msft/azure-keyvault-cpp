/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace authentication {

class AKV_EXPORT HttpChallenge
{
public:
    HttpChallenge( const akv::string_t& uri, const akv::string_t& challenge );
    HttpChallenge( const HttpChallenge& )              = delete;
    HttpChallenge& operator = ( const HttpChallenge& ) = delete;
    virtual ~HttpChallenge();

    akv::string_t scheme() const;
    akv::string_t authority() const;
    akv::string_t resource() const;
    akv::string_t scope() const;

    akv::string_t getParameter( const akv::string_t& name ) const;
    akv::string_t setParameter( const akv::string_t& name, const akv::string_t& value );

protected:
    struct State;
    State *_state;

    std::pair<akv::string_t, std::map<akv::string_t, akv::string_t>> parseChallenge( const akv::string_t& challenge );
    akv::string_t validateUri( const akv::string_t& uri );

private:
};

class AKV_EXPORT HttpBearerChallenge : public HttpChallenge
{
public:
    static bool isBearerChallenge( const akv::string_t& challenge );

    HttpBearerChallenge( const akv::string_t& uri, const akv::string_t& challenge );
    HttpBearerChallenge( const HttpBearerChallenge& )              = delete;
    HttpBearerChallenge& operator = ( const HttpBearerChallenge& ) = delete;
    virtual ~HttpBearerChallenge();

protected:

private:
};

class AKV_EXPORT HttpPoPChallenge : public HttpChallenge
{
public:
    static bool isPoPChallenge( const akv::string_t& challenge );

    HttpPoPChallenge( const akv::string_t& uri, const akv::string_t& challenge );
    HttpPoPChallenge( const HttpPoPChallenge& )              = delete;
    HttpPoPChallenge& operator = ( const HttpPoPChallenge& ) = delete;
    virtual ~HttpPoPChallenge();

protected:

private:
};

} }
