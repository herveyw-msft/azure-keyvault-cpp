/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace authentication {

class AKV_EXPORT AuthenticationException
{
public:
    AuthenticationException( unsigned short status, const akv::string_t& error );
    AuthenticationException( unsigned short status, const akv::string_t& error, const akv::string_t& error_description );

    AuthenticationException( const AuthenticationException& );
    AuthenticationException& operator = ( const AuthenticationException& );

    AuthenticationException( AuthenticationException&& );
    AuthenticationException& operator = ( AuthenticationException&& );

    virtual ~AuthenticationException();

    unsigned short       status_code() const;
    const akv::string_t& error() const;
    const akv::string_t& error_description() const;

protected:
    struct State;
    State *_state;

private:
};

} }
