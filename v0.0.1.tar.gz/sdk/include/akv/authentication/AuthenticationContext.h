/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKey;

namespace jose {
class AKV_EXPORT JsonWebKey;
}

namespace authentication {

class AKV_EXPORT AuthenticationException;
class AKV_EXPORT ClientCredentials;
class AKV_EXPORT ClientSecretCredentials;
class AKV_EXPORT AuthenticationProofKey;

class AKV_EXPORT AccessToken
{
public:
    AccessToken( const akv::string_t& token, time_t expires );
    AccessToken( const akv::string_t& token, const std::shared_ptr<akv::authentication::AuthenticationProofKey>& key, time_t expires );

    AccessToken( const AccessToken& )              = delete;
    AccessToken( AccessToken&& )                   = delete;
    AccessToken& operator = ( const AccessToken& ) = delete;
    AccessToken& operator = ( AccessToken&& )      = delete;

    akv::string_t                                 token() const;
    const std::shared_ptr<AuthenticationProofKey> key() const;
    time_t                                        expires() const;

protected:

private:
    struct State;
    State *_state;
};

class AKV_EXPORT AuthenticationContext
{
public:
    AuthenticationContext();
    AuthenticationContext( const AuthenticationContext& )              = delete; // No copy
    AuthenticationContext( AuthenticationContext&& )                   = delete; // No move
    AuthenticationContext& operator = ( const AuthenticationContext& ) = delete; // No copy assign
    AuthenticationContext& operator = ( AuthenticationContext&& )      = delete; // No move assign
    virtual ~AuthenticationContext();

    // Acquire an access token using the parameters provided.
    pplx::task<std::shared_ptr<AccessToken>> acquire_token( const akv::string_t&            scheme,
                                                            const akv::string_t&            authority,
                                                            const akv::string_t&            resource,
                                                            const akv::string_t&            scope,
                                                            const ClientCredentials&        credentials,
                                                            const pplx::cancellation_token& cancellationToken = pplx::cancellation_token::none() ) throw( AuthenticationException );

    // Flushes the the cache associated with this AuthenticationContext
    void flush();

protected:

private:
    class Impl;
    Impl *_impl;
};

} }
