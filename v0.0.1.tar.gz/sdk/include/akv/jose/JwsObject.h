/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace jose {

class AKV_EXPORT JwsHeader;

class AKV_EXPORT JwsObject
{
public:
    static std::shared_ptr<JwsObject> from_compact_jws( const akv::string_t& compactJws );
    static std::shared_ptr<JwsObject> from_flattened_jws( const akv::string_t& flattenedJws );

    JwsObject();
    JwsObject( const JwsObject& );
    JwsObject& operator = ( const JwsObject& );
    JwsObject( JwsObject&& );
    JwsObject& operator = ( JwsObject&& );
    virtual ~JwsObject();

    // Protected header
    const std::shared_ptr<JwsHeader> protected_header() const;
    void protected_header( const std::shared_ptr<JwsHeader> );

    akv::string_t protected_header_encoded() const;

    // Unprotected header
    const std::shared_ptr<JwsHeader> unprotected_header() const;
    void unprotected_header( const std::shared_ptr<JwsHeader> );

    const std::vector<akv::byte_t>& payload() const;
    void payload( const std::vector<akv::byte_t>& );

    const std::vector<akv::byte_t>& signature() const;
    void signature( const std::vector<akv::byte_t>& );

    akv::string_t to_compact_jws() const;
    akv::string_t to_string() const;

protected:

private:
    class State;
    State *_state;
};

} }
