/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace jose {

class AKV_EXPORT JwsHeader
{
public:
    static std::shared_ptr<JwsHeader> from_compact_header( const akv::string_t& compactHeader );

    JwsHeader();
    JwsHeader( const JwsHeader& );
    JwsHeader( JwsHeader&& );
    JwsHeader& operator = ( const JwsHeader& );
    JwsHeader& operator = ( JwsHeader&& );
    virtual ~JwsHeader();

    const akv::string_t& kid() const;
    void kid( const akv::string_t& kid );

    const akv::string_t& algorithm() const;
    void algorithm( const akv::string_t& algorithm );

    void add_property( const akv::string_t& name, const web::json::value& value );
    web::json::value get_property( const akv::string_t& name ) const;
    bool has_property( const akv::string_t& name ) const;
    void remove_property( const akv::string_t& name );

    bool empty() const;

    akv::string_t to_compact_header() const;
    akv::string_t to_string() const;

protected:

private:
    struct State;
    State *_state;
};

} }
