/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace jose {

class AKV_EXPORT JweFormatException
{
public:
    JweFormatException( const akv::string_t& error );
    JweFormatException( const akv::string_t& error, const akv::string_t& error_description );

    JweFormatException( const JweFormatException& );
    JweFormatException& operator = ( const JweFormatException& );

    JweFormatException( JweFormatException&& );
    JweFormatException& operator = ( JweFormatException&& );

    virtual ~JweFormatException();

    const akv::string_t& error() const;
    const akv::string_t& error_description() const;

protected:
    struct State;
    State *_state;

private:
};

} }
