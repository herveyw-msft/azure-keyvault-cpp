/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace web { namespace json {

class value;

} }

namespace akv {

// Imports from cryptography
namespace cryptography {
class AKV_EXPORT RsaParameters;
}

    
namespace jose {

//
// JSON Web Key
//
class AKV_EXPORT JsonWebKey
{
public:
    class AKV_EXPORT KeyTypes
    {
    public:
        const static akv::string_t& Rsa();
        const static akv::string_t& RsaHsm();

    private:
        KeyTypes() = delete;
    };

    class AKV_EXPORT KeyOperations
    {
    public:
        const static akv::string_t& Encrypt();
        const static akv::string_t& Decrypt();
        const static akv::string_t& WrapKey();
        const static akv::string_t& UnwrapKey();
        const static akv::string_t& Sign();
        const static akv::string_t& Verify();

    private:
        KeyOperations() = delete;
    };

    static std::shared_ptr<JsonWebKey> from_json( const web::json::value& value );
    static std::shared_ptr<JsonWebKey> from_string( const akv::string_t& str );

    JsonWebKey( const JsonWebKey& );
    JsonWebKey& operator = ( const JsonWebKey& );

    JsonWebKey( JsonWebKey&& );
    JsonWebKey& operator = ( JsonWebKey&& );

    JsonWebKey( const akv::string_t& kid, const akv::cryptography::RsaParameters& rsa );

    virtual ~JsonWebKey();

    akv::string_t                      kid() const;
    akv::string_t                      kty() const;
    std::unordered_set<akv::string_t>& key_ops();

    std::vector<akv::byte_t> n() const;
    std::vector<akv::byte_t> e() const;

    std::vector<akv::byte_t> d() const;
    std::vector<akv::byte_t> p() const;
    std::vector<akv::byte_t> q() const;
    std::vector<akv::byte_t> dp() const;
    std::vector<akv::byte_t> dq() const;
    std::vector<akv::byte_t> qi() const;

    std::vector<akv::byte_t> k() const;

    akv::cryptography::RsaParameters to_rsa_parameters( bool includePrivate = false ) const;
    web::json::value                 to_json() const;
    akv::string_t                    to_string() const;

protected:

private:
    struct State;
    State *_state;

    JsonWebKey();
};

} }
