/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKeyResolver;
    
namespace jose {

class AKV_EXPORT JweObject;

class AKV_EXPORT JsonWebEncryption
{
public:
    static pplx::task<std::shared_ptr<JweObject>> protect( const IKey& dataEncryptionKey,
                                               const akv::string_t& dataEncryptionAlgorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<std::shared_ptr<JweObject>> protect( const IKey& keyEncryptionKey,
                                               const akv::string_t& keyEncryptionAlgorithm,
                                               const akv::string_t& dataEncryptionAlgorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<std::shared_ptr<JweObject>> protect( const IKey& keyEncryptionKey,
                                               const akv::string_t& keyEncryptionAlgorithm,
                                               const std::vector<akv::byte_t>& dataEncryptionKey,
                                               const akv::string_t& dataEncryptionAlgorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<akv::string_t> protect_compact( const IKey& dataEncryptionKey,
                                                         const akv::string_t& dataEncryptionAlgorithm,
                                                         const std::vector<akv::byte_t>& plaintext,
                                                         const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<akv::string_t> protect_compact( const IKey& keyEncryptionKey,
                                                         const akv::string_t& keyEncryptionAlgorithm,
                                                         const akv::string_t& dataEncryptionAlgorithm,
                                                         const std::vector<akv::byte_t>& plaintext,
                                                         const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<akv::string_t> protect_compact( const IKey& keyEncryptionKey,
                                                         const akv::string_t& keyEncryptionAlgorithm,
                                                         const std::vector<akv::byte_t>& dataEncryptionKey,
                                                         const akv::string_t& dataEncryptionAlgorithm,
                                                         const std::vector<akv::byte_t>& plaintext,
                                                         const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<std::vector<akv::byte_t>> unprotect( const IKeyResolver& resolver,
                                                                const std::shared_ptr<JweObject> jwe,
                                                                const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<std::vector<akv::byte_t>> unprotect_compact( const IKeyResolver& resolver,
                                                                     const akv::string_t& compactJwe,
                                                                     const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    // No instances!
    JsonWebEncryption() = delete;
    JsonWebEncryption( const JsonWebEncryption& ) = delete;
    JsonWebEncryption& operator = ( const JsonWebEncryption& ) = delete;
    ~JsonWebEncryption() = delete;

protected:

private:
    static std::shared_ptr<JweObject> CreateHeader( const akv::string_t& keyWrapAlgorithm, const akv::string_t& dataEncryptionAlgorithm, const akv::string_t& keyIdentifier );
};

} }
