/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace jose {

class AKV_EXPORT JsonWebSignature
{
public:
    static pplx::task<std::shared_ptr<JwsObject>> sign( const IKey&                     signature_key,
                                                        const std::vector<akv::byte_t>& payload,
                                                        const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<std::shared_ptr<JwsObject>> sign( const IKey&                     signature_key,
                                                        const akv::string_t&            signature_algorithm,
                                                        const std::vector<akv::byte_t>& payload,
                                                        const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<std::shared_ptr<JwsObject>> sign( const IKey&                      signature_key,
                                                        const std::shared_ptr<JwsObject> object,
                                                        const pplx::cancellation_token&  token = pplx::cancellation_token::none() );

    static pplx::task<akv::string_t> sign_compact( const IKey&                     signature_key,
                                                   const std::vector<akv::byte_t>& payload,
                                                   const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<akv::string_t> sign_compact( const IKey&                     signature_key,
                                                   const akv::string_t&            signature_algorithm,
                                                   const std::vector<akv::byte_t>& payload,
                                                   const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    static pplx::task<bool> verify( const IKeyResolver&              keyResolver,
                                    const std::shared_ptr<JwsObject> jws,
                                    const pplx::cancellation_token&  token = pplx::cancellation_token::none() );

    static pplx::task<bool> verify_compact( const IKeyResolver&             keyResolver,
                                            const akv::string_t&            jws,
                                            const pplx::cancellation_token& token = pplx::cancellation_token::none() );

    // No instances!
    JsonWebSignature()                                       = delete;
    JsonWebSignature( const JsonWebSignature& )              = delete;
    JsonWebSignature& operator = ( const JsonWebSignature& ) = delete;
    ~JsonWebSignature() = delete;

protected:

private:
    static std::shared_ptr<JwsObject> CreateHeader( const akv::string_t& kid, const akv::string_t& algorithm );
};

} }
