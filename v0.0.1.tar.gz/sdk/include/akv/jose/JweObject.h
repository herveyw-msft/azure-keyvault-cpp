/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace jose {

class AKV_EXPORT JweHeader;

class AKV_EXPORT JweObject
{
public:
    static std::shared_ptr<JweObject> from_compact_jwe(const akv::string_t& compactJwe );
    static std::shared_ptr<JweObject> from_flattened_jwe( const akv::string_t& flattenedJwe );

    JweObject();
    JweObject( const JweObject& );
    JweObject& operator = ( const JweObject& );
    JweObject( JweObject&& );
    JweObject& operator = ( JweObject&& );
    virtual ~JweObject();

    const std::shared_ptr<JweHeader> protected_header() const;
    void protected_header( const std::shared_ptr<JweHeader> );
    akv::string_t protected_header_encoded() const;

    const std::shared_ptr<JweHeader> unprotected_header() const;
    void unprotected_header( const std::shared_ptr<JweHeader> );

    const std::vector<akv::byte_t>& authentication_data() const;
    void authentication_data( const std::vector<akv::byte_t>& );

    const std::vector<akv::byte_t>& ciphertext() const;
    void ciphertext( const std::vector<akv::byte_t>& );

    const std::vector<akv::byte_t>& encrypted_key() const;
    void encrypted_key( const std::vector<akv::byte_t>& );

    const std::vector<akv::byte_t>& iv() const;
    void iv( const std::vector<akv::byte_t>& );

    const std::vector<akv::byte_t>& authentication_tag() const;
    void authentication_tag( const std::vector<akv::byte_t>& );

    akv::string_t to_compact_jwe() const;
    akv::string_t to_flattened_jwe() const;

protected:

private:
    class State;
    State *_state;
};

} }
