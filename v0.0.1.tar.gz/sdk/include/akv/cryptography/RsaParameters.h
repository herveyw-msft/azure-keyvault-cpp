/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {
    
class AKV_EXPORT RsaParameters
{
public:
    RsaParameters();                                    // ctor
    RsaParameters( const RsaParameters& );              // copy
    RsaParameters( RsaParameters&& );                   // move
    RsaParameters& operator = ( const RsaParameters& ); // copy assign
    RsaParameters& operator = ( RsaParameters&& );      // move assign
    bool operator == ( const RsaParameters& );          // compare
    virtual ~RsaParameters();

    // Public parameters

    // Modulus
    const std::vector<akv::byte_t>& n() const;
    void n( const std::vector<akv::byte_t>& );
    
    // Public Exponent
    const std::vector<akv::byte_t>& e() const;
    void e( const std::vector<akv::byte_t>& );
    
    // Private parameters
    bool hasPrivateParameters() const;
    
    // Private Exponent
    const std::vector<akv::byte_t>& d() const;
    void d( const std::vector<akv::byte_t>& );

    // Exponent1
    const std::vector<akv::byte_t>& dp() const;
    void dp( const std::vector<akv::byte_t>& );

    // Exponent2
    const std::vector<akv::byte_t>& dq() const;
    void dq( const std::vector<akv::byte_t>& );

    // Prime1
    const std::vector<akv::byte_t>& p() const;
    void p( const std::vector<akv::byte_t>& );

    // Prime2
    const std::vector<akv::byte_t>& q() const;
    void q( const std::vector<akv::byte_t>& );

    // Coefficient
    const std::vector<akv::byte_t>& qi() const;
    void qi( const std::vector<akv::byte_t>& );

protected:

private:
    struct State;
    State *_state;
};

} }
