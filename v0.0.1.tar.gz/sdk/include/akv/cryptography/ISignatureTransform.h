/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT ISignatureTransform
{
public:
    struct SignResult
    {
        SignResult() { };
        SignResult( const std::vector<akv::byte_t>& v ) : value( v ) { };

        std::vector<akv::byte_t> value;
    };

    struct VerifyResult
    {
        VerifyResult() { };
        VerifyResult( bool v ) : value( v ) { };

        bool value;
    };

    ISignatureTransform();
    virtual ~ISignatureTransform();

    virtual SignResult   signHash( const std::vector<akv::byte_t>& digest ) = 0;
    virtual VerifyResult verifyHash( const std::vector<akv::byte_t>& digest, const std::vector<akv::byte_t>& signature ) = 0;

    virtual SignResult   signMessage( const std::vector<akv::byte_t>& message ) = 0;
    virtual VerifyResult verifyMessage( const std::vector<akv::byte_t>& message, const std::vector<akv::byte_t>& signature ) = 0;
};

} }
