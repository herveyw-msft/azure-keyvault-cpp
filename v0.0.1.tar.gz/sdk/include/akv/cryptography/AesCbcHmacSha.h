/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT SymmetricEncryptionAlgorithm;

//
// AESCBCHS
//
class AKV_EXPORT AesCbcHmacSha : public SymmetricEncryptionAlgorithm
{
public:
    AesCbcHmacSha( const akv::string_t& name );
    AesCbcHmacSha( const AesCbcHmacSha& ) = delete;
    AesCbcHmacSha& operator = ( const AesCbcHmacSha& ) = delete;
    virtual ~AesCbcHmacSha();

    virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const;

protected:

private:

};

//
// A128CBCHS256
//
class AKV_EXPORT Aes128CbcHmacSha256 : public AesCbcHmacSha
{
public:
    static const akv::string_t& AlgorithmName();

    Aes128CbcHmacSha256();
    Aes128CbcHmacSha256( const Aes128CbcHmacSha256& ) = delete;
    Aes128CbcHmacSha256& operator = ( const Aes128CbcHmacSha256& ) = delete;
    virtual ~Aes128CbcHmacSha256();

protected:

private:

};

//
// A192CBCHS384
//
class AKV_EXPORT Aes192CbcHmacSha384 : public AesCbcHmacSha
{
public:
    static const akv::string_t& AlgorithmName();

    Aes192CbcHmacSha384();
    Aes192CbcHmacSha384( const Aes192CbcHmacSha384& ) = delete;
    Aes192CbcHmacSha384& operator = ( const Aes192CbcHmacSha384& ) = delete;
    virtual ~Aes192CbcHmacSha384();

protected:

private:

};

//
// A256CBCHS512
//
class AKV_EXPORT Aes256CbcHmacSha512 : public AesCbcHmacSha
{
public:
    static const akv::string_t& AlgorithmName();

    Aes256CbcHmacSha512();
    Aes256CbcHmacSha512( const Aes256CbcHmacSha512& ) = delete;
    Aes256CbcHmacSha512& operator = ( const Aes256CbcHmacSha512& ) = delete;
    virtual ~Aes256CbcHmacSha512();

protected:

private:

};

} }
