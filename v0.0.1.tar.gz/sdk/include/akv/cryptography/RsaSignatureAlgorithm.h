/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT ISignatureTransform;
class AKV_EXPORT AsymmetricSignatureAlgorithm;
class AKV_EXPORT RsaParameters;

class RsaKeyHandle;

class RsaSignatureAlgorithm : public AsymmetricSignatureAlgorithm
{
public:
    RsaSignatureAlgorithm( const akv::string_t& name );
    virtual ~RsaSignatureAlgorithm();

    virtual std::shared_ptr<ISignatureTransform> createTransform( const RsaParameters& ) const = 0;
    virtual std::shared_ptr<ISignatureTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const = 0;

protected:
    template<typename T>
    std::shared_ptr<ISignatureTransform> createTransform( const RsaParameters& ) const;

    template<typename T>
    std::shared_ptr<ISignatureTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

private:

};

class Rs256SignatureAlgorithm : public RsaSignatureAlgorithm
{
public:
    static const akv::string_t& AlgorithmName();

    Rs256SignatureAlgorithm();
    virtual ~Rs256SignatureAlgorithm();

    virtual std::shared_ptr<ISignatureTransform> createTransform( const RsaParameters& ) const;
    virtual std::shared_ptr<ISignatureTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

protected:

private:

};

class Rs384SignatureAlgorithm : public RsaSignatureAlgorithm
{
public:
    static const akv::string_t& AlgorithmName();

    Rs384SignatureAlgorithm();
    virtual ~Rs384SignatureAlgorithm();

    virtual std::shared_ptr<ISignatureTransform> createTransform( const RsaParameters& ) const;
    virtual std::shared_ptr<ISignatureTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

protected:

private:

};

class Rs512SignatureAlgorithm : public RsaSignatureAlgorithm
{
public:
    static const akv::string_t& AlgorithmName();

    Rs512SignatureAlgorithm();
    virtual ~Rs512SignatureAlgorithm();

    virtual std::shared_ptr<ISignatureTransform> createTransform( const RsaParameters& ) const;
    virtual std::shared_ptr<ISignatureTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

protected:

private:

};

} }
