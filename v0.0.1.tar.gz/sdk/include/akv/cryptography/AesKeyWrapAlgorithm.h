/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT KeyWrapAlgorithm;

class AKV_EXPORT AesKw : public KeyWrapAlgorithm
{
public:
    static const std::vector<akv::byte_t>& DefaultIv();

    AesKw( const akv::string_t& name );
    AesKw( const AesKw& ) = delete;
    AesKw& operator = ( const AesKw& ) = delete;
    virtual ~AesKw();

protected:
    virtual std::shared_ptr<IKeyWrapTransform> createTransformCore( const std::vector<akv::byte_t>& key,
                                                                    const std::vector<akv::byte_t>& iv = AesKw::DefaultIv() ) const;

};

class AKV_EXPORT AesKw128 : public AesKw
{
public:
    static const akv::string_t& AlgorithmName();

    AesKw128();
    AesKw128( const AesKw128& ) = delete;
    AesKw128& operator = ( const AesKw128& ) = delete;
    virtual ~AesKw128();

    virtual std::shared_ptr<IKeyWrapTransform> createTransform( const std::vector<akv::byte_t>& key,
                                                                const std::vector<akv::byte_t>& iv = AesKw::DefaultIv() ) const;
};

class AKV_EXPORT AesKw192 : public AesKw
{
public:
    static const akv::string_t& AlgorithmName();

    AesKw192();
    AesKw192( const AesKw192& ) = delete;
    AesKw192& operator = ( const AesKw192& ) = delete;
    virtual ~AesKw192();

    virtual std::shared_ptr<IKeyWrapTransform> createTransform( const std::vector<akv::byte_t>& key,
                                                                const std::vector<akv::byte_t>& iv = AesKw::DefaultIv() ) const;
};

class AKV_EXPORT AesKw256 : public AesKw
{
public:
    static const akv::string_t& AlgorithmName();

    AesKw256();
    AesKw256( const AesKw256& ) = delete;
    AesKw256& operator = ( const AesKw256& ) = delete;
    virtual ~AesKw256();

    virtual std::shared_ptr<IKeyWrapTransform> createTransform( const std::vector<akv::byte_t>& key,
                                                                const std::vector<akv::byte_t>& iv = AesKw::DefaultIv() ) const;
};

} }
