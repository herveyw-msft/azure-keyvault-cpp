/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT SymmetricEncryptionAlgorithm;

class AKV_EXPORT Aes : public SymmetricEncryptionAlgorithm
{
public:
    Aes( const akv::string_t& name );
    Aes( const Aes& ) = delete;
    Aes& operator = ( const Aes& ) = delete;
    virtual ~Aes();

    //virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const = 0;

protected:
    std::shared_ptr<IEncryptionTransform> createTransformCore( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv ) const;

private:
};

class AKV_EXPORT Aes128 : public Aes
{
public:
    static const akv::string_t& AlgorithmName();

    Aes128();
    Aes128( const Aes128& ) = delete;
    Aes128& operator = ( const Aes128& ) = delete;

    std::shared_ptr<IEncryptionTransform> createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const;

protected:

private:
};

class AKV_EXPORT Aes192 : public Aes
{
public:
    static const akv::string_t& AlgorithmName();
    
    Aes192();
    Aes192( const Aes192& ) = delete;
    Aes192& operator = ( const Aes192& ) = delete;

    std::shared_ptr<IEncryptionTransform> createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const;

protected:

private:
};

class AKV_EXPORT Aes256 : public Aes
{
public:
    static const akv::string_t& AlgorithmName();
    
    Aes256();
    Aes256( const Aes256& ) = delete;
    Aes256& operator = ( const Aes256& ) = delete;

    std::shared_ptr<IEncryptionTransform> createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const;

protected:

private:
};

} }
