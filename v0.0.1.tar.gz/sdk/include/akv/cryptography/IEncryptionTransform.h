/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IEncryptionTransform
{
public:
    struct DecryptResult
    {
        DecryptResult() { };
        DecryptResult( const std::vector<akv::byte_t>& p ) : plaintext( p ) { };
        
        DecryptResult( const DecryptResult& ) = default;
        DecryptResult& operator = ( const DecryptResult& ) = default;

#if _MSC_VER && _MSC_VER >= 1900
		DecryptResult( DecryptResult&& ) = default;
		DecryptResult& operator = ( DecryptResult&& ) = default;
#endif

        std::vector<akv::byte_t> plaintext;
    };

    struct EncryptResult
    {
        EncryptResult() { };
        EncryptResult( const std::vector<akv::byte_t>& c ) : ciphertext( c ) { };
        EncryptResult( const std::vector<akv::byte_t>& c, const std::vector<akv::byte_t>& t ) : ciphertext( c ), tag( t ) { };
        
        EncryptResult( const EncryptResult& ) = default;
        EncryptResult& operator = ( const EncryptResult& ) = default;

#if _MSC_VER && _MSC_VER >= 1900
		EncryptResult( EncryptResult&& ) = default;
		EncryptResult& operator = ( EncryptResult&& ) = default;
#endif

        std::vector<akv::byte_t> ciphertext;
        std::vector<akv::byte_t> tag;
    };

    IEncryptionTransform();
    virtual ~IEncryptionTransform();

    virtual EncryptResult encrypt( const std::vector<akv::byte_t>& plaintext ) = 0;
    virtual DecryptResult decrypt( const std::vector<akv::byte_t>& ciphertext, const std::vector<akv::byte_t>& tag ) = 0;
};

} }
