/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKey;
    
namespace cryptography {

class AKV_EXPORT AlgorithmResolver;
class AKV_EXPORT IEncryptionTransform;
class AKV_EXPORT IKeyWrapTransform;
class AKV_EXPORT ISignatureTransform;
    
class AKV_EXPORT Key : public IKey
{
public:
    Key( const akv::string_t& kid );

    Key( const Key& )              = delete; // No copy
    Key( Key&& );
    Key& operator = ( const Key& ) = delete; // No copy assign
    Key& operator = ( Key&& );
    virtual ~Key();

    /// <summary>
    /// The key identifier
    /// </summary>
    virtual akv::string_t kid() const;


protected:
    template<typename T>
    std::shared_ptr<T> get_algorithm( const akv::string_t& algorithm_name ) const
    {
        if ( algorithm_name.empty() )
            throw std::invalid_argument( "algorithm_name" );

        auto algorithm = AlgorithmResolver::DefaultResolver().getAlgorithm( algorithm_name );

        if ( algorithm == nullptr )
            throw std::invalid_argument( "algorithm_name" );

        return std::dynamic_pointer_cast<T>( algorithm );
    }

    virtual pplx::task<IKey::DecryptResult> decrypt_transform( const std::shared_ptr<IEncryptionTransform> transform,
                                                               const std::vector<akv::byte_t>&             cipher_text,
                                                               const std::vector<akv::byte_t>&             authentication_tag,
                                                               const pplx::cancellation_token&             token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<IKey::EncryptResult> encrypt_transform( const std::shared_ptr<IEncryptionTransform> transform,
                                                               const std::vector<akv::byte_t>&             plain_text,
                                                               const pplx::cancellation_token&             token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<IKey::UnwrapResult> unwrap_transform( const std::shared_ptr<IKeyWrapTransform> transform,
                                                             const std::vector<akv::byte_t>&          cipher_text,
                                                             const pplx::cancellation_token&          token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<IKey::WrapResult> wrap_transform( const std::shared_ptr<IKeyWrapTransform> transform,
                                                         const std::vector<akv::byte_t>&          plain_text,
                                                         const pplx::cancellation_token&          token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<IKey::SignResult> sign_transform( const std::shared_ptr<ISignatureTransform> transform,
                                                         const std::vector<akv::byte_t>&            digest,
                                                         const pplx::cancellation_token&            token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<IKey::VerifyResult> verify_transform( const std::shared_ptr<ISignatureTransform> transform,
                                                             const std::vector<akv::byte_t>&            digest,
                                                             const std::vector<akv::byte_t>&            signature,
                                                             const pplx::cancellation_token&            token = pplx::cancellation_token::none() ) const;

private:
    struct State;
    State *_state;
};

} }
