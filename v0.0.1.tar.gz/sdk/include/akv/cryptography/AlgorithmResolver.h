/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT Algorithm;
    
class AKV_EXPORT AlgorithmResolver
{
public:
    static AlgorithmResolver& DefaultResolver();

    AlgorithmResolver();
    ~AlgorithmResolver();

    void addAlgorithm( const akv::string_t& algorithmName, std::shared_ptr<Algorithm> algorithm );
    std::shared_ptr<Algorithm> getAlgorithm( const akv::string_t& algorithmName ) const;
    void removeAlgorithm( const akv::string_t& algorithmName );

protected:

private:
    struct _Impl;
    _Impl *_impl;
};

} }
