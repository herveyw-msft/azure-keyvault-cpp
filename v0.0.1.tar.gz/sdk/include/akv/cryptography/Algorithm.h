/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {
    
class AKV_EXPORT Algorithm
{
public:
    virtual ~Algorithm();

    const akv::string_t& name() const;

protected:
    Algorithm( const akv::string_t& name );

private:
    Algorithm() = delete;
    Algorithm( const Algorithm& ) = delete;
    Algorithm& operator =( const Algorithm& ) = delete;

    struct _Impl;
    _Impl *_impl;
};

} }
