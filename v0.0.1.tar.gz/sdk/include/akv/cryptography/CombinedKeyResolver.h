/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKeyResolver;

namespace cryptography {

class AKV_EXPORT CombinedKeyResolver : public IKeyResolver
{
public:
    CombinedKeyResolver(std::unique_ptr<IKeyResolver> first, std::unique_ptr<IKeyResolver> fallback);
    CombinedKeyResolver(const CombinedKeyResolver&) = delete;              // No copy
    CombinedKeyResolver& operator = (const CombinedKeyResolver&) = delete; // No assign
    ~CombinedKeyResolver() override;

    pplx::task<std::shared_ptr<IKey>> resolve_key(const akv::string_t& kid, const pplx::cancellation_token& token = pplx::cancellation_token::none()) const override;

private:
    struct State;
    State *_state;
};

} }
