/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT IncrementalHash
{
public:
    enum Type
    {
        SHA256,
        SHA384,
        SHA512
    };

    IncrementalHash( Type hashName );
    IncrementalHash( const IncrementalHash& )              = delete; // No copy
    IncrementalHash( IncrementalHash&& )                   = delete; // No move

    IncrementalHash& operator = ( const IncrementalHash& ) = delete; // No copy assign
    IncrementalHash& operator = ( IncrementalHash&& )      = delete; // No move assign

    ~IncrementalHash();

    size_t size() const;

    void update( const std::vector<akv::byte_t>& data );
    std::vector<akv::byte_t> updateFinal( const std::vector<akv::byte_t>& data );

protected:

private:
    struct State;
    State *_state;
};

} }
