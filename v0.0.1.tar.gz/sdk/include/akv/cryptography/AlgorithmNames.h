/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT AlgorithmNames
{
public:
    static const akv::string_t& Rsa15();
    static const akv::string_t& RsaOaep();
    static const akv::string_t& RsaOaep256();

    static const akv::string_t& Rs256();
    static const akv::string_t& Rs384();
    static const akv::string_t& Rs512();

    static const akv::string_t& Hs256();
    static const akv::string_t& Hs384();
    static const akv::string_t& Hs512();

    static const akv::string_t& Aes128Kw();
    static const akv::string_t& Aes192Kw();
    static const akv::string_t& Aes256Kw();

    static const akv::string_t& Aes128Cbc();
    static const akv::string_t& Aes192Cbc();
    static const akv::string_t& Aes256Cbc();

    static const akv::string_t& Aes128CbcHmacSha256();
    static const akv::string_t& Aes192CbcHmacSha384();
    static const akv::string_t& Aes256CbcHmacSha512();

protected:

private:
    AlgorithmNames() = delete;
    virtual ~AlgorithmNames() = delete;

};

} }
