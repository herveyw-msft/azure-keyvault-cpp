/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {
    
class AKV_EXPORT RandomNumberGenerator
{
public:
    static void get_bytes( std::vector<akv::byte_t>& target );

    RandomNumberGenerator() = delete;
    RandomNumberGenerator( const RandomNumberGenerator& ) = delete;
    RandomNumberGenerator& operator = ( const RandomNumberGenerator& ) = delete;
    ~RandomNumberGenerator() = delete;

private:
};

} }
