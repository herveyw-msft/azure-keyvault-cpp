/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT EncryptionAlgorithm;
class AKV_EXPORT IEncryptionTransform;

class AKV_EXPORT SymmetricEncryptionAlgorithm : public EncryptionAlgorithm
{
public:
    SymmetricEncryptionAlgorithm( const akv::string_t& name );
    virtual ~SymmetricEncryptionAlgorithm();

    virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::vector<akv::byte_t>& key, const std::vector<akv::byte_t>& iv, const std::vector<akv::byte_t>& aad ) const = 0;

protected:

private:

};

} }
