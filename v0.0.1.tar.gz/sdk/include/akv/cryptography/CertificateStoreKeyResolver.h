/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKeyResolver;
    
namespace cryptography {

class AKV_EXPORT CertificateStoreKeyResolver : public IKeyResolver
{
public:
    static const akv::string_t& LocalMachine();
    static const akv::string_t& CurrentUser();

    CertificateStoreKeyResolver( const akv::string_t& storeLocation, const akv::string_t& storeName );
    CertificateStoreKeyResolver(const CertificateStoreKeyResolver&) = delete;              // No copy
    CertificateStoreKeyResolver& operator = (const CertificateStoreKeyResolver&) = delete; // No assign
    ~CertificateStoreKeyResolver() override;

    pplx::task<std::shared_ptr<IKey>> resolve_key( const akv::string_t& kid, const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const override;

protected:

private:
    struct State;
    State *_state;
};

} }
