/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKey;
    
namespace cryptography {

class AKV_EXPORT DelegatingKey : public akv::IKey
{
public:
    DelegatingKey( const std::shared_ptr<akv::IKey>& );

    DelegatingKey( const DelegatingKey& );
    DelegatingKey( DelegatingKey&& );
    DelegatingKey& operator = ( const DelegatingKey& );
    DelegatingKey& operator = ( DelegatingKey&& );
    ~DelegatingKey();

    virtual akv::string_t kid() const;

    virtual akv::string_t defaultEncryptionAlgorithm() const;
    virtual akv::string_t defaultKeyWrapAlgorithm() const;
    virtual akv::string_t defaultSignatureAlgorithm() const;

    virtual pplx::task<DecryptResult> decrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& ciphertext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const std::vector<akv::byte_t>& authenticationTag,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<EncryptResult> encrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<WrapResult> wrap( const akv::string_t&            algorithm,
                                         const std::vector<akv::byte_t>& key,
                                         const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<UnwrapResult> unwrap( const akv::string_t&            algorithm,
                                             const std::vector<akv::byte_t>& encryptedKey,
                                             const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<SignResult> signHash( const akv::string_t&             algorithm,
                                             const std::vector<akv::byte_t>&   digest,
                                             const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    virtual pplx::task<VerifyResult> verifyHash( const akv::string_t&             algorithm,
                                                 const std::vector<akv::byte_t>&   digest,
                                                 const std::vector<akv::byte_t>&   signature,
                                                 const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

protected:
    const std::shared_ptr<IKey> inner() const;

private:
    struct State;
    State *_state;

};

} }
