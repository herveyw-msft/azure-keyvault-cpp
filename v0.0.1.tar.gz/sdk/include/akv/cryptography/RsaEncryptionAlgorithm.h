/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT AsymmetricEncryptionAlgorithm;
class AKV_EXPORT RsaParameters;

class RsaKeyHandle;

class RsaEncryptionAlgorithm : public AsymmetricEncryptionAlgorithm
{
public:
    RsaEncryptionAlgorithm( const akv::string_t& name );
    virtual ~RsaEncryptionAlgorithm();

    virtual std::shared_ptr<IEncryptionTransform> createTransform( const RsaParameters& ) const = 0;
    virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const = 0;

protected:
    template<typename T>
    std::shared_ptr<IEncryptionTransform> createTransform( const RsaParameters& ) const;

    template<typename T>
    std::shared_ptr<IEncryptionTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

private:

};

class Rsa15 : public RsaEncryptionAlgorithm
{
public:
    static const akv::string_t& AlgorithmName();

    Rsa15();
    virtual ~Rsa15();

    virtual std::shared_ptr<IEncryptionTransform> createTransform( const RsaParameters& ) const;
    virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

protected:

private:

};

class RsaOaep : public RsaEncryptionAlgorithm
{
public:
    static const akv::string_t& AlgorithmName();

    RsaOaep();
    virtual ~RsaOaep();

    virtual std::shared_ptr<IEncryptionTransform> createTransform( const RsaParameters& ) const;
    virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

protected:

private:

};

class RsaOaep256 : public RsaEncryptionAlgorithm
{
public:
    static const akv::string_t& AlgorithmName();

    RsaOaep256();
    virtual ~RsaOaep256();

    virtual std::shared_ptr<IEncryptionTransform> createTransform( const RsaParameters& ) const;
    virtual std::shared_ptr<IEncryptionTransform> createTransform( const std::shared_ptr<RsaKeyHandle>& keyHandle ) const;

protected:

private:

};

} }
