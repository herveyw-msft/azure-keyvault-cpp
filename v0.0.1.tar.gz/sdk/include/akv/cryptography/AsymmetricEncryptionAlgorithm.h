/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv { namespace cryptography {

class AKV_EXPORT Algorithm;
class AKV_EXPORT EncryptionAlgorithm;
class AKV_EXPORT IEncryptionTransform;

class AKV_EXPORT AsymmetricEncryptionAlgorithm : public EncryptionAlgorithm
{
public:
    AsymmetricEncryptionAlgorithm( const akv::string_t& name );
    virtual ~AsymmetricEncryptionAlgorithm();

protected:

private:

};

} }
