/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKey;
    
namespace cryptography {

class AKV_EXPORT Key;

class AKV_EXPORT SymmetricKey : public Key
{
public:
    static const int KeySize128 = 128 >> 3;
    static const int KeySize192 = 192 >> 3;
    static const int KeySize256 = 256 >> 3;
    static const int KeySize384 = 384 >> 3;
    static const int KeySize512 = 512 >> 3;

    static const int DefaultKeySize = KeySize256;

    SymmetricKey( const akv::string_t& kid );
    SymmetricKey( const akv::string_t& kid, const int keySizeInBytes );
    SymmetricKey( const akv::string_t& kid, const std::vector<akv::byte_t>& key );
    SymmetricKey( const SymmetricKey& )             = delete; // No copy
    SymmetricKey& operator =( const SymmetricKey& ) = delete; // No copy assign
	virtual ~SymmetricKey();

    virtual akv::string_t defaultEncryptionAlgorithm() const;
    virtual akv::string_t defaultKeyWrapAlgorithm() const;
    virtual akv::string_t defaultSignatureAlgorithm() const;

    /// <summary>
    /// Decrypts the specified cipher text.
    /// </summary>
    /// <param name="ciphertext">The cipher text to decrypt</param>
    /// <param name="iv">The initialization vector</param>
    /// <param name="authenticationData">The authentication data</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The plain text</returns>
    /// <remarks>Not all algorithms require, or support, all parameters.</remarks>
    virtual pplx::task<IKey::DecryptResult> decrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& ciphertext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const std::vector<akv::byte_t>& authenticationTag,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Encrypts the specified plain text.
    /// </summary>
    /// <param name="plaintext">The plain text to encrypt</param>
    /// <param name="iv">The initialization vector</param>
    /// <param name="authenticationData">The authentication data</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>A Tuple consisting of the cipher text, the authentication tag (if applicable), the algorithm used</returns>
    /// <remarks>Not all algorithyms require, or support, all parameters.</remarks>
    virtual pplx::task<IKey::EncryptResult> encrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Encrypts the specified key material.
    /// </summary>
    /// <param name="key">The key material to encrypt</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>A Tuple consisting of the encrypted key and the algorithm used</returns>
    virtual pplx::task<IKey::WrapResult> wrap( const akv::string_t&            algorithm,
                                         const std::vector<akv::byte_t>& key,
                                         const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Decrypts the specified key material.
    /// </summary>
    /// <param name="encryptedKey">The encrypted key material</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The decrypted key material</returns>
    virtual pplx::task<UnwrapResult> unwrap( const akv::string_t&            algorithm,
                                             const std::vector<akv::byte_t>& encryptedKey,
                                             const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Signs the specified digest.
    /// </summary>
    /// <param name="algorithm">The signature algorithm to use</param>
    /// <param name="digest">The digest to sign</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The signature value</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<SignResult> signHash( const akv::string_t&             algorithm,
                                             const std::vector<akv::byte_t>&   digest,
                                             const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Verifies the specified digest and signature.
    /// </summary>
    /// <param name="algorithm">The signature algorithm to use</param>
    /// <param name="digest">The digest to sign</param>
    /// <param name="signature">The signature to verify</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>True if the signature verifies</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<VerifyResult> verifyHash( const akv::string_t&             algorithm,
                                                 const std::vector<akv::byte_t>&   digest,
                                                 const std::vector<akv::byte_t>&   signature,
                                                 const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

protected:

private:
    struct _Impl;
    _Impl *_impl = NULL;
};

} }
