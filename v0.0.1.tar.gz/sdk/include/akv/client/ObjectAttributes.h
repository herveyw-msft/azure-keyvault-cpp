/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

// Forward declaration
namespace web {
namespace json {
class value;
} }

namespace akv {

namespace jose {
    
class AKV_EXPORT JsonWebKey;

}

class AKV_EXPORT ObjectAttributes
{
public:
    static std::shared_ptr<ObjectAttributes> from_string( const akv::string_t& src );
    static std::shared_ptr<ObjectAttributes> from_json( const web::json::value& src );

    ObjectAttributes();
    ObjectAttributes( const ObjectAttributes& );
    ObjectAttributes& operator = ( const ObjectAttributes& );

    ObjectAttributes( ObjectAttributes&& );
    ObjectAttributes& operator = ( ObjectAttributes&& );

    virtual ~ObjectAttributes();

    bool    enabled() const;
    void    enabled( bool value );

    int64_t nbf() const;
    void    nbf( int64_t value );

    int64_t exp() const;
    void    exp( int64_t value );
    
    int64_t created() const;
    int64_t updated() const;

    web::json::value to_json() const;

protected:

private:
    struct State;
    State *_state;
};

}
