/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

namespace authentication {
class AKV_EXPORT AccessToken;
}

class AKV_EXPORT IKey;

class AKV_EXPORT ObjectAttributes;
class AKV_EXPORT KeyBundle;
class AKV_EXPORT SecretBundle;

class HttpMessage;
class HttpMessageSecurity;

class AKV_EXPORT KeyVaultClient
{
public:
    // Authentication callback
    typedef std::function<pplx::task<std::shared_ptr<akv::authentication::AccessToken>>( const akv::string_t& scheme, const akv::string_t& authority, const akv::string_t& resource, const akv::string_t& scope )> AuthenticationCallback;

    KeyVaultClient( AuthenticationCallback authenticationCallback );

    KeyVaultClient( const KeyVaultClient& )              = delete; // No copy
    KeyVaultClient& operator = ( const KeyVaultClient& ) = delete; // No copy assign

#if _MSC_VER && _MSC_VER >= 1900
	KeyVaultClient( const KeyVaultClient&& )              = delete; // No move
    KeyVaultClient& operator = ( const KeyVaultClient&& ) = delete; // No move assign
#endif

    virtual ~KeyVaultClient();

    //
    // Key Operations
    //

    pplx::task<std::shared_ptr<KeyBundle>> key_import( const akv::string_t&            key_identifier,
                                                       const akv::KeyBundle&           key,
                                                       const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none() );

    pplx::task<std::shared_ptr<KeyBundle>> key_delete( const akv::string_t&            key_identifier,
                                                       const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none() );

    pplx::task<std::shared_ptr<KeyBundle>> key_get( const akv::string_t&            key_identifier,
                                                    const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none() );

    pplx::task<IKey::EncryptResult> key_encrypt( const akv::string_t&            key_identifier,
                                                 const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& value,
                                                 const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none() );

    pplx::task<IKey::DecryptResult> key_decrypt( const akv::string_t&            key_identifier,
                                                 const akv::string_t&            algorithm_name,
                                                 const std::vector<akv::byte_t>& value,
                                                 const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none()  );

    pplx::task<IKey::WrapResult> key_wrap( const akv::string_t&            key_identifier,
                                           const akv::string_t&            algorithm_name,
                                           const std::vector<akv::byte_t>& value,
                                           const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none()  );

    pplx::task<IKey::UnwrapResult> key_unwrap( const akv::string_t&            key_identifier,
                                               const akv::string_t&            algorithm_name,
                                               const std::vector<akv::byte_t>& value,
                                               const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none()  );

    pplx::task<IKey::SignResult> key_sign( const akv::string_t&            key_identifier,
                                           const akv::string_t&            algorithm_name,
                                           const std::vector<akv::byte_t>& value,
                                           const pplx::cancellation_token& cancellation_token  = pplx::cancellation_token::none() );

    pplx::task<IKey::VerifyResult> key_verify( const akv::string_t&            key_identifier,
                                               const akv::string_t&            algorithm_name,
                                               const std::vector<akv::byte_t>& digest,
                                               const std::vector<akv::byte_t>& signature,
                                               const pplx::cancellation_token& cancellation_token = pplx::cancellation_token::none()  );

    // 
    // Secret operations
    //

    pplx::task<std::shared_ptr<SecretBundle>> secret_get( const akv::string_t&            secretIdentifier,
                                                          const pplx::cancellation_token& cancel_token = pplx::cancellation_token::none() );

	pplx::task<std::shared_ptr<SecretBundle>> secret_set( const akv::string_t&                         secretIdentifier,
                                                          const akv::string_t&                         value,
                                                          const akv::string_t&                         content_type,
                                                          const std::shared_ptr<akv::ObjectAttributes> attributes,
                                                          const pplx::cancellation_token&              cancel_token = pplx::cancellation_token::none() );

protected:
    // Preauthentication step
    pplx::task<std::shared_ptr<HttpMessageSecurity>> get_message_security( const web::uri& httpUrl, const akv::string_t& httpMethod );

    // Generic key operation
    template<typename T>
    pplx::task<T> key_operation( const akv::string_t& key_identifier, const akv::string_t& operation, const akv::string_t& algorithm_name, const std::vector<akv::byte_t>& value, const pplx::cancellation_token& cancellation_token );

    // Generic HTTP Delete
    template<typename T>
    pplx::task<std::shared_ptr<T>> object_delete( const akv::string_t & objectIdentifier, const pplx::cancellation_token& cancellationToken = pplx::cancellation_token::none() );

    // Generic HTTP Get
    template<typename T>
    pplx::task<std::shared_ptr<T>> object_get( const akv::string_t & objectIdentifier, const pplx::cancellation_token& cancellationToken = pplx::cancellation_token::none() );

    // Generic HTTP Put
    template<typename T>
    pplx::task<std::shared_ptr<T>> object_put( const akv::string_t & objectIdentifier, const T& object, const pplx::cancellation_token& cancellationToken = pplx::cancellation_token::none() );

    // Generic request send with response handler
    template<typename T>
    pplx::task<std::shared_ptr<T>> sendMessage( const web::uri&                                                                                                              httpUrl,
                                                const std::shared_ptr<HttpMessage>                                                                                           httpMessage,
                                                std::function<pplx::task<std::shared_ptr<T>>( const web::http::http_response&, const std::shared_ptr<HttpMessageSecurity> )> httpResponseCallback,
                                                const pplx::cancellation_token&                                                                                              cancellationToken );

private:
    struct State;
    State *_state;

    std::shared_ptr<akv::KeyBundle> get_cached_key( const akv::string_t& key_identifier );
    std::shared_ptr<akv::KeyBundle> put_cached_key( const akv::string_t& key_identifier, std::shared_ptr<akv::KeyBundle> key );
    void flush_cached_keys();

};

}
