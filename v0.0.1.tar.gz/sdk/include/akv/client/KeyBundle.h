/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

// Forward declaration
namespace web {
namespace json {
class value;
} }

namespace akv {

namespace jose {
class AKV_EXPORT JsonWebKey;
}

class AKV_EXPORT ObjectAttributes;

class AKV_EXPORT KeyBundle
{
public:
    static std::shared_ptr<KeyBundle> from_string( const akv::string_t& src );
    static std::shared_ptr<KeyBundle> from_json( const web::json::value& src );

    KeyBundle();
    KeyBundle( const akv::jose::JsonWebKey& key );
    KeyBundle( const KeyBundle& );
    KeyBundle& operator = ( const KeyBundle& );

    KeyBundle( KeyBundle&& );
    KeyBundle& operator = ( KeyBundle&& );

    virtual ~KeyBundle();

    akv::string_t id() const;

    ObjectAttributes& attributes() const;

    jose::JsonWebKey& web_key() const;

    web::json::value to_json() const;

protected:

private:
    struct State;
    State *_state;
};

}
