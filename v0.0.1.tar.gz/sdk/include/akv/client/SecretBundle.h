/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

// Forward declaration
namespace web {
namespace json {
class value;
} }

namespace akv {

class AKV_EXPORT ObjectAttributes;

class AKV_EXPORT SecretBundle
{
public:
    static std::shared_ptr<SecretBundle> from_string( const akv::string_t& src );
    static std::shared_ptr<SecretBundle> from_json( const web::json::value& src );

    SecretBundle();
    SecretBundle( const SecretBundle& );
    SecretBundle& operator = ( const SecretBundle& );

    SecretBundle( SecretBundle&& );
    SecretBundle& operator = ( SecretBundle&& );

    virtual ~SecretBundle();

    akv::string_t id() const;
    akv::string_t content_type() const;
    akv::string_t value() const;
    akv::string_t kid() const;
    bool          managed() const;

    ObjectAttributes& attributes();

    web::json::value to_json() const;

protected:

private:
    struct State;
    State *_state;
};

}
