/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT IKeyResolver;


class AKV_EXPORT KeyVaultKeyResolver : public IKeyResolver
{
public:
    KeyVaultKeyResolver( KeyVaultClient::AuthenticationCallback callback );
    KeyVaultKeyResolver( const KeyVaultKeyResolver&) = delete;              // No copy
    KeyVaultKeyResolver( KeyVaultKeyResolver&& ) = delete;                  // No move
    KeyVaultKeyResolver& operator = (const KeyVaultKeyResolver& ) = delete; // No copy assign
    KeyVaultKeyResolver& operator = ( KeyVaultKeyResolver&& ) = delete;     // No move assign
    virtual ~KeyVaultKeyResolver();

    virtual pplx::task<std::shared_ptr<IKey>> resolve_key( const akv::string_t& kid, const pplx::cancellation_token& cancellationToken = pplx::cancellation_token::none() ) const;

protected:

private:
    struct State;
    State *_state;
};

}
