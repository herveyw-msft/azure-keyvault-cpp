/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

// Forward declaration
namespace web {
namespace json {
class value;
} }

namespace akv {

class AKV_EXPORT ObjectIdentifier
{
public:
    ObjectIdentifier( const ObjectIdentifier& );
    ObjectIdentifier& operator = ( const ObjectIdentifier& );

    ObjectIdentifier( ObjectIdentifier&& );
    ObjectIdentifier& operator = ( ObjectIdentifier&& );

    virtual ~ObjectIdentifier();

    akv::string_t vault() const;
    akv::string_t name() const;
    akv::string_t base_identifier() const;
    akv::string_t identifier() const;

protected:
    static bool is_object_identifier( const akv::string_t& collection, const akv::string_t& identifier );

    ObjectIdentifier( const akv::string_t& collection, const akv::string_t& identifier );

private:
    struct State;
    State *_state;
};

class AKV_EXPORT SecretIdentifier : public ObjectIdentifier
{
public:
    static bool is_secret_identifier( const akv::string_t& identifier );

    SecretIdentifier( const akv::string_t& identifier );
    SecretIdentifier( const SecretIdentifier& );
    SecretIdentifier& operator = ( const SecretIdentifier& );

    SecretIdentifier( SecretIdentifier&& );
    SecretIdentifier& operator = ( SecretIdentifier&& );

    virtual ~SecretIdentifier();

protected:

private:
    struct State;
    State *_state;
};

class AKV_EXPORT KeyIdentifier : public ObjectIdentifier
{
public:
    static bool is_key_identifier( const akv::string_t& identifier );

    KeyIdentifier( const akv::string_t& identifier );
    KeyIdentifier( const KeyIdentifier& );
    KeyIdentifier& operator = ( const KeyIdentifier& );

    KeyIdentifier( KeyIdentifier&& );
    KeyIdentifier& operator = ( KeyIdentifier&& );

    virtual ~KeyIdentifier();

protected:

private:
    struct State;
    State *_state;
};

}
