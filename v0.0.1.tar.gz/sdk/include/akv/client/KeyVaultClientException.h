/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv {

class AKV_EXPORT KeyVaultClientException
{
public:
public:
    KeyVaultClientException( unsigned short status, const akv::string_t& error );
    KeyVaultClientException( unsigned short status, const akv::string_t& error, const akv::string_t& error_description );

    KeyVaultClientException( const KeyVaultClientException& );
    KeyVaultClientException& operator = ( const KeyVaultClientException& );

    KeyVaultClientException( KeyVaultClientException&& );
    KeyVaultClientException& operator = ( KeyVaultClientException&& );

    virtual ~KeyVaultClientException();

    unsigned short       status_code() const;
    const akv::string_t& error() const;
    const akv::string_t& error_description() const;

protected:
    struct State;
    State *_state;

private:
};

}
