/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

// DLL export/import is only for Windows
#if _WIN32
// Define dllexport/dllimport
#if  defined(__AKV_EXPORT__)
#define AKV_EXPORT __declspec(dllexport)
#else
#define AKV_EXPORT __declspec(dllimport)
#endif

#else
// Define dllexport/dllimport as empty
#define AKV_EXPORT

#endif

#if defined( __cplusplus )
//
// STL
//
#include <algorithm>
#include <iterator>
#include <list>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <tuple>
#include <unordered_set>
#include <vector>

namespace akv
{

#ifdef _WIN32

// On Windows, we prefer wide strings
typedef uint8_t      byte_t;
typedef wchar_t      char_t;
typedef std::wstring string_t;

// Cross platform macro helpers (use u ## x for u16)
#ifndef __T
#define __T(x) L ## x
#endif

#else

// On other systems, we prefer narrow strings
typedef uint8_t        byte_t;
typedef char           char_t;
typedef std::string    string_t;

typedef void *PVOID;

// Cross platform macro helpers (use u ## x for u16)
#ifndef __T
#define __T(x) x
#endif

#endif

}

#endif
