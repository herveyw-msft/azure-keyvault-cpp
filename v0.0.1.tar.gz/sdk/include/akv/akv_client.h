/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

#if defined(__cplusplus)

// Client needs types and core
#include <akv/akv_types.h>
#include <akv/akv_core.h>

#include <akv/client/ObjectIdentifier.h>
#include <akv/client/KeyBundle.h>
#include <akv/client/SecretBundle.h>
#include <akv/client/KeyVaultClientException.h>
#include <akv/client/KeyVaultClient.h>

#include <akv/client/KeyVaultKey.h>
#include <akv/client/KeyVaultKeyResolver.h>

#else

#error Microsoft Azure Key Vault Core requires C++

#endif
