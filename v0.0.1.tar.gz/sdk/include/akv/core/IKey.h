/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

namespace akv
{

class AKV_EXPORT IKey
{
public:
    struct DecryptResult
    {
        DecryptResult() { };
        DecryptResult( const akv::string_t& k, const std::vector<akv::byte_t>& p ) : kid( k ), value( p ) { };
        
        DecryptResult( const DecryptResult& )              = default;
        DecryptResult& operator = ( const DecryptResult& ) = default;

#if _MSC_VER && _MSC_VER >= 1900
		DecryptResult(DecryptResult&&)              = default;
		DecryptResult& operator = (DecryptResult&&) = default;
#endif

        akv::string_t            kid;
        std::vector<akv::byte_t> value;
    };

    struct EncryptResult
    {
        EncryptResult() { };
        EncryptResult( const akv::string_t& k, const std::vector<akv::byte_t>& c ) : kid( k ), value( c ) { };
        EncryptResult( const akv::string_t& k, const std::vector<akv::byte_t>& c, const std::vector<akv::byte_t>& t ) : kid( k ), value( c ), tag( t ) { };
        
        EncryptResult( const EncryptResult& )              = default;
        EncryptResult& operator = ( const EncryptResult& ) = default;

#if _MSC_VER && _MSC_VER >= 1900
		EncryptResult(EncryptResult&&)              = default;
		EncryptResult& operator = (EncryptResult&&) = default;
#endif

        akv::string_t            kid;
        std::vector<akv::byte_t> value;
        std::vector<akv::byte_t> tag;
    };

    struct UnwrapResult
    {
        UnwrapResult() { };
        UnwrapResult( const akv::string_t& k, const std::vector<akv::byte_t>& p ) : kid( k ), value( p ) { };
        
        UnwrapResult( const UnwrapResult& )              = default;
        UnwrapResult& operator = ( const UnwrapResult& ) = default;

#if _MSC_VER && _MSC_VER >= 1900
		UnwrapResult(UnwrapResult&&)              = default;
		UnwrapResult& operator = (UnwrapResult&&) = default;
#endif

        akv::string_t            kid;
        std::vector<akv::byte_t> value;
    };

    struct WrapResult
    {
        WrapResult() { };
        WrapResult( const akv::string_t& k, const std::vector<akv::byte_t>& c ) : kid( k ), value( c ) { };
        
        WrapResult( const WrapResult& )            = default;
		WrapResult& operator = (const WrapResult&) = default;

#if _MSC_VER && _MSC_VER >= 1900
		WrapResult(WrapResult&&)              = default;
		WrapResult& operator = (WrapResult&&) = default;
#endif

        akv::string_t            kid;
        std::vector<akv::byte_t> value;
    };

    struct SignResult
    {
        SignResult() { };
        SignResult( const akv::string_t& k, const std::vector<akv::byte_t>& s ) : kid( k ), value( s ) { };
        
        SignResult( const SignResult& )            = default;
		SignResult& operator = (const SignResult&) = default;

#if _MSC_VER && _MSC_VER >= 1900
		SignResult(SignResult&&)              = default;
		SignResult& operator = (SignResult&&) = default;
#endif

        akv::string_t            kid;
        std::vector<akv::byte_t> value;
    };

    struct VerifyResult
    {
        VerifyResult() { };
        VerifyResult( const akv::string_t& k, bool v ) : kid( k ), value( v ) { };
        
        VerifyResult( const VerifyResult& )            = default;
		VerifyResult& operator = (const VerifyResult&) = default;

#if _MSC_VER && _MSC_VER >= 1900
		VerifyResult(VerifyResult&&)              = default;
		VerifyResult& operator = (VerifyResult&&) = default;
#endif

        akv::string_t kid;
        bool          value;
    };
    
    virtual ~IKey();

    /// <summary>
    /// The key identifier
    /// </summary>
    virtual akv::string_t kid() const = 0;

    virtual akv::string_t defaultEncryptionAlgorithm() const = 0;
    virtual akv::string_t defaultKeyWrapAlgorithm() const = 0;
    virtual akv::string_t defaultSignatureAlgorithm() const = 0;

    /// <summary>
    /// Encrypts the specified plain text.
    /// </summary>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="plaintext">The plain text to encrypt</param>
    /// <param name="iv">The initialization vector</param>
    /// <param name="authenticationData">The authentication data</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>A Tuple consisting of the cipher text, the authentication tag (if applicable), the algorithm used</returns>
    /// <remarks>Not all algorithyms require, or support, all parameters.</remarks>
    virtual pplx::task<EncryptResult> encrypt( const akv::string_t&            algorithm,
                                               const std::vector<akv::byte_t>& plaintext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const = 0;

    /// <summary>
    /// Encrypts the specified plain text using the keys defaultEncryptionAlgorithm.
    /// </summary>
    /// <param name="plaintext">The plain text to encrypt</param>
    /// <param name="iv">The initialization vector</param>
    /// <param name="authenticationData">The authentication data</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>A Tuple consisting of the cipher text, the authentication tag (if applicable), the algorithm used</returns>
    /// <remarks>Not all algorithyms require, or support, all parameters.</remarks>
    virtual pplx::task<EncryptResult> encrypt( const std::vector<akv::byte_t>& plaintext,
                                               const std::vector<akv::byte_t>& iv,
                                               const std::vector<akv::byte_t>& authenticationData,
                                               const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Decrypts the specified cipher text.
    /// </summary>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="ciphertext">The cipher text to decrypt</param>
    /// <param name="iv">The initialization vector</param>
    /// <param name="authenticationData">The authentication data</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The plain text</returns>
    /// <remarks>Not all algorithms require, or support, all parameters.</remarks>
    virtual pplx::task<DecryptResult> decrypt( const akv::string_t&            algorithm,
                                                const std::vector<akv::byte_t>& ciphertext,
                                                const std::vector<akv::byte_t>& iv,
                                                const std::vector<akv::byte_t>& authenticationData,
                                                const std::vector<akv::byte_t>& authenticationTag,
                                                const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const = 0;

    /// <summary>
    /// Encrypts the specified key material.
    /// </summary>
    /// <param name="key">The key material to encrypt</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>A Tuple consisting of the encrypted key and the algorithm used</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<WrapResult> wrap( const akv::string_t&            algorithm,
                                            const std::vector<akv::byte_t>& key,
                                            const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const = 0;

    /// <summary>
    /// Encrypts the specified key material using the keys defaultKeyWrapAlgorithm
    /// </summary>
    /// <param name="key">The key material to encrypt</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>A Tuple consisting of the encrypted key and the algorithm used</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<WrapResult> wrap( const std::vector<akv::byte_t>& key,
                                            const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Decrypts the specified key material.
    /// </summary>
    /// <param name="encryptedKey">The encrypted key material</param>
    /// <param name="algorithm">The algorithm to use</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The decrypted key material</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<UnwrapResult> unwrap( const akv::string_t&            algorithm,
                                                const std::vector<akv::byte_t>& encryptedKey,
                                                const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const = 0;

    /// <summary>
    /// Signs the specified digest.
    /// </summary>
    /// <param name="algorithm">The signature algorithm to use</param>
    /// <param name="digest">The digest to sign</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The signature value</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<SignResult> signHash( const akv::string_t&            algorithm,
                                                const std::vector<akv::byte_t>& digest,
                                                const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const = 0;

    /// <summary>
    /// Signs the specified digest using the keys defaultSignatureAlgorithm
    /// </summary>
    /// <param name="algorithm">The signature algorithm to use</param>
    /// <param name="digest">The digest to sign</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>The signature value</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<SignResult> signHash( const std::vector<akv::byte_t>& digest,
                                                const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const;

    /// <summary>
    /// Verifies the specified digest and signature.
    /// </summary>
    /// <param name="algorithm">The signature algorithm to use</param>
    /// <param name="digest">The digest to sign</param>
    /// <param name="signature">The signature to verify</param>
    /// <param name="token">Cancellation token</param>
    /// <returns>True if the signature verifies</returns>
    /// <remarks>If the algorithm is not specified, an implementation should use its default algorithm</remarks>
    virtual pplx::task<VerifyResult> verifyHash( const akv::string_t&            algorithm,
                                                    const std::vector<akv::byte_t>& digest,
                                                    const std::vector<akv::byte_t>& signature,
                                                    const pplx::cancellation_token& token = pplx::cancellation_token::none() ) const = 0;

protected:

private:
};

}
