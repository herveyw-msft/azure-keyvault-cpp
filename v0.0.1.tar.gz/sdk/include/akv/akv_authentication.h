/***
*
* Copyright (C) Microsoft. All rights reserved.
* Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
*
****/

#pragma once

#if defined(__cplusplus)

// Authentication needs types and JSON Web Key
#include <akv/akv_types.h>

#include <akv/authentication/AuthenticationException.h>
#include <akv/authentication/HttpChallenge.h>
#include <akv/authentication/ClientCredentials.h>
#include <akv/authentication/AuthenticationContext.h>

#else

#error Microsoft Azure Key Vault Authentication requires C++

#endif